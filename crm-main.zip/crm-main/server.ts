import express, { Request, Response } from "express";
import path from "path";
import dotenv from "dotenv";
import { GoogleGenAI } from "@google/genai";
import { createServer as createViteServer } from "vite";

dotenv.config();

// Initialize Express
const app = express();
const PORT = 3000;

app.use(express.json({ limit: '10mb' }));

// Helper to get Gemini Client with safe lazy initialization
let aiClient: GoogleGenAI | null = null;
function getAi(): GoogleGenAI {
  if (!aiClient) {
    const key = process.env.GEMINI_API_KEY;
    if (!key) {
      throw new Error("GEMINI_API_KEY environment variable is required");
    }
    aiClient = new GoogleGenAI({
      apiKey: key,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        }
      }
    });
  }
  return aiClient;
}

// 1. API: AI Business & Financial Advisor (Siana Munim)
app.post("/api/ai/advise", async (req: Request, res: Response): Promise<void> => {
  try {
    const { products, clients, sales, expenses, currentLanguage = 'roman_urdu' } = req.body;

    const ai = getAi();
    
    // Prepare financial stats
    const totalProducts = products?.length || 0;
    const totalStock = products?.reduce((acc: number, p: any) => acc + (p.stock || 0), 0) || 0;
    const lowStockItems = products?.filter((p: any) => (p.stock || 0) <= (p.minStockAlert || 5)) || [];
    
    const totalClients = clients?.length || 0;
    const outstandingKhata = clients?.reduce((acc: number, c: any) => acc + (c.balance || 0), 0) || 0;
    
    const totalSalesAmount = sales?.reduce((acc: number, s: any) => acc + (s.totalAmount || 0), 0) || 0;
    const totalProfit = sales?.reduce((acc: number, s: any) => acc + (s.profit || 0), 0) || 0;
    const totalDiscount = sales?.reduce((acc: number, s: any) => acc + (s.discount || 0), 0) || 0;
    
    const totalExpenses = expenses?.reduce((acc: number, e: any) => acc + (e.amount || 0), 0) || 0;
    const netSavings = totalProfit - totalExpenses;

    const languageContext = currentLanguage === 'urdu' 
      ? "proper Urdu language (Urdu script translation or clear Urdu in English alphabet as preferred, but please respond in clear and beautiful Roman Urdu or simple Urdu text so the user can easily read)."
      : "beautiful, friendly shopkeeper style Roman Urdu (Urdu written in English alphabets: e.g. 'Bhai jaan, aap ka business bohot acha chal raha hai but...').";

    const prompt = `
Aap ek tajurba-kar (experienced) visual accountant aur business helper hain jiska naam "Bhai AI Munim" hai.
Aap ko dukandari, retails, inventory management, aur accounts ka mukammal tajurba hai.
Neeche likhe hue mere shop ke real-time business stats aur records ko scan karein:

--- BUSINESS STATISTICS ---
- Total Products (Kul Maal): ${totalProducts} items in catalogue.
- High Demands & Stock status (Total Stock in hand): ${totalStock} units.
- Low Stock Items (Kam stock wala maal): ${JSON.stringify(lowStockItems.map((p: any) => `${p.name} (Baqi: ${p.stock})`))}
- Clients (Khata-dar customers): ${totalClients} clients.
- Total Outstanding Balance (Khata udhaar jo logo se lena hai): Rs. ${outstandingKhata}/-
- Total Sales Recorded (Kul Bikri): Rs. ${totalSalesAmount}/-
- Total Profit Earned (Kul Munafa from Sales): Rs. ${totalProfit}/-
- Total Discounts given (Choot): Rs. ${totalDiscount}/-
- Expenses Recorded (Kul kharchay): Rs. ${totalExpenses}/-
- Net Profit (Net Munafa - Profit minus Expenses): Rs. ${netSavings}/-

--- DATA LOGS ---
- Products List (Sample): ${JSON.stringify(products?.slice(0, 10).map((p: any) => ({ name: p.name, sale: p.sellingPrice, cost: p.costPrice, qty: p.stock })))}
- Recent Clients Balance (Top debtor): ${JSON.stringify(clients?.sort((a: any, b: any) => b.balance - a.balance).slice(0, 5).map((c: any) => ({ name: c.name, phone: c.phone, khata: c.balance })))}
- Recent Sales: ${JSON.stringify(sales?.slice(0, 5).map((s: any) => ({ invoice: s.invoiceNumber, amount: s.totalAmount, date: s.date })))}

--- REQUIRED ACTIONS ---
Aap ko is data ka gehra tajziya (detailed analysis) kar k aik mufeed, khush-ikhlaq, aur behtareen business advise deni hai is tarah:
1. Ek chota Khush-Aamdeed (greeting in warm host shopkeeper style).
2. Financial Health report card (Kaisa chal raha hai kaam, profit ratios kaisa hai).
3. Low stock warning (Jis maal ko foran order karne ki zaroorat hai, uska zikr).
4. Khata warning (Jo debtors/clients zyaada udhaar le chuke hain aur un se paise lene hain, uska zikr).
5. Munafa barhaney ka mashwara (Suggest how to cut expenses or change prices of some products to grow margins).
6. Short bullet points for next action items.

Response language must be: ${languageContext}.
Keep it structured, clear, and highly practical. Avoid abstract corporate jargon; speak like a wise veteran Pakistani/Hindustani Shop Accountant (Munim Ji).
`;

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: prompt,
      config: {
        systemInstruction: "You are 'Bhai AI Munim', a genius accountant, ledger master, and companion auditor for retail shops. You give advice with accurate math, great warmth, and helpful commercial suggestions in authentic Roman Urdu or beautiful simple translation.",
        temperature: 0.7,
      }
    });

    res.json({ advice: response.text });
  } catch (error: any) {
    console.error("AI Advice system error:", error);
    res.status(500).json({ error: "Bhai, AI server pe kuch masla aya hai.", details: error.message });
  }
});

// 2. API: Product Image Generator & Illustrator via Gemini / Imagen
app.post("/api/ai/generate-product-image", async (req: Request, res: Response): Promise<void> => {
  try {
    const { productName, category } = req.body;
    if (!productName) {
      res.status(400).json({ error: "Product name is required for image generation" });
      return;
    }

    const ai = getAi();
    const prompt = `A clean, professional studio-quality commercial catalog photo of a single retail product: "${productName}" under category: "${category}". Isolated on a pristine soft neutral light grey background, photorealistic, elegant lighting, extremely commercial, 3D high resolution.`;

    try {
      // We attempt to generate images using 'imagen-4.0-generate-001' or 'gemini-2.5-flash-image'
      // If we use 'imagen-4.0-generate-001' directly:
      const response = await ai.models.generateImages({
        model: 'imagen-4.0-generate-001',
        prompt: prompt,
        config: {
          numberOfImages: 1,
          outputMimeType: 'image/jpeg',
          aspectRatio: '1:1',
        },
      });

      if (response && response.generatedImages && response.generatedImages.length > 0) {
        const base64Bytes = response.generatedImages[0].image.imageBytes;
        res.json({ imageUrl: `data:image/jpeg;base64,${base64Bytes}` });
        return;
      }
    } catch (imagenErr) {
      console.warn("Imagen generation failed, falling back to gemini-2.5-flash-image:", imagenErr);
      
      // Let's fallback to standard Gemini 2.5 Flash Image generator
      try {
        const response = await ai.models.generateContent({
          model: 'gemini-2.5-flash-image',
          contents: {
            parts: [
              {
                text: prompt,
              },
            ],
          },
          config: {
            imageConfig: {
              aspectRatio: "1:1",
            },
          },
        });

        // Loop parts to extract image
        if (response.candidates?.[0]?.content?.parts) {
          for (const part of response.candidates[0].content.parts) {
            if (part.inlineData) {
              const base64EncodeString = part.inlineData.data;
              res.json({ imageUrl: `data:image/png;base64,${base64EncodeString}` });
              return;
            }
          }
        }
      } catch (geminiImgErr) {
        console.error("Gemini Image generation also failed:", geminiImgErr);
      }
    }

    // Defensive default placeholders based on category if all generation failed (or API key doesn't support paid visual model)
    const normalizedCategory = (category || "").toLowerCase();
    let sampleImg = "https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=400&q=80"; // red shoe
    if (normalizedCategory.includes("tech") || normalizedCategory.includes("electronic") || normalizedCategory.includes("mobile")) {
      sampleImg = "https://images.unsplash.com/photo-1525609004556-c46c7d6cf0a3?w=400&q=80"; // smartphone
    } else if (normalizedCategory.includes("clothing") || normalizedCategory.includes("kapra") || normalizedCategory.includes("garment")) {
      sampleImg = "https://images.unsplash.com/photo-1523381210434-271e8be1f52b?w=400&q=80"; // neat clothes
    } else if (normalizedCategory.includes("grocery") || normalizedCategory.includes("food") || normalizedCategory.includes("sauda")) {
      sampleImg = "https://images.unsplash.com/photo-1542838132-92c53300491e?w=400&q=80"; // groceries
    } else if (normalizedCategory.includes("bag") || normalizedCategory.includes("acc")) {
      sampleImg = "https://images.unsplash.com/photo-1584917865442-de89df76afd3?w=400&q=80"; // luxury bag
    } else {
      sampleImg = `https://picsum.photos/seed/${encodeURIComponent(productName)}/400/400`; // general dynamic seed
    }

    res.json({ imageUrl: sampleImg, isFallback: true });

  } catch (error: any) {
    console.error("General product image endpoint failure:", error);
    res.status(500).json({ error: "Could not generate product image", details: error.message });
  }
});

// 3. API: Dynamic Social Media Marketing & WhatsApp Broadcast Generator
app.post("/api/ai/generate-social-post", async (req: Request, res: Response): Promise<void> => {
  try {
    const { 
      productName, 
      category, 
      price, 
      platform = 'whatsapp', 
      tonality = 'offer_promotion',
      customNote = ''
    } = req.body;

    const ai = getAi();

    let toneDescription = "";
    if (tonality === 'funny_urdu') {
      toneDescription = "Friendly, slightly humorous, and highly native Roman Urdu with local Pakistani/Indian shop terminology (e.g., 'Bhaijaan', 'loot lo cell', 'jaldi aao').";
    } else if (tonality === 'offer_promotion') {
      toneDescription = "Exciting, discount-driven promotion containing clear emojis, pricing, contact details, call to action, headlines, and FOMO (Fear of Missing Out).";
    } else if (tonality === 'professional_bhai') {
      toneDescription = "Respectful, humble, elegant and clear customer relations message. Highly professional style in Roman Urdu or clean English.";
    } else {
      toneDescription = "A concise, itemized WhatsApp Group broadcast message with beautiful lists, spacing, checkmarks, pricing tags, and discount details.";
    }

    const prompt = `
You are a brilliant retail marketing copywriter named "Bhai Marketing King". You write high-converting social media posts, stories, captions, and WhatsApp groups messages for local merchants.

Write a custom post/message tailored specifically for:
- Platform: ${platform.toUpperCase()}
- Product Name: ${productName || 'General store catalogue / Multi-products'}
- Category: ${category || 'General Store'}
- Price Tag: Rs. ${price ? price + '/-' : 'Call or visit shop to ask'}
- Desired Tone: ${toneDescription}
- Custom merchant notes to include: ${customNote || 'None'}

Formatting rules:
1. Use appropriate and catchy emojis suitable for ${platform}.
2. Since it is for ${platform}, keep the structure scannable with bullet points or well-spaced lines.
3. If it's WhatsApp, include clear formatting (*bold*, _italics_) that WhatsApp supports.
4. Include a catchy signature line (e.g. "Bhai Shop ERP Ledger - Aap Ki Munfard Choice! 📱 For orders, call or contact on WhatsApp").
5. Add relevant local hashtags (e.g. #DukanPromotion, #BhaiRetailer, #BhaiShop, and others matching product category).
6. Write either in Roman Urdu (Urdu words with English alphabet) or standard English as per request, with clear, readable phrasing.

Only output the generated message content directly. Do not prefix with any conversational text or comments like "Here is your post:".
`;

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: prompt,
      config: {
        systemInstruction: "You are 'Bhai Marketing King', a genius social media copywriter for small and medium retail merchants. You write beautiful posts with great humor, urgency, and high conversion, ready to be copy-pasted or shared on social platforms.",
        temperature: 0.8,
      }
    });

    res.json({ post: response.text });
  } catch (error: any) {
    console.error("AI Marketing Generator failed:", error);
    res.status(500).json({ error: "Bhai, AI Marketing server me kuch masla aya hai.", details: error.message });
  }
});


// Setup dev server vs production
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    // Development Mode
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    
    // Inject Vite middlewares after the APIs
    app.use(vite.middlewares);
  } else {
    // Production Mode
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req: Request, res: Response) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Bhai ERP server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer();
