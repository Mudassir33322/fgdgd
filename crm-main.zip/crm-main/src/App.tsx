/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { 
  BarChart3, 
  Package, 
  Users, 
  ShoppingCart, 
  Calculator, 
  Sparkles, 
  Grid, 
  Globe, 
  HelpCircle,
  Menu,
  X,
  Plus,
  Share2,
  Truck
} from 'lucide-react';
import { Product, Client, Sale, Expense, Supplier, SupplierBill, Staff } from './types';
import Dashboard from './components/Dashboard';
import Inventory from './components/Inventory';
import Clients from './components/Clients';
import Sales from './components/Sales';
import Accountant from './components/Accountant';
import AiAdvisor from './components/AiAdvisor';
import SocialHub from './components/SocialHub';
import Suppliers from './components/Suppliers';

// Initial Seed Data - Empty to allow users to start fresh with a pristine clean database!
const INITIAL_PRODUCTS: Product[] = [];
const INITIAL_CLIENTS: Client[] = [];
const INITIAL_EXPENSES: Expense[] = [];
const INITIAL_SALES: Sale[] = [];
const INITIAL_SUPPLIERS: Supplier[] = [];
const INITIAL_SUPPLIER_BILLS: SupplierBill[] = [];
const INITIAL_STAFF: Staff[] = [];

export default function App() {
  
  // Tab panel navigator
  const [activeTab, setActiveTab] = useState('dashboard');
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  // Global Language Configuration Toggles
  const [language, setLanguage] = useState<'roman_urdu' | 'urdu' | 'english'>('roman_urdu');

  // Unified ERP States (loaded from localStorage or fall back onto seeds)
  const [products, setProducts] = useState<Product[]>(() => {
    const saved = localStorage.getItem('bhai_erp_products');
    return saved ? JSON.parse(saved) : INITIAL_PRODUCTS;
  });

  // Dynamic Dukan Categories state
  const [categories, setCategories] = useState<string[]>(() => {
    const saved = localStorage.getItem('bhai_erp_categories');
    return saved ? JSON.parse(saved) : ['Shoes', 'Garments', 'Electronics', 'Groceries', 'General'];
  });

  const [clients, setClients] = useState<Client[]>(() => {
    const saved = localStorage.getItem('bhai_erp_clients');
    return saved ? JSON.parse(saved) : INITIAL_CLIENTS;
  });

  const [sales, setSales] = useState<Sale[]>(() => {
    const saved = localStorage.getItem('bhai_erp_sales');
    return saved ? JSON.parse(saved) : INITIAL_SALES;
  });

  const [expenses, setExpenses] = useState<Expense[]>(() => {
    const saved = localStorage.getItem('bhai_erp_expenses');
    return saved ? JSON.parse(saved) : INITIAL_EXPENSES;
  });

  const [suppliers, setSuppliers] = useState<Supplier[]>(() => {
    const saved = localStorage.getItem('bhai_erp_suppliers');
    return saved ? JSON.parse(saved) : INITIAL_SUPPLIERS;
  });

  const [supplierBills, setSupplierBills] = useState<SupplierBill[]>(() => {
    const saved = localStorage.getItem('bhai_erp_supplier_bills');
    return saved ? JSON.parse(saved) : INITIAL_SUPPLIER_BILLS;
  });

  const [staff, setStaff] = useState<Staff[]>(() => {
    const saved = localStorage.getItem('bhai_erp_staff');
    return saved ? JSON.parse(saved) : INITIAL_STAFF;
  });

  // Sync state data sets with localStorage durably
  useEffect(() => {
    localStorage.setItem('bhai_erp_products', JSON.stringify(products));
  }, [products]);

  useEffect(() => {
    localStorage.setItem('bhai_erp_categories', JSON.stringify(categories));
  }, [categories]);

  useEffect(() => {
    localStorage.setItem('bhai_erp_clients', JSON.stringify(clients));
  }, [clients]);

  useEffect(() => {
    localStorage.setItem('bhai_erp_sales', JSON.stringify(sales));
  }, [sales]);

  useEffect(() => {
    localStorage.setItem('bhai_erp_expenses', JSON.stringify(expenses));
  }, [expenses]);

  useEffect(() => {
    localStorage.setItem('bhai_erp_suppliers', JSON.stringify(suppliers));
  }, [suppliers]);

  useEffect(() => {
    localStorage.setItem('bhai_erp_supplier_bills', JSON.stringify(supplierBills));
  }, [supplierBills]);

  useEffect(() => {
    localStorage.setItem('bhai_erp_staff', JSON.stringify(staff));
  }, [staff]);

  // One-time auto-wipe on mount to ensure user starts with a completely pristine clean database (zeroes everywhere)
  useEffect(() => {
    const hasWipedSeeds = localStorage.getItem('bhai_erp_wiped_seeds_v3');
    if (!hasWipedSeeds) {
      localStorage.removeItem('bhai_erp_products');
      localStorage.removeItem('bhai_erp_categories');
      localStorage.removeItem('bhai_erp_clients');
      localStorage.removeItem('bhai_erp_sales');
      localStorage.removeItem('bhai_erp_expenses');
      localStorage.removeItem('bhai_erp_suppliers');
      localStorage.removeItem('bhai_erp_supplier_bills');
      localStorage.removeItem('bhai_erp_staff');
      localStorage.removeItem('bhai_erp_expense_categories');

      setProducts([]);
      setCategories(['Shoes', 'Garments', 'Electronics', 'Groceries', 'General']);
      setClients([]);
      setSales([]);
      setExpenses([]);
      setSuppliers([]);
      setSupplierBills([]);
      setStaff([]);

      localStorage.setItem('bhai_erp_wiped_seeds_v3', 'true');
    }
  }, []);


  // 1. DYNAMIC CATEGORY MODIFIERS
  const handleAddCategory = (cat: string) => {
    if (!categories.includes(cat)) {
      setCategories([...categories, cat]);
    }
  };

  const handleDeleteCategory = (cat: string) => {
    setCategories(categories.filter(c => c !== cat));
    // Auto shift remaining products from that deleted category to General
    setProducts(products.map(p => p.category === cat ? { ...p, category: 'General' } : p));
  };


  // 2. PRODUCT HANDLERS
  const handleAddProduct = (prod: Product) => {
    setProducts([prod, ...products]);
  };

  const handleUpdateProduct = (prod: Product) => {
    setProducts(products.map(p => p.id === prod.id ? prod : p));
  };

  const handleDeleteProduct = (id: string) => {
    setProducts(products.filter(p => p.id !== id));
  };

  // 2. CLIENT HANDLERS
  const handleAddClient = (client: Client) => {
    setClients([client, ...clients]);
  };

  const handleUpdateClient = (client: Client) => {
    setClients(clients.map(c => c.id === client.id ? client : c));
  };

  const handleDeleteClient = (id: string) => {
    setClients(clients.filter(c => c.id !== id));
  };

  // Recover payments voucher - subtract amount from outstanding client khata balance, log receipt
  const handleRecordClientPayment = (clientId: string, amount: number) => {
    setClients(clients.map(c => {
      if (c.id === clientId) {
        return {
          ...c,
          balance: Math.max(0, c.balance - amount),
          lastTransactionDate: new Date().toISOString().split('T')[0]
        };
      }
      return c;
    }));

    // Record as standard cash inflow receipt (negative expense or offset, but wait — we can just offset or state it!)
    const targetClient = clients.find(c => c.id === clientId);
    const clientName = targetClient ? targetClient.name : 'Client';
    
    // Log as custom expense adjustment with negative cash outflow to represent payment received
    const recoveryLog: Expense = {
      id: 'EXP-REV-' + Date.now().toString().slice(-4),
      title: `Khata Recovery received from ${clientName}`,
      amount: -amount, // Saved as cash recovery offset
      category: 'General',
      date: new Date().toISOString().split('T')[0]
    };
    setExpenses([recoveryLog, ...expenses]);
  };

  // 3. SALES INVOICE HANDLER
  // Auto-deducts sold stocks from warehouse inventory, handles client outstanding debt logs
  const handleAddSale = (newSale: Sale) => {
    // Deduct stock limits
    setProducts(prevProds => {
      return prevProds.map(p => {
        const matchingCartItem = newSale.items.find(item => item.productId === p.id);
        if (matchingCartItem) {
          return {
            ...p,
            stock: Math.max(0, p.stock - matchingCartItem.qty)
          };
        }
        return p;
      });
    });

    // Record client khata loan debt if unpaid portion exists
    const unpaidBalance = newSale.totalAmount - newSale.paidAmount;
    if (newSale.clientId !== 'walk-in' && unpaidBalance > 0) {
      setClients(prevClients => {
        return prevClients.map(c => {
          if (c.id === newSale.clientId) {
            return {
              ...c,
              balance: c.balance + unpaidBalance,
              lastTransactionDate: newSale.date
            };
          }
          return c;
        });
      });
    }

    // Save transaction
    setSales([newSale, ...sales]);
  };

  // 4. GENERAL LEDGER EXPENSES
  const handleAddExpense = (exp: Expense) => {
    setExpenses([exp, ...expenses]);
  };

  const handleDeleteExpense = (id: string) => {
    setExpenses(expenses.filter(e => e.id !== id));
  };

  const handleResetAllData = () => {
    const confirmText = language === 'english' 
      ? 'Are you sure you want to permanently clear all ERP data (Products, Sales, Expenses, Clients, Staff, Suppliers)? This cannot be undone.'
      : language === 'urdu'
      ? 'کیا آپ واقعی دکان کا تمام ڈیٹا مستقل طور پر ختم کرنا چاہتے ہیں؟ یہ عمل واپس نہیں لایا جا سکتا۔'
      : 'Kya aap waqai dukan ka sara data hamesha k liye saaf karna chahte hain? Yeh wapas nahi laya ja sakta.';
      
    if (window.confirm(confirmText)) {
      localStorage.removeItem('bhai_erp_products');
      localStorage.removeItem('bhai_erp_categories');
      localStorage.removeItem('bhai_erp_clients');
      localStorage.removeItem('bhai_erp_sales');
      localStorage.removeItem('bhai_erp_expenses');
      localStorage.removeItem('bhai_erp_suppliers');
      localStorage.removeItem('bhai_erp_supplier_bills');
      localStorage.removeItem('bhai_erp_staff');
      localStorage.removeItem('bhai_erp_expense_categories');

      setProducts([]);
      setCategories(['Shoes', 'Garments', 'Electronics', 'Groceries', 'General']);
      setClients([]);
      setSales([]);
      setExpenses([]);
      setSuppliers([]);
      setSupplierBills([]);
      setStaff([]);
      
      alert(language === 'english' ? 'Database Cleared successfully!' : language === 'urdu' ? 'ڈیٹا کامیابی سے صاف ہو گیا!' : 'Data kamyabi se saaf ho gaya!');
    }
  };


  // 5. SUPPLIERS (DEALERS) HANDLERS
  const handleAddSupplier = (sup: Supplier) => {
    setSuppliers([sup, ...suppliers]);
  };

  const handleUpdateSupplier = (sup: Supplier) => {
    setSuppliers(suppliers.map(s => s.id === sup.id ? sup : s));
  };

  const handleDeleteSupplier = (id: string) => {
    setSuppliers(suppliers.filter(s => s.id !== id));
  };

  const handleRecordSupplierPayment = (supplierId: string, amount: number) => {
    setSuppliers(suppliers.map(s => {
      if (s.id === supplierId) {
        return {
          ...s,
          balance: Math.max(0, s.balance - amount)
        };
      }
      return s;
    }));

    // Record cash outlay / expense event
    const targetSup = suppliers.find(s => s.id === supplierId);
    const supName = targetSup ? targetSup.name : 'Supplier';
    const paymentOutward: Expense = {
      id: 'EXP-SUP-PAY-' + Date.now().toString().slice(-4),
      title: `Cash Debt Paid to Supplier Dealer: ${supName}`,
      amount: amount,
      category: 'General',
      date: new Date().toISOString().split('T')[0]
    };
    setExpenses([paymentOutward, ...expenses]);
  };

  const handleRecordStockPurchase = (bill: SupplierBill) => {
    // Add to bills list
    setSupplierBills([bill, ...supplierBills]);

    // Increase product stock count
    setProducts(products.map(p => {
      if (p.id === bill.productId) {
        return {
          ...p,
          stock: p.stock + bill.qty
        };
      }
      return p;
    }));

    // Raise supplier balance if transaction is credit-based
    const remainLiability = bill.totalAmount - bill.paidAmount;
    if (remainLiability > 0) {
      setSuppliers(suppliers.map(s => {
        if (s.id === bill.supplierId) {
          return {
            ...s,
            balance: s.balance + remainLiability
          };
        }
        return s;
      }));
    }

    // Log the paidAmount portion as active cash spend/expense right now
    if (bill.paidAmount > 0) {
      const spend: Expense = {
        id: 'EXP-PURC-' + Date.now().toString().slice(-4),
        title: `Procured stock: ${bill.productName} (${bill.qty} units)`,
        amount: bill.paidAmount,
        category: 'General',
        date: bill.date
      };
      setExpenses([spend, ...expenses]);
    }
  };

  // 6. STAFF HANDLERS
  const handleAddStaff = (stf: Staff) => {
    setStaff([stf, ...staff]);
  };

  const handleUpdateStaff = (stf: Staff) => {
    setStaff(staff.map(s => s.id === stf.id ? stf : s));
  };

  const handleDeleteStaff = (id: string) => {
    setStaff(staff.filter(s => s.id !== id));
  };

  const handleRecordStaffSalaryOrLoan = (staffId: string, type: 'salary' | 'advance', amount: number) => {
    setStaff(staff.map(s => {
      if (s.id === staffId) {
        if (type === 'advance') {
          return {
            ...s,
            advanceTaken: s.advanceTaken + amount
          };
        } else {
          // wage payout
          return {
            ...s,
            advanceTaken: Math.max(0, s.advanceTaken - amount)
          };
        }
      }
      return s;
    }));

    // Record as cash outlay/expense item
    const targetStf = staff.find(s => s.id === staffId);
    const stfName = targetStf ? targetStf.name : 'Employee';
    const wageExpense: Expense = {
      id: 'EXP-WAGE-' + Date.now().toString().slice(-4),
      title: type === 'advance' ? `Salary Advance paid to ${stfName}` : `Salary payout dispersed to ${stfName}`,
      amount: amount,
      category: 'Salary',
      date: new Date().toISOString().split('T')[0]
    };
    setExpenses([wageExpense, ...expenses]);
  };

  const handleUpdateStaffAttendance = (staffId: string, status: 'Present' | 'Absent' | 'Half-day' | 'Leave') => {
    setStaff(staff.map(s => {
      if (s.id === staffId) {
        return {
          ...s,
          attendanceToday: status
        };
      }
      return s;
    }));
  };


  // Navigation callbacks
  const handleQuickNavigation = (targetTab: string) => {
    setActiveTab(targetTab);
    setIsMobileMenuOpen(false);
  };

  // Roman Urdu/English translation dictionaries
  const sidebarNavLabels = {
    roman_urdu: {
      dashboard: "Dashboard",
      inventory: "Inventory (Maal List)",
      clients: "Grahak (Khata Book)",
      suppliers_staff: "Dealers & Staff Ledger 🚚",
      sales: "Billing (Naya Bill)",
      accountant: "Munim (Hisaab Kitaab)",
      social_hub: "Social Hub / WhatsApp Connect",
      aiAdvisor: "Siana AI Munim"
    },
    urdu: {
      dashboard: "ڈیش بورڈ",
      inventory: "اسٹاک اور مصنوعات",
      clients: "گاہک کھاتا بک",
      suppliers_staff: "ڈیلرز اور اسٹاف بک 🚚",
      sales: "انوائس اور فروخت",
      accountant: "حساب کتاب (اخراجات)",
      social_hub: "میڈیا اور واٹس ایپ",
      aiAdvisor: "ماہر محاسب (AI)"
    },
    english: {
      dashboard: "Dashboard Panel",
      inventory: "Inventory Manager",
      clients: "Clients Ledger Book",
      suppliers_staff: "Dealers & Staff Book 🚚",
      sales: "Create Retail Invoice",
      accountant: "General Ledger Logs",
      social_hub: "Social & WhatsApp Hub",
      aiAdvisor: "Siana AI Accountant"
    }
  }[language];

  return (
    <div className="min-h-screen bg-slate-50 font-sans text-slate-800 flex" id="main-erp-system">
      
      {/* A. DESKTOP PERMANENT SIDEBAR */}
      <aside className="hidden lg:flex flex-col justify-between w-64 bg-[#0f172a] text-slate-300 p-6 border-r border-slate-850 flex-shrink-0">
        <div className="space-y-8">
          
          {/* Main Title Head */}
          <div id="sidebar-header" className="flex items-center gap-3">
            <span className="p-2.5 bg-blue-600 text-white rounded-xl shadow-lg shadow-blue-900/50">
              <Calculator className="w-6 h-6 animate-pulse" />
            </span>
            <div>
              <h1 className="font-black text-white text-sm leading-none flex items-center gap-1">
                <span>Bhai Shop ERP</span>
              </h1>
              <span className="text-[10px] text-slate-500 font-mono font-medium block mt-1">Multi-Trade Ver-1.1</span>
            </div>
          </div>

          {/* Navigation link stacks */}
          <nav className="space-y-1.5 text-xs font-bold font-sans">
            
            <button 
              onClick={() => handleQuickNavigation('dashboard')}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200 ${
                activeTab === 'dashboard' ? 'bg-blue-600 text-white shadow-md shadow-blue-900/20' : 'hover:bg-slate-800/50 hover:text-white'
              }`}
            >
              <BarChart3 className="w-4.5 h-4.5" />
              <span>{sidebarNavLabels.dashboard}</span>
            </button>

            <button 
              onClick={() => handleQuickNavigation('inventory')}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200 ${
                activeTab === 'inventory' ? 'bg-blue-600 text-white shadow-md shadow-blue-900/20' : 'hover:bg-slate-800/50 hover:text-white'
              }`}
            >
              <Package className="w-4.5 h-4.5" />
              <span>{sidebarNavLabels.inventory}</span>
            </button>

            <button 
              onClick={() => handleQuickNavigation('clients')}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200 ${
                activeTab === 'clients' ? 'bg-blue-600 text-white shadow-md shadow-blue-900/20' : 'hover:bg-slate-800/50 hover:text-white'
              }`}
            >
              <Users className="w-4.5 h-4.5" />
              <span>{sidebarNavLabels.clients}</span>
            </button>

            <button 
              onClick={() => handleQuickNavigation('suppliers_staff')}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200 ${
                activeTab === 'suppliers_staff' ? 'bg-blue-600 text-white shadow-md shadow-blue-900/20' : 'hover:bg-slate-800/50 hover:text-white'
              }`}
            >
              <Truck className="w-4.5 h-4.5" />
              <span>{sidebarNavLabels.suppliers_staff}</span>
            </button>

            <button 
              onClick={() => handleQuickNavigation('sales')}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200 ${
                activeTab === 'sales' ? 'bg-blue-600 text-white shadow-md shadow-blue-900/20' : 'hover:bg-slate-800/50 hover:text-white'
              }`}
            >
              <ShoppingCart className="w-4.5 h-4.5" />
              <span>{sidebarNavLabels.sales}</span>
            </button>

            <button 
              onClick={() => handleQuickNavigation('accountant')}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200 ${
                activeTab === 'accountant' ? 'bg-blue-600 text-white shadow-md shadow-blue-900/20' : 'hover:bg-slate-800/50 hover:text-white'
              }`}
            >
              <Grid className="w-4.5 h-4.5" />
              <span>{sidebarNavLabels.accountant}</span>
            </button>

            <button 
              onClick={() => handleQuickNavigation('social_hub')}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200 ${
                activeTab === 'social_hub' ? 'bg-blue-600 text-white shadow-md shadow-blue-900/20' : 'hover:bg-slate-800/50 hover:text-white'
              }`}
            >
              <Share2 className="w-4.5 h-4.5" />
              <span>{sidebarNavLabels.social_hub}</span>
            </button>

            {/* Premium AI Advisor Trigger Tab */}
            <div className="border-t border-slate-800 pt-3 mt-3 relative">
              <button 
                onClick={() => handleQuickNavigation('ai_advisor')}
                className={`w-full flex items-center gap-3 px-4 py-3.5 rounded-xl bg-gradient-to-r transition-all duration-300 transform active:scale-98 ${
                  activeTab === 'ai_advisor' 
                    ? 'from-indigo-600 to-violet-700 text-white shadow-lg' 
                    : 'bg-white/5 hover:bg-white/10 text-indigo-300 font-extrabold shadow-sm'
                }`}
              >
                <Sparkles className="w-4.5 h-4.5 text-amber-400 animate-spin" />
                <span>{sidebarNavLabels.aiAdvisor}</span>
              </button>
            </div>

          </nav>
        </div>

        {/* Unified Quick language triggers */}
        <div className="bg-slate-900 p-4 border border-slate-800 rounded-2xl space-y-2">
          <span className="text-[9px] uppercase font-bold text-slate-500 tracking-wider block">Urdu Multi-language Toggles</span>
          <div className="grid grid-cols-3 gap-1 text-[9px] font-black text-center text-slate-400 font-mono">
            <button 
              onClick={() => setLanguage('roman_urdu')}
              className={`p-1.5 rounded transition ${language === 'roman_urdu' ? 'bg-blue-600 text-white font-extrabold' : 'hover:bg-slate-800 hover:text-white'}`}
            >
              ROMAN
            </button>
            <button 
              onClick={() => setLanguage('urdu')}
              className={`p-1.5 rounded transition ${language === 'urdu' ? 'bg-blue-600 text-white font-extrabold' : 'hover:bg-slate-800 hover:text-white'}`}
            >
              URDU
            </button>
            <button 
              onClick={() => setLanguage('english')}
              className={`p-1.5 rounded transition ${language === 'english' ? 'bg-blue-600 text-white font-extrabold' : 'hover:bg-slate-800 hover:text-white'}`}
            >
              ENG
            </button>
          </div>
        </div>

      </aside>

      {/* B. MAIN RIGHT STAGE VIEWPORT (Full fluid layouts) */}
      <main className="flex-1 flex flex-col min-w-0 overflow-y-auto max-h-screen">
        
        {/* 1. Global Navigation Top Header */}
        <header id="global-navigation-header" className="bg-white px-6 py-4 border-b border-slate-100 flex justify-between items-center sticky top-0 z-40 shadow-sm shadow-slate-100/40">
          
          <div className="flex items-center gap-3">
            {/* Mobile toggles */}
            <button 
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="lg:hidden p-2 text-slate-500 hover:bg-slate-100 rounded-xl"
            >
              {isMobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>

            <div>
              <h2 className="text-sm font-black text-slate-900 capitalize tracking-tight flex items-center gap-2">
                <span>{sidebarNavLabels[activeTab as keyof typeof sidebarNavLabels]}</span>
              </h2>
              <span className="text-[10px] text-slate-400 font-medium block mt-0.5">Assalam-o-Alaikum! Welcome to your digital ledger book.</span>
            </div>
          </div>

          <div className="flex items-center gap-4">
            
            {/* Realtime indicators */}
            <span className="hidden sm:inline-flex items-center gap-1.5 text-[10px] bg-emerald-50 text-emerald-700 font-bold px-2.5 py-1 rounded-full border border-emerald-100 uppercase">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-600 animate-ping"></span> Live Database Synced
            </span>

            {/* Quick action billing portal direct link */}
            <button 
              onClick={() => handleQuickNavigation('sales')}
              className="flex items-center gap-1 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white font-bold text-xs py-2 px-3.5 rounded-xl transition shadow active:scale-95"
            >
              <ShoppingCart className="w-3.5 h-3.5" />
              <span className="hidden md:inline">Sell (Naya Bill)</span>
            </button>

          </div>

        </header>

        {/* 2. Mobile Nav Drawer overlays */}
        {isMobileMenuOpen && (
          <div id="mobile-nav-panel animate-fade-in" className="lg:hidden fixed inset-l-0 top-16 right-0 left-0 bg-[#0f172a]/95 text-slate-300 p-6 z-40 border-b border-slate-800 space-y-6">
            <nav className="grid grid-cols-2 gap-3 text-xs font-bold whitespace-nowrap">
              <button onClick={() => handleQuickNavigation('dashboard')} className="p-3 bg-slate-850 block rounded-xl text-center active:bg-blue-600">Dashboard</button>
              <button onClick={() => handleQuickNavigation('inventory')} className="p-3 bg-slate-850 block rounded-xl text-center active:bg-blue-600">Inventory Items</button>
              <button onClick={() => handleQuickNavigation('clients')} className="p-3 bg-slate-850 block rounded-xl text-center active:bg-blue-600">Khata Book</button>
              <button onClick={() => handleQuickNavigation('suppliers_staff')} className="p-3 bg-slate-850 block rounded-xl text-center active:bg-blue-600">Dealers & Staff 🚚</button>
              <button onClick={() => handleQuickNavigation('sales')} className="p-3 bg-slate-850 block rounded-xl text-center active:bg-blue-600">Create Invoice</button>
              <button onClick={() => handleQuickNavigation('accountant')} className="p-3 bg-slate-850 block rounded-xl text-center active:bg-blue-600">General Ledger</button>
              <button onClick={() => handleQuickNavigation('social_hub')} className="p-3 bg-slate-850 block rounded-xl text-center active:bg-blue-600">Social Hub 📱</button>
              <button onClick={() => handleQuickNavigation('ai_advisor')} className="p-3 bg-gradient-to-r from-blue-600 to-violet-600 block rounded-xl text-center text-white col-span-2">Siana AI Munim</button>
            </nav>

            <div className="bg-slate-900 p-3 rounded-xl flex justify-between items-center">
              <span className="text-[9px] uppercase font-semibold text-slate-500">Urdu Dialect Translation:</span>
              <div className="flex gap-2 text-[9px] font-black font-mono">
                <button onClick={() => { setLanguage('roman_urdu'); setIsMobileMenuOpen(false); }} className={`p-1 px-2 rounded ${language==='roman_urdu'?'bg-blue-600 text-white':''}`}>ROMAN</button>
                <button onClick={() => { setLanguage('urdu'); setIsMobileMenuOpen(false); }} className={`p-1 px-2 rounded ${language==='urdu'?'bg-blue-600 text-white':''}`}>URDU</button>
                <button onClick={() => { setLanguage('english'); setIsMobileMenuOpen(false); }} className={`p-1 px-2 rounded ${language==='english'?'bg-blue-600 text-white':''}`}>ENG</button>
              </div>
            </div>
          </div>
        )}

        {/* 3. Main Stage tab Rendering Router */}
        <div className="flex-1 p-6 max-w-7xl w-full mx-auto">
          
          {activeTab === 'dashboard' && (
            <Dashboard 
              products={products}
              clients={clients}
              sales={sales}
              expenses={expenses}
              onNavigate={handleQuickNavigation}
              language={language}
            />
          )}

          {activeTab === 'inventory' && (
            <Inventory 
              products={products}
              categories={categories}
              onAddCategory={handleAddCategory}
              onDeleteCategory={handleDeleteCategory}
              onAddProduct={handleAddProduct}
              onUpdateProduct={handleUpdateProduct}
              onDeleteProduct={handleDeleteProduct}
              language={language}
            />
          )}

          {activeTab === 'social_hub' && (
            <SocialHub 
              products={products}
              clients={clients}
              sales={sales}
              language={language}
            />
          )}

          {activeTab === 'clients' && (
            <Clients 
              clients={clients}
              sales={sales}
              onAddClient={handleAddClient}
              onUpdateClient={handleUpdateClient}
              onDeleteClient={handleDeleteClient}
              onRecordClientPayment={handleRecordClientPayment}
              language={language}
            />
          )}

          {activeTab === 'suppliers_staff' && (
            <Suppliers 
              suppliers={suppliers}
              supplierBills={supplierBills}
              staff={staff}
              products={products}
              onAddSupplier={handleAddSupplier}
              onUpdateSupplier={handleUpdateSupplier}
              onDeleteSupplier={handleDeleteSupplier}
              onRecordSupplierPayment={handleRecordSupplierPayment}
              onRecordStockPurchase={handleRecordStockPurchase}
              onAddStaff={handleAddStaff}
              onUpdateStaff={handleUpdateStaff}
              onDeleteStaff={handleDeleteStaff}
              onRecordStaffSalaryOrLoan={handleRecordStaffSalaryOrLoan}
              onUpdateStaffAttendance={handleUpdateStaffAttendance}
              language={language}
            />
          )}

          {activeTab === 'sales' && (
            <Sales 
              products={products}
              clients={clients}
              sales={sales}
              onAddSale={handleAddSale}
              language={language}
            />
          )}

          {activeTab === 'accountant' && (
            <Accountant 
              expenses={expenses}
              sales={sales}
              onAddExpense={handleAddExpense}
              onDeleteExpense={handleDeleteExpense}
              language={language}
              onResetAllData={handleResetAllData}
            />
          )}

          {activeTab === 'ai_advisor' && (
            <AiAdvisor 
              products={products}
              clients={clients}
              sales={sales}
              expenses={expenses}
              language={language}
            />
          )}

        </div>

      </main>

    </div>
  );
}
