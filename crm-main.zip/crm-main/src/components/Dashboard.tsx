/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { 
  TrendingUp, 
  TrendingDown, 
  Users, 
  ShoppingBag, 
  AlertTriangle, 
  FileDown, 
  DollarSign, 
  Sparkles,
  ArrowUpRight,
  Calculator,
  Percent,
  Flame,
  Search,
  ThumbsUp,
  AlertCircle,
  Target
} from 'lucide-react';
import { Product, Client, Sale, Expense } from '../types';

interface DashboardProps {
  products: Product[];
  clients: Client[];
  sales: Sale[];
  expenses: Expense[];
  onNavigate: (tab: string) => void;
  language: 'roman_urdu' | 'urdu' | 'english';
}

export default function Dashboard({ 
  products, 
  clients, 
  sales, 
  expenses, 
  onNavigate,
  language 
}: DashboardProps) {

  // translations
  const t = {
    roman_urdu: {
      dailySales: "Aaj Ki Bikri (Daily Sales)",
      dailyProfit: "Aaj Ka Munafa (Daily Profit)",
      lowStockAlert: "Kam Stock Wala Maal",
      outstandingAmount: "Lena Udhaar (Receivable)",
      totalProducts: "Kul Maal (Products)",
      viewAll: "Sab Dekhein",
      salesTrend: "Bikri Ka Trend (Daily Sales)",
      profitTrend: "Munafa Ka Trend (Daily Profit)",
      quickSummary: "Karnama (Quick Summary)",
      alertStock: "Kam stock alert! Isay foran barhein.",
      alertKhata: "Khata barh gaya hai! In se rabta karein.",
      exportReports: "CSV Reports Export",
      exportSales: "Sales Record Export",
      exportInventory: "Stock List Export",
      exportClients: "Khata List Export",
      noSalesYet: "Abhi tak koi bikri nahi hai.",
      monthlySales: "Mahana Bikri (Monthly Sales)",
      netWorth: "Kul Sarmaya (Asset Value)",
      heatmapTitle: "Maal Ka Munafa Heatmap (Profit Margin Analytics)",
      heatmapDesc: "Har product ka munafa margin aur bachat level check karein",
      highMargin: "Shandar Munafa (>= 25%)",
      modMargin: "Behtar Munafa (15% - 24%)",
      lowMargin: "Kam Margin (1% - 14%)",
      negativeMargin: "Anomalous / Nuqsan (<= 0%)",
      searchProductPlaceholder: "Product ya category dhoondein...",
      showAll: "Saray Items",
      profitMarginText: "Margin",
      costText: "Kharid",
      saleText: "Becha",
      profitText: "Bachat",
      dailyTargetTitle: "Aaj Ki Bikri Ka Target (Daily Sales Target)",
      dailyTargetDesc: "Aaj dukan ke liye target revenue set karein aur behtreen andaz me progress dekhin.",
      setTargetButton: "Target Badlein",
      saveTargetButton: "Hifz (Save)",
      targetReached: "Mubarak ho! Aaj ka sales target poora ho gaya hai! 🎉",
      targetRemaining: "Target poora karne k liye mazeed Rs. {amount} ki sale chahiye.",
      targetSetPlaceholder: "Target amount likhein...",
      currentTargetText: "Aaj Ka Target",
      achievedText: "Hasil Shuda Sale"
    },
    urdu: {
      dailySales: "آج کی فروخت",
      dailyProfit: "آج کا منافع",
      lowStockAlert: "کم اسٹاک کا الرٹ",
      outstandingAmount: "بقایا رقم (ادھار)",
      totalProducts: "کل پروڈکٹس",
      viewAll: "سب دیکھیں",
      salesTrend: "فروخت کی کارکردگی",
      profitTrend: "منافع کی کارکردگی",
      quickSummary: "خلاصہ رپورٹ",
      alertStock: "کچھ اشیاء کا اسٹاک کم ہے۔ برائے مہربانی نیا آرڈر کریں!",
      alertKhata: "کھاتی داروں کا ادھار بڑھ گیا ہے۔",
      exportReports: "رپورٹس ڈاؤن لوڈ کریں",
      exportSales: "فروخت کی رپورٹ",
      exportInventory: "اسٹاک کی رپورٹ",
      exportClients: "گاہکوں کی رپورٹ",
      noSalesYet: "ابھی تک کوئی فروخت ریکارڈ نہیں ہوئی۔",
      monthlySales: "ماہانہ فروخت",
      netWorth: "کل سرمایہ کی قیمت",
      heatmapTitle: "پروڈکٹ کا منافع ہیٹ میپ",
      heatmapDesc: "ہر پروڈکٹ کا منافع مارجن اور بچت فیصد چیک کریں۔",
      highMargin: "شاندار منافع (>= 25%)",
      modMargin: "بہتر منافع (15% - 24%)",
      lowMargin: "کم ال مارجن (1% - 14%)",
      negativeMargin: "نقصان یا بغیر منافع (<= 0%)",
      searchProductPlaceholder: "پروڈکٹ یا زمرہ تلاش کریں...",
      showAll: "تمام آئٹمز",
      profitMarginText: "مارجن",
      costText: "خریداری",
      saleText: "فروخت",
      profitText: "منافع",
      dailyTargetTitle: "روزانہ کا فروخت ہدف",
      dailyTargetDesc: "کاروبار کے لیے آج کا ہدف سلیکٹ کریں اور لائیو کارکردگی مانیٹر کریں۔",
      setTargetButton: "ہدف تبدیل کریں",
      saveTargetButton: "محفوظ کریں",
      targetReached: "ماشاءاللہ! آج کا فروخت کا ہدف مکمل ہو چکا ہے! 🎉",
      targetRemaining: "ہدف تک پہنچنے کے لیے مزید Rs. {amount} درکار ہیں۔",
      targetSetPlaceholder: "روپے لکھیں...",
      currentTargetText: "آج کا ہدف",
      achievedText: "حاصل کردہ فروخت"
    },
    english: {
      dailySales: "Daily Sales",
      dailyProfit: "Daily Profit",
      lowStockAlert: "Low Stock Alert",
      outstandingAmount: "Outstanding Receivable",
      totalProducts: "Total Products",
      viewAll: "View All",
      salesTrend: "Sales Revenue Trend",
      profitTrend: "Gross Profit Trend",
      quickSummary: "Quick Summary",
      alertStock: "Low stock items detected! Order custom inventory soon.",
      alertKhata: "High outstanding client balances detected.",
      exportReports: "Export CSV Reports",
      exportSales: "Export Sales",
      exportInventory: "Export Inventory",
      exportClients: "Export Client Book",
      noSalesYet: "No sales recorded yet.",
      monthlySales: "Monthly Sales",
      netWorth: "Inventory Net Value",
      heatmapTitle: "Product Profitability Heatmap",
      heatmapDesc: "Analyze item-by-item profit margins to identify high-yield vs thin-margin retail goods",
      highMargin: "High Margin (>= 25%)",
      modMargin: "Moderate Margin (15% - 24%)",
      lowMargin: "Thin Margin (1% - 14%)",
      negativeMargin: "Zero/Negative Margin (<= 0%)",
      searchProductPlaceholder: "Search product or category...",
      showAll: "All Items",
      profitMarginText: "Margin",
      costText: "Buying Cost",
      saleText: "Selling Price",
      profitText: "Unit Profit",
      dailyTargetTitle: "Daily Sales Target Tracker",
      dailyTargetDesc: "Set your daily shop target and track progress in real-time as bills are paid.",
      setTargetButton: "Change Target",
      saveTargetButton: "Save Target",
      targetReached: "Congratulations! Today's sales target achieved! 🎉",
      targetRemaining: "Need Rs. {amount} more to hit today's milestone.",
      targetSetPlaceholder: "Target amount in Rs...",
      currentTargetText: "Today's Target",
      achievedText: "Achieved Sales"
    }
  }[language];

  // Helper dates
  const todayStr = new Date().toISOString().split('T')[0];

  // Heatmap UI States and Calculations
  const [heatmapFilter, setHeatmapFilter] = React.useState<'all' | 'high' | 'medium' | 'low' | 'negative'>('all');
  const [heatmapSearch, setHeatmapSearch] = React.useState('');

  // Daily Sales Target States
  const [dailyTarget, setDailyTarget] = React.useState<number>(() => {
    const saved = localStorage.getItem('bhai_erp_daily_target');
    return saved ? parseInt(saved, 10) : 15000; // default 15k Rs daily sales goal
  });
  const [isEditingTarget, setIsEditingTarget] = React.useState(false);
  const [tempTargetInput, setTempTargetInput] = React.useState(dailyTarget.toString());

  const handleSaveTarget = () => {
    const parsed = parseInt(tempTargetInput, 10);
    if (!isNaN(parsed) && parsed >= 0) {
      setDailyTarget(parsed);
      localStorage.setItem('bhai_erp_daily_target', parsed.toString());
      setIsEditingTarget(false);
    }
  };

  const productMargins = products.map(p => {
    const profit = p.sellingPrice - p.costPrice;
    const marginPercent = p.sellingPrice > 0 ? parseFloat(((profit / p.sellingPrice) * 100).toFixed(1)) : 0;
    
    // determine tier
    let tier: 'high' | 'medium' | 'low' | 'negative' = 'low';
    if (profit <= 0) {
      tier = 'negative';
    } else if (marginPercent >= 25) {
      tier = 'high';
    } else if (marginPercent >= 15) {
      tier = 'medium';
    } else {
      tier = 'low';
    }

    return {
      ...p,
      profit,
      marginPercent,
      tier
    };
  });

  const filteredHeatmap = productMargins.filter(p => {
    const matchesSearch = p.name.toLowerCase().includes(heatmapSearch.toLowerCase()) || 
                          p.category.toLowerCase().includes(heatmapSearch.toLowerCase());
    const matchesFilter = heatmapFilter === 'all' || p.tier === heatmapFilter;
    return matchesSearch && matchesFilter;
  });

  // Count tiers for stats indicator summary
  const tierCounts = productMargins.reduce((acc, curr) => {
    acc[curr.tier] = (acc[curr.tier] || 0) + 1;
    return acc;
  }, { high: 0, medium: 0, low: 0, negative: 0 } as Record<'high' | 'medium' | 'low' | 'negative', number>);

  // Calculations
  const todaySales = sales
    .filter(s => s.date === todayStr)
    .reduce((sum, s) => sum + s.totalAmount, 0);

  const todayProfit = sales
    .filter(s => s.date === todayStr)
    .reduce((sum, s) => sum + s.profit, 0);

  const totalOutstanding = clients.reduce((sum, c) => sum + (c.balance || 0), 0);
  const totalProductsCount = products.length;
  
  const lowStockItems = products.filter(p => p.stock <= p.minStockAlert);
  const highDebtClients = clients.filter(c => c.balance > 10000);

  const netAssetValue = products.reduce((sum, p) => sum + (p.costPrice * p.stock), 0);
  const totalProjectedRevenue = products.reduce((sum, p) => sum + (p.sellingPrice * p.stock), 0);

  // Group sales by day of the last 7 days for the beautiful SVG graph
  const getLast7Days = () => {
    const dates = [];
    for (let i = 6; i >= 0; i--) {
      const d = new Date();
      d.setDate(d.getDate() - i);
      dates.push(d.toISOString().split('T')[0]);
    }
    return dates;
  };

  const last7Days = getLast7Days();
  const salesGraphData = last7Days.map(date => {
    const daySales = sales.filter(s => s.date === date);
    const revenue = daySales.reduce((sum, s) => sum + s.totalAmount, 0);
    const profit = daySales.reduce((sum, s) => sum + s.profit, 0);
    
    // Formatting: e.g., "Jun 04" or weekday
    const parts = date.split('-');
    const label = `${parts[1]}/${parts[2]}`;
    return { date, label, revenue, profit };
  });

  const maxRevenue = Math.max(...salesGraphData.map(d => d.revenue), 1000);

  // Helper to trigger CSV downloading
  const downloadCSV = (filename: string, headers: string[], rows: string[][]) => {
    const csvContent = "data:text/csv;charset=utf-8,\uFEFF" 
      + [headers.join(","), ...rows.map(e => e.map(val => `"${val.replace(/"/g, '""')}"`).join(","))].join("\n");
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", filename);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleExportSales = () => {
    const headers = ["Invoice No", "Date", "Client Name", "Total Amount", "Discount", "Paid Amount", "Status", "Profit (Rs)"];
    const rows = sales.map(s => [
      s.invoiceNumber,
      s.date,
      s.clientName,
      s.totalAmount.toString(),
      s.discount.toString(),
      s.paidAmount.toString(),
      s.paymentStatus,
      s.profit.toString()
    ]);
    downloadCSV(`Sales_Report_${todayStr}.csv`, headers, rows);
  };

  const handleExportInventory = () => {
    const headers = ["Product ID", "Product Name", "Category", "Buying Cost (Cost Price)", "Sale Price (Selling Price)", "Stock in Hand", "Min stock alert"];
    const rows = products.map(p => [
      p.id,
      p.name,
      p.category,
      p.costPrice.toString(),
      p.sellingPrice.toString(),
      p.stock.toString(),
      p.minStockAlert.toString()
    ]);
    downloadCSV(`Inventory_Report_${todayStr}.csv`, headers, rows);
  };

  const handleExportClients = () => {
    const headers = ["Client ID", "Name", "Phone", "Address", "Outstanding Loan Balance (Khatabar)"];
    const rows = clients.map(c => [
      c.id,
      c.name,
      c.phone,
      c.address,
      c.balance.toString()
    ]);
    downloadCSV(`Khatabar_Book_${todayStr}.csv`, headers, rows);
  };

  const targetPercent = dailyTarget > 0 ? Math.min(100, Math.round((todaySales / dailyTarget) * 100)) : 0;
  const isTargetAchieved = todaySales >= dailyTarget && dailyTarget > 0;
  const remainingAmount = dailyTarget > todaySales ? dailyTarget - todaySales : 0;

  // Circular gauge config
  const radius = 45;
  const strokeWidth = 9;
  const circumference = 2 * Math.PI * radius; // approx 282.74
  const strokeDashoffset = circumference - (targetPercent / 100) * circumference;

  return (
    <div className="space-y-6" id="dashboard-tab">
      
      {/* 1. Header Alerts bar */}
      {(lowStockItems.length > 0 || totalOutstanding > 20000) && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {lowStockItems.length > 0 && (
            <div id="low-stock-alert" className="flex items-center gap-3 p-4 bg-amber-50 border border-amber-200 text-amber-800 rounded-xl">
              <AlertTriangle className="w-5 h-5 flex-shrink-0 animate-bounce text-amber-600" />
              <div className="text-sm">
                <span className="font-semibold block">{t.lowStockAlert} ({lowStockItems.length})</span>
                <span className="text-xs text-amber-700">{t.alertStock}</span>
              </div>
              <button 
                onClick={() => onNavigate('inventory')} 
                className="ml-auto text-xs font-semibold bg-amber-100 hover:bg-amber-200 text-amber-900 py-1 px-3 rounded-lg transition"
              >
                {t.viewAll}
              </button>
            </div>
          )}

          {totalOutstanding > 25000 && (
            <div id="high- khata-alert" className="flex items-center gap-3 p-4 bg-rose-50 border border-rose-200 text-rose-800 rounded-xl">
              <Users className="w-5 h-5 flex-shrink-0 text-rose-600" />
              <div className="text-sm">
                <span className="font-semibold block">{t.outstandingAmount} (Rs. {totalOutstanding.toLocaleString()})</span>
                <span className="text-xs text-rose-700">{t.alertKhata}</span>
              </div>
              <button 
                onClick={() => onNavigate('clients')} 
                className="ml-auto text-xs font-semibold bg-rose-100 hover:bg-rose-200 text-rose-900 py-1 px-3 rounded-lg transition"
              >
                {t.viewAll}
              </button>
            </div>
          )}
        </div>
      )}

      {/* 2. Top Numerical Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        
        {/* Daily Sales Card */}
        <div id="card-daily-sales" className="bg-white rounded-2xl p-5 border border-slate-100 hover:shadow-lg hover:shadow-slate-100 transition-all duration-300 relative overflow-hidden group">
          <div className="absolute top-0 right-0 w-24 h-24 bg-blue-50 rounded-full translate-x-8 -translate-y-8 group-hover:scale-110 transition-transform duration-500"></div>
          <div className="flex justify-between items-start relative z-10">
            <div>
              <p className="text-xs font-medium text-slate-500 tracking-wide uppercase">{t.dailySales}</p>
              <h3 className="text-3xl font-bold font-sans text-slate-800 mt-2">Rs. {todaySales.toLocaleString()}</h3>
              <p className="text-xs text-blue-600 font-medium mt-1 inline-flex items-center gap-1">
                <TrendingUp className="w-3.5 h-3.5" />
                <span>Today's Total Cash Inflow</span>
              </p>
            </div>
            <div className="bg-blue-500/10 text-blue-600 p-2.5 rounded-xl">
              <ShoppingBag className="w-6 h-6" />
            </div>
          </div>
        </div>

        {/* Daily Profit Card */}
        <div id="card-daily-profit" className="bg-white rounded-2xl p-5 border border-slate-100 hover:shadow-lg hover:shadow-slate-100 transition-all duration-300 relative overflow-hidden group">
          <div className="absolute top-0 right-0 w-24 h-24 bg-emerald-50 rounded-full translate-x-8 -translate-y-8 group-hover:scale-110 transition-transform duration-500"></div>
          <div className="flex justify-between items-start relative z-10">
            <div>
              <p className="text-xs font-medium text-slate-500 tracking-wide uppercase">{t.dailyProfit}</p>
              <h3 className="text-3xl font-bold font-sans text-emerald-600 mt-2">Rs. {todayProfit.toLocaleString()}</h3>
              <p className={`text-xs ${todayProfit >= 0 ? 'text-emerald-600' : 'text-rose-600'} font-medium mt-1 inline-flex items-center gap-1`}>
                <Sparkles className="w-3.5 h-3.5" />
                <span>Today's Margins ({todaySales > 0 ? Math.round((todayProfit / todaySales) * 100) : 0}%)</span>
              </p>
            </div>
            <div className="bg-emerald-500/10 text-emerald-600 p-2.5 rounded-xl">
              <DollarSign className="w-6 h-6" />
            </div>
          </div>
        </div>

        {/* Total Client outstanding receivables khata */}
        <div id="card-outstanding" className="bg-white rounded-2xl p-5 border border-slate-100 hover:shadow-lg hover:shadow-slate-100 transition-all duration-300 relative overflow-hidden group">
          <div className="absolute top-0 right-0 w-24 h-24 bg-rose-50 rounded-full translate-x-8 -translate-y-8 group-hover:scale-110 transition-transform duration-500"></div>
          <div className="flex justify-between items-start relative z-10">
            <div>
              <p className="text-xs font-medium text-slate-500 tracking-wide uppercase">{t.outstandingAmount}</p>
              <h3 className="text-3xl font-bold font-sans text-slate-800 mt-2">Rs. {totalOutstanding.toLocaleString()}</h3>
              <p className="text-xs text-rose-600 font-medium mt-1 inline-flex items-center gap-1" onClick={() => onNavigate('clients')}>
                <Users className="w-3.5 h-3.5" />
                <span className="cursor-pointer hover:underline">Total Khata Book Debtors</span>
              </p>
            </div>
            <div className="bg-rose-500/10 text-rose-600 p-2.5 rounded-xl">
              <Users className="w-6 h-6" />
            </div>
          </div>
        </div>

        {/* Net Asset Worth Store Inventory value valuation */}
        <div id="card-net-worth" className="bg-white rounded-2xl p-5 border border-slate-100 hover:shadow-lg hover:shadow-slate-100 transition-all duration-300 relative overflow-hidden group">
          <div className="absolute top-0 right-0 w-24 h-24 bg-violet-50 rounded-full translate-x-8 -translate-y-8 group-hover:scale-110 transition-transform duration-500"></div>
          <div className="flex justify-between items-start relative z-10">
            <div>
              <p className="text-xs font-medium text-slate-500 tracking-wide uppercase">{t.netWorth}</p>
              <h3 className="text-3xl font-bold font-sans text-slate-800 mt-2">Rs. {netAssetValue.toLocaleString()}</h3>
              <p className="text-xs text-violet-600 font-medium mt-1 inline-flex items-center gap-1">
                <Calculator className="w-3.5 h-3.5" />
                <span>Estimated Sale: Rs. {totalProjectedRevenue.toLocaleString()}</span>
              </p>
            </div>
            <div className="bg-violet-500/10 text-violet-600 p-2.5 rounded-xl">
              <ShoppingBag className="w-6 h-6" />
            </div>
          </div>
        </div>

      </div>

      {/* Daily Sales Target Tracker Gauge */}
      <div id="daily-sales-target-section" className="bg-white rounded-2xl p-6 border border-slate-100 shadow-sm space-y-6">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
          <div className="space-y-1">
            <h3 className="font-semibold text-slate-800 text-lg flex items-center gap-2">
              <Target className="w-5.5 h-5.5 text-blue-600 animate-pulse" />
              <span>{t.dailyTargetTitle}</span>
            </h3>
            <p className="text-xs text-slate-500">{t.dailyTargetDesc}</p>
          </div>

          <div className="flex items-center gap-2 shrink-0 w-full sm:w-auto">
            {isEditingTarget ? (
              <div className="flex items-center gap-2 w-full sm:w-auto">
                <input
                  type="number"
                  placeholder={t.targetSetPlaceholder}
                  value={tempTargetInput}
                  onChange={(e) => setTempTargetInput(e.target.value)}
                  className="px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold w-full sm:w-28 text-slate-700 outline-none focus:border-blue-500"
                />
                <button
                  onClick={handleSaveTarget}
                  className="px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-xs font-bold transition active:scale-95 cursor-pointer whitespace-nowrap"
                >
                  {t.saveTargetButton}
                </button>
                <button
                  onClick={() => {
                    setIsEditingTarget(false);
                    setTempTargetInput(dailyTarget.toString());
                  }}
                  className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-600 rounded-lg text-xs font-bold transition active:scale-95 cursor-pointer"
                >
                  Cancel
                </button>
              </div>
            ) : (
              <button
                onClick={() => setIsEditingTarget(true)}
                className="w-full sm:w-auto flex items-center justify-center gap-2 px-4 py-2 bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-xl text-xs font-bold text-slate-700 transition active:scale-95 cursor-pointer"
              >
                <Target className="w-4 h-4 text-blue-500" />
                <span>{t.setTargetButton}</span>
              </button>
            )}
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 items-center">
          
          {/* Circular SVG Gauge (1/4 width) */}
          <div className="flex justify-center items-center py-2 md:border-r border-slate-100">
            <div className="relative w-36 h-36 flex items-center justify-center">
              <svg className="w-full h-full transform -rotate-90">
                {/* Background track circle */}
                <circle
                  cx="72"
                  cy="72"
                  r={radius}
                  className="text-slate-100"
                  strokeWidth={strokeWidth}
                  stroke="currentColor"
                  fill="transparent"
                />
                {/* Visual completion arc */}
                <circle
                  cx="72"
                  cy="72"
                  r={radius}
                  className={`${isTargetAchieved ? 'text-emerald-500' : 'text-blue-500'} transition-all duration-1000 ease-out`}
                  strokeWidth={strokeWidth}
                  strokeDasharray={circumference}
                  strokeDashoffset={strokeDashoffset}
                  strokeLinecap="round"
                  stroke="currentColor"
                  fill="transparent"
                />
              </svg>
              
              {/* Inner absolute content */}
              <div className="absolute text-center space-y-0.5">
                <span className={`text-2xl font-black font-sans block ${isTargetAchieved ? 'text-emerald-600' : 'text-blue-600'}`}>
                  {targetPercent}%
                </span>
                <span className="text-[10px] uppercase font-black text-slate-400 tracking-wider">
                  {language === 'english' ? 'Progress' : language === 'urdu' ? 'کارکردگی' : 'Karkardagi'}
                </span>
              </div>
            </div>
          </div>

          {/* Detailed statistics metrics (3/4 width) */}
          <div className="md:col-span-3 space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              
              {/* Box 1: Target value */}
              <div className="p-4 bg-slate-50/70 border border-slate-100 rounded-2xl">
                <span className="text-[10px] uppercase font-black text-slate-400 block tracking-wider">{t.currentTargetText}</span>
                <h4 className="text-xl font-bold font-sans text-slate-700 mt-1">Rs. {dailyTarget.toLocaleString()}</h4>
              </div>

              {/* Box 2: Achieved sales value */}
              <div className="p-4 bg-slate-50/70 border border-slate-100 rounded-2xl">
                <span className="text-[10px] uppercase font-black text-slate-400 block tracking-wider">{t.achievedText}</span>
                <h4 className="text-xl font-bold font-sans text-slate-800 mt-1">Rs. {todaySales.toLocaleString()}</h4>
              </div>

              {/* Box 3: Remaining target */}
              <div className="p-4 bg-slate-50/70 border border-slate-100 rounded-2xl">
                <span className="text-[10px] uppercase font-black text-slate-400 block tracking-wider">
                  {language === 'english' ? 'Remaining Gap' : language === 'urdu' ? 'باقی ہدف' : 'Baqi Target'}
                </span>
                <h4 className={`text-xl font-bold font-sans mt-1 ${isTargetAchieved ? 'text-emerald-600' : 'text-slate-800'}`}>
                  Rs. {remainingAmount.toLocaleString()}
                </h4>
              </div>

            </div>

            {/* Micro-bar visual timeline backup description */}
            <div className="space-y-2">
              <div className="w-full bg-slate-100 rounded-full h-3.5 overflow-hidden p-0.5 border border-slate-200/50">
                <div 
                  className={`h-full rounded-full transition-all duration-1000 ease-out ${
                    isTargetAchieved 
                      ? 'bg-gradient-to-r from-emerald-500 to-teal-500 shadow-sm shadow-emerald-500/10' 
                      : 'bg-gradient-to-r from-blue-500 to-sky-500 shadow-sm shadow-blue-500/10'
                  }`}
                  style={{ width: `${targetPercent}%` }}
                ></div>
              </div>

              {/* Reward feedback or progress instructions notification */}
              {isTargetAchieved ? (
                <div className="p-3 bg-emerald-50/60 border border-emerald-100 text-emerald-800 rounded-xl text-xs font-bold flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-emerald-500 animate-spin" />
                  <span>{t.targetReached}</span>
                </div>
              ) : (
                <div className="p-3 bg-blue-50/60 border border-blue-100 text-blue-800 rounded-xl text-xs font-bold flex items-center gap-2">
                  <Target className="w-4 h-4 text-blue-500" />
                  <span>
                    {t.targetRemaining.replace('{amount}', remainingAmount.toLocaleString())}
                  </span>
                </div>
              )}
            </div>

          </div>

        </div>
      </div>

      {/* 3. Graphical Trends and Analytics Section using handcrafted SVG charts for perfect React 19 compatibility and stunning look */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">

        {/* Sales Daily Revenue Trends (2/3 width) */}
        <div id="sales-trend-graph" className="lg:col-span-2 bg-white rounded-2xl p-6 border border-slate-100 shadow-sm">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
            <div>
              <h3 className="font-semibold text-slate-800 text-lg">{t.salesTrend}</h3>
              <p className="text-xs text-slate-500">Bite bar bar (7 days record of revenue and gross profits)</p>
            </div>
            <div className="flex items-center gap-4 text-xs font-medium">
              <span className="flex items-center gap-1.5"><span className="w-3 h-3 bg-blue-500 rounded-sm"></span>Revenue</span>
              <span className="flex items-center gap-1.5"><span className="w-3 h-3 bg-emerald-500 rounded-sm"></span>Profit</span>
            </div>
          </div>

          {/* SVG Graph rendering area */}
          <div className="relative h-64 w-full">
            <svg viewBox="0 0 500 240" className="w-full h-full" preserveAspectRatio="none">
              
              {/* Grid Lines */}
              <line x1="40" y1="30" x2="480" y2="30" stroke="#f1f5f9" strokeWidth="1" />
              <line x1="40" y1="80" x2="480" y2="80" stroke="#f1f5f9" strokeWidth="1" />
              <line x1="40" y1="130" x2="480" y2="130" stroke="#f1f5f9" strokeWidth="1" />
              <line x1="40" y1="180" x2="480" y2="180" stroke="#e2e8f0" strokeWidth="1" />

              {/* Day Coordinates Graph Columns */}
              {salesGraphData.map((d, idx) => {
                const x = 55 + idx * 60;
                
                // Max height mapped to 150px (leaving paddings)
                const revenueHeight = maxRevenue > 0 ? (d.revenue / maxRevenue) * 140 : 0;
                const profitHeight = maxRevenue > 0 ? (d.profit / maxRevenue) * 140 : 0;
                
                const revenueY = 180 - revenueHeight;
                const profitY = 180 - profitHeight;

                return (
                  <g key={d.date} className="group cursor-pointer">
                    {/* Background hover highlights */}
                    <rect x={x - 12} y="15" width="40" height="180" fill="transparent" className="hover:fill-slate-50/50 transition-colors" />

                    {/* Revenue Bar */}
                    <rect 
                      x={x - 8} 
                      y={revenueY} 
                      width="12" 
                      height={revenueHeight} 
                      fill="#3b82f6" 
                      rx="3" 
                      className="transition-all duration-700" 
                    />

                    {/* Profit Bar */}
                    <rect 
                      x={x + 6} 
                      y={profitY} 
                      width="12" 
                      height={profitHeight} 
                      fill="#10b981" 
                      rx="3" 
                      className="transition-all duration-700" 
                    />

                    {/* Text values visible on hover or compact */}
                    {d.revenue > 0 && (
                      <text x={x + 5} y={revenueY - 6} textAnchor="middle" fontSize="8" fontWeight="600" fill="#1e40af">{Math.round(d.revenue / 1000)}k</text>
                    )}

                    {/* X-Axis labels (Date label) */}
                    <text x={x + 5} y="200" textAnchor="middle" fontSize="10" fontWeight="500" fill="#64748b" className="font-sans">
                      {d.label}
                    </text>
                  </g>
                );
              })}

              {/* Zero baseline */}
              <line x1="40" y1="180" x2="480" y2="180" stroke="#94a3b8" strokeWidth="1.5" />
            </svg>
            
            {/* Edge Indicators for visual graph guide */}
            <div className="absolute top-1 right-2 flex items-center gap-1.5 px-2 py-1 bg-slate-50 text-[10px] text-slate-500 rounded font-mono border border-slate-100">
              <ArrowUpRight className="w-3 h-3 text-blue-500" />
              Maximize: Rs. {maxRevenue.toLocaleString()}
            </div>
          </div>
          
          <div className="mt-2 flex justify-between items-center text-xs text-slate-400 border-t border-slate-100 pt-4">
            <span>* Figures shown in PKR (Rs). Graph scales automatically up to maximum daily sales limit.</span>
            <button onClick={() => onNavigate('sales')} className="text-blue-600 hover:underline flex items-center gap-1 font-semibold">
              Create Invoice <ArrowUpRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Export / Quick Control Panel (1/3 width) */}
        <div id="quick-control-card" className="bg-white rounded-2xl p-6 border border-slate-100 shadow-sm flex flex-col justify-between">
          <div>
            <h3 className="font-semibold text-slate-800 text-lg mb-4">{t.exportReports}</h3>
            <p className="text-xs text-slate-500 mb-6">Apnay business ka tamam data CSV sheets format me download karein taakay Excel ya mobile par asani se khol sakein.</p>
            
            <div className="space-y-3">
              <button 
                onClick={handleExportSales}
                disabled={sales.length === 0}
                className="w-full flex items-center justify-between p-3.5 bg-slate-50 hover:bg-slate-100 border border-slate-100 rounded-xl text-xs font-semibold text-slate-700 transition active:scale-98 disabled:opacity-50"
              >
                <span className="flex items-center gap-2.5">
                  <span className="w-2 h-2 rounded-full bg-blue-500"></span>
                  {t.exportSales}
                </span>
                <span className="flex items-center gap-1.5 text-slate-400">
                  <span className="text-[10px] bg-sky-100 text-sky-800 px-1.5 py-0.5 rounded font-mono font-medium">{sales.length} records</span>
                  <FileDown className="w-4 h-4" />
                </span>
              </button>

              <button 
                onClick={handleExportInventory}
                disabled={products.length === 0}
                className="w-full flex items-center justify-between p-3.5 bg-slate-50 hover:bg-slate-100 border border-slate-100 rounded-xl text-xs font-semibold text-slate-700 transition active:scale-98 disabled:opacity-50"
              >
                <span className="flex items-center gap-2.5">
                  <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
                  {t.exportInventory}
                </span>
                <span className="flex items-center gap-1.5 text-slate-400">
                  <span className="text-[10px] bg-emerald-100 text-emerald-800 px-1.5 py-0.5 rounded font-mono font-medium">{products.length} types</span>
                  <FileDown className="w-4 h-4" />
                </span>
              </button>

              <button 
                onClick={handleExportClients}
                disabled={clients.length === 0}
                className="w-full flex items-center justify-between p-3.5 bg-slate-50 hover:bg-slate-100 border border-slate-100 rounded-xl text-xs font-semibold text-slate-700 transition active:scale-98 disabled:opacity-50"
              >
                <span className="flex items-center gap-2.5">
                  <span className="w-2 h-2 rounded-full bg-amber-500"></span>
                  {t.exportClients}
                </span>
                <span className="flex items-center gap-1.5 text-slate-400">
                  <span className="text-[10px] bg-amber-100 text-amber-800 px-1.5 py-0.5 rounded font-mono font-medium">{clients.length} clients</span>
                  <FileDown className="w-4 h-4" />
                </span>
              </button>
            </div>
          </div>

          <div className="mt-8 bg-blue-50 border border-blue-100 rounded-2xl p-4 flex gap-3 items-start">
            <span className="p-2 bg-blue-600 text-white rounded-lg"><Sparkles className="w-4 h-4 animate-pulse" /></span>
            <div>
              <h4 className="text-xs font-bold text-blue-900">Roman Urdu AI Advisor!</h4>
              <p className="text-[11px] text-blue-700 mt-0.5">Siana AI Munim se apne dukan ke munafay ki report aur stock analysis karwayein!</p>
              <button 
                onClick={() => onNavigate('ai_advisor')}
                className="mt-2 text-xs font-bold text-blue-900 hover:underline flex items-center gap-1"
              >
                Open AI Advisor <Sparkles className="w-3.5 h-3.5 animate-spin text-amber-500" />
              </button>
            </div>
          </div>
        </div>

      </div>

      {/* Profitability Heatmap Visual Segment */}
      <div id="profitability-heatmap" className="bg-white rounded-2xl p-6 border border-slate-100 shadow-sm space-y-6">
        
        {/* Header & Controls Row */}
        <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-4 border-b border-slate-100 pb-5">
          <div className="space-y-1">
            <h3 className="font-semibold text-slate-800 text-lg flex items-center gap-2">
              <Flame className="w-5 h-5 text-amber-500 animate-pulse" />
              <span>{t.heatmapTitle}</span>
            </h3>
            <p className="text-xs text-slate-500">{t.heatmapDesc}</p>
          </div>

          {/* Interactive filter & search controls */}
          <div className="flex flex-wrap items-center gap-3 w-full lg:w-auto">
            {/* Search Input block */}
            <div className="relative flex-1 lg:flex-initial">
              <span className="absolute inset-y-0 left-3 flex items-center text-slate-400">
                <Search className="w-4 h-4" />
              </span>
              <input
                type="text"
                value={heatmapSearch}
                onChange={(e) => setHeatmapSearch(e.target.value)}
                placeholder={t.searchProductPlaceholder}
                className="w-full lg:w-52 pl-9 pr-3 py-2 bg-slate-50 border border-slate-200/80 rounded-xl text-xs font-semibold text-slate-700 outline-none focus:border-blue-500 transition-colors"
              />
            </div>

            {/* Heatmap level filters */}
            <div className="flex p-1 bg-slate-50 border border-slate-200/60 rounded-xl text-xs font-bold gap-1 w-full lg:w-auto overflow-x-auto">
              <button
                onClick={() => setHeatmapFilter('all')}
                className={`px-3 py-1.5 rounded-lg whitespace-nowrap transition cursor-pointer ${
                  heatmapFilter === 'all' 
                    ? 'bg-white text-slate-800 shadow-sm' 
                    : 'text-slate-500 hover:text-slate-800'
                }`}
              >
                {t.showAll} ({products.length})
              </button>
              <button
                onClick={() => setHeatmapFilter('high')}
                className={`px-3 py-1.5 rounded-lg whitespace-nowrap transition cursor-pointer flex items-center gap-1.5 ${
                  heatmapFilter === 'high' 
                    ? 'bg-emerald-600 text-white shadow-sm' 
                    : 'text-emerald-700 hover:bg-emerald-50'
                }`}
              >
                <Flame className="w-3.5 h-3.5" />
                <span>{language === 'english' ? 'High' : language === 'urdu' ? 'شاندار' : 'Shandar'}</span> 
                <span className="opacity-80 font-mono text-[10px]">({tierCounts.high})</span>
              </button>
              <button
                onClick={() => setHeatmapFilter('medium')}
                className={`px-3 py-1.5 rounded-lg whitespace-nowrap transition cursor-pointer flex items-center gap-1.5 ${
                  heatmapFilter === 'medium' 
                    ? 'bg-blue-600 text-white shadow-sm' 
                    : 'text-blue-700 hover:bg-blue-50'
                }`}
              >
                <ThumbsUp className="w-3.5 h-3.5" />
                <span>{language === 'english' ? 'Moderate' : language === 'urdu' ? 'بہتر' : 'Behtar'}</span>
                <span className="opacity-80 font-mono text-[10px]">({tierCounts.medium})</span>
              </button>
              <button
                onClick={() => setHeatmapFilter('low')}
                className={`px-3 py-1.5 rounded-lg whitespace-nowrap transition cursor-pointer flex items-center gap-1.5 ${
                  heatmapFilter === 'low' 
                    ? 'bg-amber-500 text-white shadow-sm' 
                    : 'text-amber-700 hover:bg-amber-50'
                }`}
              >
                <AlertTriangle className="w-3.5 h-3.5" />
                <span>{language === 'english' ? 'Thin' : language === 'urdu' ? 'کم' : 'Kam'}</span>
                <span className="opacity-80 font-mono text-[10px]">({tierCounts.low})</span>
              </button>
              <button
                onClick={() => setHeatmapFilter('negative')}
                className={`px-3 py-1.5 rounded-lg whitespace-nowrap transition cursor-pointer flex items-center gap-1.5 ${
                  heatmapFilter === 'negative' 
                    ? 'bg-rose-600 text-white shadow-sm' 
                    : 'text-rose-700 hover:bg-rose-50'
                }`}
              >
                <AlertCircle className="w-3.5 h-3.5" />
                <span>{language === 'english' ? 'Zero/Negative' : language === 'urdu' ? 'نقصان' : 'Nuqsan/Zero'}</span>
                <span className="opacity-80 font-mono text-[10px]">({tierCounts.negative})</span>
              </button>
            </div>
          </div>
        </div>

        {/* Heatmap Layout Density Grid */}
        {filteredHeatmap.length === 0 ? (
          <div className="text-center py-10 bg-slate-50/50 border border-dashed border-slate-100 rounded-2xl text-xs font-bold text-slate-400">
            {language === 'english' ? 'No products match the selected profitability criteria.' : 'Is criteria k mutabiq koi product nahi mila.'}
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {filteredHeatmap.map(p => {
              // Color variables depending on tier
              const colorConfig = {
                high: {
                  badge: 'bg-emerald-50 text-emerald-800 border border-emerald-200/50',
                  badgeText: language === 'english' ? 'High' : language === 'urdu' ? 'شاندار' : 'Shandar',
                  borderL: 'border-l-4 border-l-emerald-500',
                  progressBg: 'bg-emerald-500',
                  glow: 'shadow-emerald-500/5'
                },
                medium: {
                  badge: 'bg-blue-50 text-blue-800 border border-blue-200/50',
                  badgeText: language === 'english' ? 'Moderate' : language === 'urdu' ? 'بہتر' : 'Behtar',
                  borderL: 'border-l-4 border-l-blue-500',
                  progressBg: 'bg-blue-500',
                  glow: 'shadow-blue-500/5'
                },
                low: {
                  badge: 'bg-amber-50 text-amber-800 border border-amber-200/50',
                  badgeText: language === 'english' ? 'Thin' : language === 'urdu' ? 'کم' : 'Kam',
                  borderL: 'border-l-4 border-l-amber-500',
                  progressBg: 'bg-amber-500',
                  glow: 'shadow-amber-500/5'
                },
                negative: {
                  badge: 'bg-rose-50 text-rose-800 border border-rose-200',
                  badgeText: language === 'english' ? 'Nuqsan/Zero' : language === 'urdu' ? 'نقصان' : 'Nuqsan/Zero',
                  borderL: 'border-l-4 border-l-rose-500',
                  progressBg: 'bg-rose-500',
                  glow: 'shadow-rose-500/5'
                }
              }[p.tier];

              return (
                <div 
                  key={p.id}
                  className={`bg-white hover:bg-slate-50 border border-slate-100/80 rounded-2xl p-4 flex flex-col justify-between transition-all duration-300 hover:shadow-md ${colorConfig.borderL}`}
                >
                  <div className="space-y-3">
                    {/* Compact Image or Placeholder + Tier Pill */}
                    <div className="flex justify-between items-start gap-2">
                      <div className="flex items-center gap-2">
                        {p.image ? (
                          <img 
                            src={p.image} 
                            alt={p.name} 
                            className="w-8 h-8 rounded-lg object-cover border border-slate-100 shrink-0" 
                            referrerPolicy="no-referrer"
                          />
                        ) : (
                          <span className="w-8 h-8 bg-slate-50 border border-slate-200 text-slate-400 rounded-lg flex items-center justify-center font-black text-[10px] shrink-0 font-sans">
                            {p.name.charAt(0).toUpperCase()}
                          </span>
                        )}
                        <div className="min-w-0">
                          <h4 className="font-bold text-slate-800 text-xs truncate leading-snug">{p.name}</h4>
                          <span className="text-[10px] text-slate-400 font-bold block truncate">{p.category}</span>
                        </div>
                      </div>
                    </div>

                    {/* Numeric breakdown details */}
                    <div className="grid grid-cols-2 gap-2 text-[10px] font-bold text-slate-500 bg-slate-50 p-2.5 rounded-xl border border-slate-100">
                      <div>
                        <span className="text-[9px] uppercase font-black text-slate-400 block tracking-wider">{t.costText}</span>
                        <span className="text-slate-700 font-mono">Rs.{p.costPrice.toLocaleString()}</span>
                      </div>
                      <div>
                        <span className="text-[9px] uppercase font-black text-slate-400 block tracking-wider">{t.saleText}</span>
                        <span className="text-slate-900 font-mono">Rs.{p.sellingPrice.toLocaleString()}</span>
                      </div>
                    </div>

                    {/* Profit Margin scale bar and calculations */}
                    <div className="space-y-1.5 pt-1">
                      <div className="flex justify-between text-[11px] font-extrabold">
                        <span className="text-slate-400 flex items-center gap-0.5">
                          <Percent className="w-3.5 h-3.5 text-slate-400" />
                          <span>{t.profitMarginText}</span>
                        </span>
                        <span className={p.profit > 0 ? "text-slate-800" : "text-rose-600"}>
                          {p.marginPercent}%
                        </span>
                      </div>

                      {/* Stacked comparison bar */}
                      <div className="w-full bg-slate-100 rounded-full h-2 overflow-hidden flex">
                        {p.profit > 0 ? (
                          <>
                            {/* Buying Cost share */}
                            <div 
                              className="bg-slate-200 h-full" 
                              style={{ width: `${Math.max(10, Math.min(90, 100 - p.marginPercent))}%` }}
                              title={`${t.costText}: Rs. ${p.costPrice}`}
                            ></div>
                            {/* Yield Profit Margin share */}
                            <div 
                              className={`${colorConfig.progressBg} h-full`} 
                              style={{ width: `${Math.max(10, Math.min(90, p.marginPercent))}%` }}
                              title={`${t.profitText}: Rs. ${p.profit}`}
                            ></div>
                          </>
                        ) : (
                          <div className="bg-rose-500 w-full h-full" title="No Margin / Negative Margin"></div>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Absolute Card Footer representing tier and unit yield profit status */}
                  <div className="mt-3.5 pt-3 border-t border-slate-100 flex items-center justify-between text-[11px] font-bold">
                    <span className={`px-2 py-0.5 rounded-md text-[9px] font-extrabold uppercase tracking-wider ${colorConfig.badge}`}>
                      {colorConfig.badgeText}
                    </span>
                    <span className={`font-mono font-black ${p.profit > 0 ? 'text-emerald-700' : 'text-rose-700'}`}>
                      {p.profit >= 0 ? '+' : ''}Rs.{p.profit.toLocaleString()}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {/* Heatmap intensity color legend scale */}
        <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-4 pt-1 text-[10px] font-semibold text-slate-400 bg-slate-50/50 p-4 rounded-xl border border-slate-100">
          <div className="flex flex-wrap items-center gap-x-2 gap-y-1">
            <span className="w-2 rounded-full h-2 bg-emerald-500"></span>
            <span>{t.highMargin}</span>
            <span className="text-slate-300 font-normal">|</span>
            <span className="w-2 rounded-full h-2 bg-blue-500"></span>
            <span>{t.modMargin}</span>
            <span className="text-slate-300 font-normal">|</span>
            <span className="w-2 rounded-full h-2 bg-amber-500"></span>
            <span>{t.lowMargin}</span>
            <span className="text-slate-300 font-normal">|</span>
            <span className="w-2 rounded-full h-2 bg-rose-500"></span>
            <span>{t.negativeMargin}</span>
          </div>

          <span>* Profit Margin is calculated as: ((Sale Price - Cost Price) / Sale Price) * 100</span>
        </div>

      </div>

      {/* 4. Recent Transactions & Low Stock Table Row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* Recent Invoices list */}
        <div id="recent-invoices" className="bg-white rounded-2xl p-6 border border-slate-100 shadow-sm">
          <div className="flex justify-between items-center mb-4">
            <div>
              <h3 className="font-semibold text-slate-800 text-base">Haliya Invoice Records (Recent Sales)</h3>
              <p className="text-xs text-slate-500">Halia bechey gae invoices ki fehrist</p>
            </div>
            <button onClick={() => onNavigate('sales')} className="text-xs text-blue-600 font-semibold hover:underline border border-blue-100 px-2.5 py-1 rounded-lg">
              {t.viewAll}
            </button>
          </div>

          {sales.length === 0 ? (
            <div className="text-center py-8 text-xs text-slate-400 font-medium">
              {t.noSalesYet}
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="border-b border-slate-100 text-slate-400 font-semibold">
                    <th className="py-2.5">Invoice #</th>
                    <th className="py-2.5">Customer</th>
                    <th className="py-2.5">Total Amount</th>
                    <th className="py-2.5">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-50">
                  {sales.slice(0, 5).map(sale => (
                    <tr key={sale.id} className="text-slate-700 font-medium hover:bg-slate-50 transition-colors">
                      <td className="py-2.5 font-mono text-slate-900">{sale.invoiceNumber}</td>
                      <td className="py-2.5 max-w-[120px] truncate">{sale.clientName}</td>
                      <td className="py-2.5 font-bold">Rs. {sale.totalAmount.toLocaleString()}</td>
                      <td className="py-2.5">
                        <span className={`inline-block px-1.5 py-0.5 rounded-full text-[10px] font-bold ${
                          sale.paymentStatus === 'Paid' ? 'bg-emerald-50 text-emerald-700' :
                          sale.paymentStatus === 'Partially Paid' ? 'bg-amber-50 text-amber-700' :
                          'bg-rose-50 text-rose-700'
                        }`}>
                          {sale.paymentStatus}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>

        {/* Low inventory product details */}
        <div id="low-inventory-details" className="bg-white rounded-2xl p-6 border border-slate-100 shadow-sm">
          <div className="flex justify-between items-center mb-4">
            <div>
              <h3 className="font-semibold text-slate-800 text-base">Kam Maal List (Low Stock Warnings)</h3>
              <p className="text-xs text-slate-500">In products ko jald dukan m order karein</p>
            </div>
            <button onClick={() => onNavigate('inventory')} className="text-xs text-blue-600 font-semibold hover:underline border border-blue-100 px-2.5 py-1 rounded-lg">
              {t.viewAll}
            </button>
          </div>

          {lowStockItems.length === 0 ? (
            <div className="text-center py-8 text-xs text-emerald-600 bg-emerald-50 rounded-xl font-medium">
              Mubarak! Tamam product stock me behtareen quantity me mojood hain.
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="border-b border-slate-100 text-slate-400 font-semibold">
                    <th className="py-2.5">Product Item</th>
                    <th className="py-2.5">Category</th>
                    <th className="py-2.5">Baqi Qty (Stock)</th>
                    <th className="py-2.5">Action Alert</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-50">
                  {lowStockItems.slice(0, 5).map(prod => (
                    <tr key={prod.id} className="text-slate-700 font-medium hover:bg-slate-50 transition-colors">
                      <td className="py-2.5 font-semibold text-slate-800 flex items-center gap-2">
                        {prod.image ? (
                          <img src={prod.image} alt={prod.name} className="w-6 h-6 rounded-md object-cover" referrerPolicy="no-referrer" />
                        ) : (
                          <span className="w-6 h-6 bg-slate-100 border border-slate-200 text-slate-400 font-sans text-[9px] rounded-md flex items-center justify-center font-bold">X</span>
                        )}
                        <span className="max-w-[120px] truncate">{prod.name}</span>
                      </td>
                      <td className="py-2.5 text-slate-500">{prod.category}</td>
                      <td className="py-2.5 font-bold font-mono text-rose-600">{prod.stock} items</td>
                      <td className="py-2.5">
                        <span className="text-[10px] font-bold text-amber-700 bg-amber-50 rounded px-1.5 py-0.5">Order Soon</span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>

      </div>

    </div>
  );
}
