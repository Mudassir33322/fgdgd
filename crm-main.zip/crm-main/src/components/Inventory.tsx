/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  Search, 
  Plus, 
  Edit3, 
  Trash2, 
  AlertTriangle, 
  Sparkles, 
  FolderPlus, 
  Loader2, 
  Package, 
  Coins, 
  Upload, 
  Undo,
  Tags,
  Check
} from 'lucide-react';
import { Product } from '../types';

interface InventoryProps {
  products: Product[];
  categories: string[];
  onAddCategory: (cat: string) => void;
  onDeleteCategory: (cat: string) => void;
  onAddProduct: (product: Product) => void;
  onUpdateProduct: (product: Product) => void;
  onDeleteProduct: (id: string) => void;
  language: 'roman_urdu' | 'urdu' | 'english';
}

export default function Inventory({ 
  products, 
  categories,
  onAddCategory,
  onDeleteCategory,
  onAddProduct,
  onUpdateProduct,
  onDeleteProduct,
  language 
}: InventoryProps) {

  // Search and filters State
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('');
  const [stockStatusFilter, setStockStatusFilter] = useState('all'); // all, low, okay

  // Category view control
  const [isCategoryPanelOpen, setIsCategoryPanelOpen] = useState(false);
  const [newCatInput, setNewCatInput] = useState('');

  // Modal State
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [modalMode, setModalMode] = useState<'add' | 'edit'>('add');
  const [editingId, setEditingId] = useState<string | null>(null);

  // Form State
  const [name, setName] = useState('');
  const [category, setCategory] = useState('');
  const [isAddingNewInlineCategory, setIsAddingNewInlineCategory] = useState(false);
  const [newInlineCatVal, setNewInlineCatVal] = useState('');
  const [costPrice, setCostPrice] = useState(0);
  const [sellingPrice, setSellingPrice] = useState(0);
  const [stock, setStock] = useState(0);
  const [minStockAlert, setMinStockAlert] = useState(5);
  const [imageUrl, setImageUrl] = useState('');

  // AI Generation state
  const [isGeneratingImage, setIsGeneratingImage] = useState(false);
  const [aiPromptError, setAiPromptError] = useState('');
  const [aiSuccessMessage, setAiSuccessMessage] = useState('');

  // Helper local image handler
  const handleLocalImageUploaded = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 2 * 1024 * 1024) {
        setAiPromptError("Bhai, file size 2MB se kam hona chahiye takay memory crash na ho.");
        return;
      }
      setAiPromptError('');
      setAiSuccessMessage('');
      const reader = new FileReader();
      reader.onloadend = () => {
        setImageUrl(reader.result as string);
        setAiSuccessMessage("Local photo uploaded successfully!");
      };
      reader.readAsDataURL(file);
    }
  };

  const t = {
    roman_urdu: {
      searchPlaceholder: "Maal dhundein (Product Name / Category)...",
      addNew: "Naya Maal Add Karein (New Product)",
      categoryLabel: "Zat / Category",
      costPriceLabel: "Kharid Qemat (Cost Price)",
      sellingPriceLabel: "Bechnay Ki Qemat (Selling Price)",
      stockLabel: "Stock Quantity (Tadaad)",
      minStockLabel: "Kam-az-kam Alert Alert Limit",
      aiButton: "AI Se Image Banaen (Generate AI image)",
      editTitle: "Maal Tabdeel Karein (Edit Product)",
      addTitle: "Naya Maal Shamil Karein (Add Product)",
      saveButton: "Mehsul Save Karein",
      allCats: "Tamam Categories",
      allStock: "Tamam Stock States",
      lowStock: "Serf Kam Stock",
      okStock: "Theek Stock",
      actions: "Tarteeb",
      noProducts: "Dukan me abhi koi maal nahi hai. Add button dabaen!",
      nameLabel: "Product Ka Naam",
      imagePreview: "Tasveer Preview",
      emptyImage: "Abhi koi tasveer nahi hai. Uper AI button dabaye ya URL dale."
    },
    urdu: {
      searchPlaceholder: "مصنوعات تلاش کریں...",
      addNew: "نئی مصنوعات شامل کریں",
      categoryLabel: "اقسام (کیٹیگری)",
      costPriceLabel: "قیمت خرید (قیمت لاگت)",
      sellingPriceLabel: "قیمت فروخت",
      stockLabel: "اسٹاک کی کل تعداد",
      minStockLabel: "کم اسٹاک الرٹ کی حد",
      aiButton: "مصنوعی ذہانت (AI) سے تصویر بنائیں",
      editTitle: "مصنوعات میں ترمیم کریں",
      addTitle: "نئی پروڈکٹ داخل کریں",
      saveButton: "پروڈکٹ محفوظ کریں",
      allCats: "تمام اقسام",
      allStock: "تمام اسٹاک",
      lowStock: "کم اسٹاک",
      okStock: "مکمل اسٹاک",
      actions: "عمل",
      noProducts: "ابھی تک کوئی پروڈکٹ موجود نہیں ہے۔ نئی شامل کریں!",
      nameLabel: "نام پروڈکٹ",
      imagePreview: "تصویر کا جائزہ",
      emptyImage: "ابھی کوئی تصویر سیٹ نہیں کی گئی ہے۔"
    },
    english: {
      searchPlaceholder: "Search products by name, ID or category...",
      addNew: "Add New Product",
      categoryLabel: "Category Name",
      costPriceLabel: "Cost Price (Buying)",
      sellingPriceLabel: "Selling Price (Sale)",
      stockLabel: "Initial Stock Level",
      minStockLabel: "Min Stock Alert Level",
      aiButton: "Generate AI Product Image",
      editTitle: "Update Product Details",
      addTitle: "Register New Product",
      saveButton: "Save Product Item",
      allCats: "All Categories",
      allStock: "All Stock Levels",
      lowStock: "Low Stock Triggered",
      okStock: "Satisfactory Stock",
      actions: "Actions",
      noProducts: "No products in store database. Register a new custom product to start trade.",
      nameLabel: "Product Title / Model",
      imagePreview: "Product Image Preview",
      emptyImage: "No visual image selected. Use prompt to generate or paste absolute link."
    }
  }[language];

  // AI Product Image Handler
  const handleGenerateAiImage = async () => {
    if (!name) {
      setAiPromptError("AI se image bananay k liye pehlay Product Ka Naam likhein bhai.");
      return;
    }
    setAiPromptError('');
    setIsGeneratingImage(true);
    setAiSuccessMessage('');
    try {
      const response = await fetch('/api/ai/generate-product-image', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ productName: name, category: category || 'General' }),
      });
      const data = await response.json();
      if (data.imageUrl) {
        setImageUrl(data.imageUrl);
        setAiSuccessMessage(data.isFallback ? "Default seed image set. AI generated illustration loaded." : "Excellent! Safe AI Image loaded inside placeholder.");
      } else {
        setAiPromptError("Image generate nahi hosaki. Default placehold link set kar rehay hain.");
        setImageUrl(`https://picsum.photos/seed/${encodeURIComponent(name)}/300/300`);
      }
    } catch (err: any) {
      console.error(err);
      setAiPromptError("Connection ya key ka kuch masla hai, standard placeholders set kiye gye.");
      setImageUrl(`https://picsum.photos/seed/${encodeURIComponent(name)}/300/300`);
    } finally {
      setIsGeneratingImage(false);
    }
  };

  // Open Modal Helpers
  const openAddModal = () => {
    setModalMode('add');
    setEditingId(null);
    setName('');
    setCategory('');
    setCostPrice(0);
    setSellingPrice(0);
    setStock(0);
    setMinStockAlert(5);
    setImageUrl('');
    setAiPromptError('');
    setAiSuccessMessage('');
    setIsModalOpen(true);
  };

  const openEditModal = (prod: Product) => {
    setModalMode('edit');
    setEditingId(prod.id);
    setName(prod.name);
    setCategory(prod.category);
    setCostPrice(prod.costPrice);
    setSellingPrice(prod.sellingPrice);
    setStock(prod.stock);
    setMinStockAlert(prod.minStockAlert);
    setImageUrl(prod.image || '');
    setAiPromptError('');
    setAiSuccessMessage('');
    setIsModalOpen(true);
  };

  // Submit Handler
  const handleSaveProductSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    const parsedCost = Number(costPrice) || 0;
    const parsedSell = Number(sellingPrice) || 0;
    const parsedStock = Number(stock) || 0;
    const parsedMin = Number(minStockAlert) || 5;

    // Use default premium picture if none set
    const finalImage = imageUrl.trim() || `https://picsum.photos/seed/${encodeURIComponent(name)}/400/400`;

    if (modalMode === 'add') {
      const newProduct: Product = {
        id: 'PROD-' + Date.now().toString().slice(-6),
        name: name.trim(),
        category: category.trim() || 'General',
        costPrice: parsedCost,
        sellingPrice: parsedSell,
        stock: parsedStock,
        minStockAlert: parsedMin,
        image: finalImage
      };
      onAddProduct(newProduct);
    } else if (modalMode === 'edit' && editingId) {
      const updated: Product = {
        id: editingId,
        name: name.trim(),
        category: category.trim() || 'General',
        costPrice: parsedCost,
        sellingPrice: parsedSell,
        stock: parsedStock,
        minStockAlert: parsedMin,
        image: finalImage
      };
      onUpdateProduct(updated);
    }

    setIsModalOpen(false);
  };

  // Delete product confirmation
  const handleDeleteCheck = (id: string, prodName: string) => {
    const isAgree = window.confirm(`Bhaijaan, kiya aap waqai me " ${prodName} " ko dukan k stock list se kharij (delete) karna chahte hain? Sabhi records se ye hat jayega.`);
    if (isAgree) {
      onDeleteProduct(id);
    }
  };

  // Filter logic
  const filteredProducts = products.filter(p => {
    const matchesSearch = p.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          p.category.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          p.id.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesCategory = selectedCategory === '' || p.category === selectedCategory;
    
    let matchesStock = true;
    if (stockStatusFilter === 'low') {
      matchesStock = p.stock <= p.minStockAlert;
    } else if (stockStatusFilter === 'okay') {
      matchesStock = p.stock > p.minStockAlert;
    }

    return matchesSearch && matchesCategory && matchesStock;
  });

  return (
    <div className="space-y-6" id="inventory-tab">
      
      {/* Category Management Drawer Trigger */}
      <div className="flex justify-between items-center bg-gradient-to-r from-blue-50/60 to-indigo-50/60 p-4 border border-blue-100 rounded-2xl">
        <div className="flex items-center gap-2">
          <Tags className="w-5 h-5 text-blue-650" />
          <div>
            <span className="text-xs font-black text-slate-800 block">Dukan Categories Control Board 📁</span>
            <span className="text-[10px] text-slate-500 block">Sway custom labels to tag items neatly</span>
          </div>
        </div>

        <button
          onClick={() => setIsCategoryPanelOpen(!isCategoryPanelOpen)}
          className="text-xs font-extrabold text-blue-600 hover:text-blue-800 flex items-center gap-1 cursor-pointer bg-white px-3.5 py-1.5 border border-blue-200 rounded-xl transition"
        >
          {isCategoryPanelOpen ? "Close Board ✖" : "Zat Categories Manage Karen 📁"}
        </button>
      </div>

      {isCategoryPanelOpen && (
        <div className="bg-slate-50 rounded-2xl p-5 border border-slate-200/80 shadow-inner grid grid-cols-1 md:grid-cols-3 gap-6 animate-fade-in text-xs font-semibold">
          
          {/* Form Create Categories */}
          <div className="space-y-3">
            <span className="text-[10px] uppercase font-black text-slate-400 block tracking-wider">Nayi custom Category likhein</span>
            <div className="flex gap-2">
              <input 
                type="text" 
                placeholder="e.g. Leather Shoes, Wool Kapra"
                value={newCatInput}
                onChange={(e) => setNewCatInput(e.target.value)}
                className="p-2.5 bg-white border outline-none focus:border-blue-500 rounded-xl flex-1 font-bold text-xs"
              />
              <button
                onClick={() => {
                  if (newCatInput.trim()) {
                    onAddCategory(newCatInput.trim());
                    setNewCatInput('');
                  }
                }}
                className="bg-blue-600 hover:bg-blue-700 text-white p-2.5 rounded-xl font-bold transition active:scale-95 text-xs inline-flex items-center gap-1"
              >
                <Plus className="w-4 h-4" /> Add
              </button>
            </div>
            <p className="text-[10px] text-slate-400 font-medium">Bhai ye list durable save rahegi products tag karne k liye.</p>
          </div>

          {/* List of categories chips */}
          <div className="md:col-span-2 space-y-2">
            <span className="text-[10px] uppercase font-black text-slate-400 block tracking-wider">Mojooda Categories ({categories.length})</span>
            <div className="flex flex-wrap gap-2">
              {categories.map(cat => {
                const countOfProds = products.filter(p => p.category === cat).length;
                return (
                  <span key={cat} className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-white border border-slate-250 rounded-xl shadow-sm text-xs text-slate-700 font-bold">
                    <Tags className="w-3.5 h-3.5 text-slate-400" />
                    <span>{cat}</span>
                    <span className="text-[10px] bg-slate-100 text-slate-500 px-1.5 py-0.5 rounded-full">{countOfProds} stocks</span>
                    <button
                      onClick={() => {
                        const isOk = window.confirm(`Bhai, kia aap category "${cat}" ko hatana chahte hain? Subhi mapped items automatically "General" me shift hojayeinge.`);
                        if (isOk) onDeleteCategory(cat);
                      }}
                      className="text-slate-400 hover:text-rose-600 font-bold transition rounded p-0.5 ml-1"
                    >
                      ×
                    </button>
                  </span>
                );
              })}
            </div>
          </div>

        </div>
      )}
      
      {/* 1. Filtering & Quick Search Rails */}
      <div className="bg-white rounded-2xl p-5 border border-slate-100 flex flex-col sm:flex-row gap-4 items-center justify-between shadow-sm">
        
        <div className="relative w-full sm:max-w-md">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input 
            type="text" 
            placeholder={t.searchPlaceholder}
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-10 pr-4 py-2.5 bg-slate-50 hover:bg-slate-50/80 border border-slate-200/80 outline-none focus:border-blue-500 hover:focus:bg-white focus:bg-white text-xs font-medium rounded-xl transition"
          />
        </div>

        <div className="flex flex-wrap items-center gap-2 w-full sm:w-auto">
          {/* Category Dropdown */}
          <select 
            value={selectedCategory} 
            onChange={(e) => setSelectedCategory(e.target.value)}
            className="bg-slate-50 border border-slate-200 text-xs font-medium py-2.5 px-3 rounded-xl outline-none focus:border-blue-500 font-bold"
          >
            <option value="">{t.allCats}</option>
            {categories.map(cat => (
              <option key={cat} value={cat}>{cat}</option>
            ))}
          </select>

          {/* Stock state dropdown */}
          <select 
            value={stockStatusFilter} 
            onChange={(e) => setStockStatusFilter(e.target.value)}
            className="bg-slate-50 border border-slate-200 text-xs font-medium py-2.5 px-3 rounded-xl outline-none focus:border-blue-500 font-bold"
          >
            <option value="all">{t.allStock}</option>
            <option value="low" className="text-rose-600 font-bold">{t.lowStock}</option>
            <option value="okay">{t.okStock}</option>
          </select>

          {/* Add product button trigger */}
          <button 
            onClick={openAddModal}
            className="ml-auto sm:ml-0 flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white font-semibold text-xs py-2.5 px-5 rounded-xl transition shadow-md shadow-blue-100 active:scale-95"
          >
            <Plus className="w-4 h-4" />
            <span>{t.addNew}</span>
          </button>
        </div>

      </div>

      {/* 2. Main Stock Catalog Grid table */}
      {filteredProducts.length === 0 ? (
        <div className="bg-white rounded-2xl border border-slate-100 py-16 text-center shadow-sm">
          <div className="inline-flex p-4 bg-slate-50 text-slate-400 rounded-full mb-3"><Package className="w-8 h-8" /></div>
          <p className="text-xs text-slate-500 font-medium max-w-sm mx-auto">{t.noProducts}</p>
          <button 
            onClick={openAddModal}
            className="mt-4 inline-flex items-center gap-1.5 text-xs text-blue-600 font-bold hover:underline"
          >
            {t.addNew} <Sparkles className="w-3.5 h-3.5" />
          </button>
        </div>
      ) : (
        <div className="bg-white rounded-2xl border border-slate-100 overflow-hidden shadow-sm">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs whitespace-nowrap">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-100 text-slate-400 font-semibold uppercase tracking-wider text-[10px]">
                  <th className="py-3 px-5">ID</th>
                  <th className="py-3 px-5">Tasveer / Item Info</th>
                  <th className="py-3 px-5">{t.categoryLabel}</th>
                  <th className="py-3 px-5 text-right">{t.costPriceLabel}</th>
                  <th className="py-3 px-5 text-right">{t.sellingPriceLabel}</th>
                  <th className="py-3 px-5 text-center">{t.stockLabel}</th>
                  <th className="py-3 px-5 text-center">{t.actions}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredProducts.map(prod => {
                  const isLow = prod.stock <= prod.minStockAlert;
                  return (
                    <tr key={prod.id} className="hover:bg-slate-50 transition-colors font-medium text-slate-700">
                      
                      {/* ID Key */}
                      <td className="py-4 px-5 font-mono text-slate-900 border-r border-slate-50">{prod.id}</td>

                      {/* Name & Avatar Image (with safe fallback rendering referrers) */}
                      <td className="py-4 px-5">
                        <div className="flex items-center gap-3">
                          <img 
                            src={prod.image || `https://picsum.photos/seed/${encodeURIComponent(prod.name)}/100/100`} 
                            alt={prod.name} 
                            className="w-10 h-10 rounded-xl object-contain bg-slate-50 border border-slate-150 p-0.5 shadow-sm flex-shrink-0"
                            referrerPolicy="no-referrer"
                          />
                          <div>
                            <span className="font-semibold text-slate-900 block text-xs tracking-tight">{prod.name}</span>
                            <span className="text-[10px] text-slate-400 block font-mono">Alert when stock: &lt;= {prod.minStockAlert}</span>
                          </div>
                        </div>
                      </td>

                      {/* Category badge */}
                      <td className="py-4 px-5">
                        <span className="inline-flex items-center gap-1.5 px-2.5 py-1 bg-slate-100/80 text-[10px] text-slate-500 rounded-lg">
                          <Tags className="w-3 h-3 text-slate-400" />
                          {prod.category}
                        </span>
                      </td>

                      {/* Buying Price */}
                      <td className="py-4 px-5 text-right font-sans font-semibold text-slate-500">
                        Rs. {prod.costPrice.toLocaleString()}
                      </td>

                      {/* Selling Price */}
                      <td className="py-4 px-5 text-right font-sans font-bold text-slate-900">
                        Rs. {prod.sellingPrice.toLocaleString()}
                      </td>

                      {/* Stock units alert */}
                      <td className="py-4 px-5 text-center">
                        <div className="flex flex-col items-center">
                          <span className={`inline-flex items-center gap-1 px-3 py-1 text-xs font-bold rounded-lg font-mono ${
                            isLow ? 'bg-rose-50 text-rose-600 border border-rose-100 animate-pulse' : 'bg-emerald-50 text-emerald-600 border border-emerald-100'
                          }`}>
                            {prod.stock} items
                          </span>
                          {isLow && (
                            <span className="text-[9px] text-rose-500 font-semibold block mt-1 inline-flex items-center gap-0.5">
                              <AlertTriangle className="w-2.5 h-2.5" /> Ordered Required
                            </span>
                          )}
                        </div>
                      </td>

                      {/* Edit, delete row icons */}
                      <td className="py-4 px-5 text-center">
                        <div className="inline-flex items-center gap-1">
                          <button 
                            onClick={() => openEditModal(prod)}
                            className="p-2 text-slate-400 hover:text-blue-600 hover:bg-blue-50 rounded-xl transition"
                          >
                            <Edit3 className="w-4 h-4" />
                          </button>
                          <button 
                            onClick={() => handleDeleteCheck(prod.id, prod.name)}
                            className="p-2 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-xl transition"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </td>

                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* 3. Add/Edit Premium Item Dialog overlay drawer */}
      {isModalOpen && (
        <div id="product-modal" className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-sm">
          
          <div className="bg-white rounded-3xl w-full max-w-2xl border border-slate-100 shadow-2xl relative overflow-hidden flex flex-col md:flex-row max-h-[90vh]">
            
            {/* Modal Left Section (Main Details form) */}
            <form onSubmit={handleSaveProductSubmit} className="flex-1 p-6 flex flex-col justify-between overflow-y-auto">
              <div>
                <h3 className="text-base font-bold text-slate-900 mb-4">{modalMode === 'add' ? t.addTitle : t.editTitle}</h3>
                
                <div className="space-y-4">
                  {/* Title Name */}
                  <div>
                    <label className="text-[10px] uppercase font-bold text-slate-400 tracking-wide block mb-1">{t.nameLabel}</label>
                    <input 
                      type="text" 
                      required
                      placeholder="e.g. Peshawari Chappal (Kaptan Model)"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      className="w-full p-2.5 bg-slate-50 hover:bg-slate-100 border border-slate-200 outline-none focus:border-blue-500 focus:bg-white text-xs font-semibold rounded-lg transition"
                    />
                  </div>

                  {/* Category Selection */}
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="text-[10px] uppercase font-bold text-slate-400 tracking-wide block mb-1">{t.categoryLabel}</label>
                      
                      {!isAddingNewInlineCategory ? (
                        <div className="flex gap-1.5">
                          <select 
                            value={category}
                            onChange={(e) => {
                              if (e.target.value === '__add_new__') {
                                setIsAddingNewInlineCategory(true);
                              } else {
                                setCategory(e.target.value);
                              }
                            }}
                            className="w-full p-2.5 bg-slate-50 hover:bg-slate-100 border border-slate-200 outline-none focus:border-blue-500 focus:bg-white text-xs font-bold rounded-lg transition"
                          >
                            <option value="">-- Categories List --</option>
                            {categories.map(cat => (
                              <option key={cat} value={cat}>{cat}</option>
                            ))}
                            <option value="__add_new__" className="text-blue-600 font-bold">➕ [ Nayi Category Likhein ]</option>
                          </select>
                        </div>
                      ) : (
                        <div className="flex gap-1">
                          <input 
                            type="text"
                            placeholder="Type Category name..."
                            value={newInlineCatVal}
                            onChange={(e) => setNewInlineCatVal(e.target.value)}
                            className="p-2 bg-white border border-blue-300 outline-none focus:border-blue-500 text-xs font-semibold rounded-lg flex-1"
                          />
                          <button
                            type="button"
                            onClick={() => {
                              if (newInlineCatVal.trim()) {
                                onAddCategory(newInlineCatVal.trim());
                                setCategory(newInlineCatVal.trim());
                                setNewInlineCatVal('');
                                setIsAddingNewInlineCategory(false);
                              } else {
                                setIsAddingNewInlineCategory(false);
                              }
                            }}
                            className="bg-emerald-600 text-white px-2 rounded-lg text-[10px] font-black"
                          >
                            Save
                          </button>
                        </div>
                      )}
                    </div>

                    <div>
                      <label className="text-[10px] uppercase font-bold text-slate-400 tracking-wide block mb-1">{t.minStockLabel}</label>
                      <input 
                        type="number"
                        min="0"
                        value={minStockAlert}
                        onChange={(e) => setMinStockAlert(Number(e.target.value))}
                        className="w-full p-2.5 bg-slate-50 hover:bg-slate-100 border border-slate-200 outline-none focus:border-blue-500 focus:bg-white text-xs font-semibold rounded-lg transition"
                      />
                    </div>
                  </div>

                  {/* Pricing Fields */}
                  <div className="grid grid-cols-3 gap-3">
                    <div>
                      <label className="text-[10px] uppercase font-bold text-slate-400 block mb-1">{t.costPriceLabel}</label>
                      <input 
                        type="number"
                        min="0"
                        value={costPrice}
                        onChange={(e) => setCostPrice(Number(e.target.value))}
                        className="w-full p-2.5 bg-slate-50 hover:bg-slate-100 border border-slate-200 outline-none focus:border-blue-500 focus:bg-white text-xs font-mono font-bold rounded-lg transition"
                      />
                    </div>

                    <div>
                      <label className="text-[10px] uppercase font-bold text-slate-400 block mb-1">{t.sellingPriceLabel}</label>
                      <input 
                        type="number"
                        min="0"
                        value={sellingPrice}
                        onChange={(e) => setSellingPrice(Number(e.target.value))}
                        className="w-full p-2.5 bg-slate-50 hover:bg-slate-100 border border-slate-200 outline-none focus:border-blue-500 focus:bg-white text-xs font-mono font-bold rounded-lg transition"
                      />
                    </div>

                    <div>
                      <label className="text-[10px] uppercase font-bold text-slate-400 block mb-1">{t.stockLabel}</label>
                      <input 
                        type="number"
                        min="0"
                        value={stock}
                        onChange={(e) => setStock(Number(e.target.value))}
                        className="w-full p-2.5 bg-slate-50 hover:bg-slate-100 border border-slate-200 outline-none focus:border-blue-500 focus:bg-white text-xs font-mono font-bold rounded-lg transition"
                      />
                    </div>
                  </div>

                  {/* Product image split (Local Upload OR Custom URL) */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-1">
                    
                    {/* Upload File Input box */}
                    <div>
                      <label className="text-[10px] uppercase font-bold text-slate-400 block mb-1">Local Image Upload (.PNG / .JPG) 📁</label>
                      <div className="border-2 border-dashed border-slate-200 hover:border-blue-400 rounded-xl p-2.5 text-center cursor-pointer hover:bg-slate-50/50 transition relative">
                        <input 
                          type="file" 
                          accept="image/*" 
                          onChange={handleLocalImageUploaded} 
                          className="absolute inset-0 opacity-0 cursor-pointer w-full h-full" 
                        />
                        <Upload className="w-5 h-5 text-slate-400 mx-auto mb-1 animate-pulse" />
                        <span className="text-[10px] font-black text-slate-700 block">Select image from Computer 💻</span>
                        <span className="text-[8px] text-slate-400 block">File size limit: Under 2MB</span>
                      </div>
                    </div>

                    {/* Image URL Input textbox */}
                    <div>
                      <label className="text-[10px] uppercase font-bold text-slate-400 block mb-1">Or Paste Image Web Link</label>
                      <input 
                        type="text" 
                        placeholder="https://images.unsplash.com/... or Base64"
                        value={imageUrl}
                        onChange={(e) => setImageUrl(e.target.value)}
                        className="w-full p-2.5 bg-slate-50 hover:bg-slate-100 border border-slate-200 outline-none focus:border-blue-500 focus:bg-white text-[10px] font-medium rounded-lg h-[56px] transition"
                      />
                    </div>

                  </div>
                </div>
              </div>

              <div className="flex gap-2 mt-6 pt-4 border-t border-slate-100">
                <button 
                  type="button" 
                  onClick={() => setIsModalOpen(false)}
                  className="bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold py-2.5 px-4 rounded-xl transition"
                >
                  Cancel
                </button>
                <button 
                  type="submit" 
                  className="bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold py-2.5 px-6 rounded-xl transition shadow flex-1"
                >
                  {t.saveButton}
                </button>
              </div>
            </form>

            {/* Modal Right Section (AI Product Image generator block) */}
            <div className="w-full md:w-64 bg-slate-50 border-t md:border-t-0 md:border-l border-slate-100 p-6 flex flex-col justify-between overflow-y-auto">
              <div>
                <span className="inline-flex items-center gap-1 text-[10px] font-bold text-blue-600 bg-blue-50 px-2 py-0.5 rounded-full mb-2 uppercase">
                  <Sparkles className="w-3 h-3 text-orange-500 animate-spin" /> AI Product Visualizer
                </span>
                <h4 className="text-xs font-bold text-slate-800 mb-2">Bhai Intelligent Photo</h4>
                <p className="text-[10px] text-slate-500 leading-relaxed mb-4">
                  Apnay product ka aik dil-khush visual banane k liye name lamba likh kr AI button dabayein taakay high quality photo auto generate hojaye!
                </p>

                {/* Main preview box */}
                <div className="w-full aspect-square bg-white border border-slate-200 rounded-xl overflow-hidden flex items-center justify-center p-2 shadow-inner relative group">
                  {imageUrl ? (
                    <img 
                      src={imageUrl} 
                      alt="Generations" 
                      className="w-full h-full object-contain rounded-lg"
                      referrerPolicy="no-referrer"
                    />
                  ) : (
                    <div className="text-center p-3">
                      <Package className="w-8 h-8 text-slate-300 mx-auto mb-1 animate-pulse" />
                      <span className="text-[9px] text-slate-400 block">{t.emptyImage}</span>
                    </div>
                  )}

                  {isGeneratingImage && (
                    <div className="absolute inset-0 bg-slate-900/60 flex flex-col items-center justify-center text-white p-3 text-center">
                      <Loader2 className="w-6 h-6 animate-spin text-blue-400 mb-1" />
                      <span className="text-[10px] font-bold">Image taiyar horahi hai...</span>
                      <span className="text-[8px] text-slate-300 mt-0.5">Vocalizing model prompts</span>
                    </div>
                  )}
                </div>

                {/* Error messages / successes of generating info */}
                {aiPromptError && <p className="text-[10px] text-rose-500 font-semibold mt-2">{aiPromptError}</p>}
                {aiSuccessMessage && <p className="text-[10px] text-emerald-600 font-semibold mt-2 flex items-center gap-0.5"><Check className="w-3.5 h-3.5" /> {aiSuccessMessage}</p>}
              </div>

              <div className="mt-6">
                <button
                  type="button"
                  disabled={isGeneratingImage}
                  onClick={handleGenerateAiImage}
                  className="w-full flex items-center justify-center gap-1.5 py-2 px-3 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white font-bold text-[11px] rounded-xl transition duration-300 shadow-md shadow-indigo-100 disabled:opacity-50"
                >
                  <Sparkles className="w-3.5 h-3.5 animate-pulse text-amber-300" />
                  <span>{t.aiButton}</span>
                </button>
              </div>
            </div>

          </div>
          
        </div>
      )}

    </div>
  );
}
