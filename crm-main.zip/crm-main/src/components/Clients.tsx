/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  Users, 
  UserPlus, 
  Phone, 
  MapPin, 
  Search, 
  ArrowUpRight, 
  Plus, 
  Coins, 
  History, 
  BookOpen, 
  Edit, 
  Trash2,
  Calendar,
  CheckCircle2,
  DollarSign
} from 'lucide-react';
import { Client, Sale } from '../types';

interface ClientsProps {
  clients: Client[];
  sales: Sale[];
  onAddClient: (client: Client) => void;
  onUpdateClient: (client: Client) => void;
  onDeleteClient: (id: string) => void;
  onRecordClientPayment: (clientId: string, amount: number) => void;
  language: 'roman_urdu' | 'urdu' | 'english';
}

export default function Clients({ 
  clients, 
  sales, 
  onAddClient, 
  onUpdateClient, 
  onDeleteClient,
  onRecordClientPayment,
  language 
}: ClientsProps) {

  // Search State
  const [searchQuery, setSearchQuery] = useState('');

  // Selected client for ledger review/history
  const [selectedClientId, setSelectedClientId] = useState<string | null>(null);

  // New Client Modal
  const [isClientModalOpen, setIsClientModalOpen] = useState(false);
  const [clientModalMode, setClientModalMode] = useState<'add' | 'edit'>('add');
  const [editingClientId, setEditingClientId] = useState<string | null>(null);
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [address, setAddress] = useState('');
  const [initialBalance, setInitialBalance] = useState(0);

  // Payments Recovery Drawer Modal state
  const [isPaymentModalOpen, setIsPaymentModalOpen] = useState(false);
  const [paymentClientId, setPaymentClientId] = useState<string | null>(null);
  const [paymentAmount, setPaymentAmount] = useState(0);

  const t = {
    roman_urdu: {
      searchPlaceholder: "Client ka naam ya phone talash karein...",
      addClientBtn: "Naya Client (Khata Book Registration)",
      totalClients: "Kul Khatadar Clients",
      outstandingLoan: "Kul Lena Udhaar (Receivable)",
      clientTableId: "ID",
      clientTableName: "Khatadar Info",
      clientTablePhone: "Phone",
      clientTableBalance: "Udhaar / Khata",
      cleanDebt: "Sari raqam bebak (Paid)",
      actionEdit: "Tabdeel",
      actionDelete: "Kharij",
      ledgerHistory: "Infradi Khata / Transaction Ledger",
      noClients: "Abhi koi client card register nhi hai. Add button dabayein!",
      paymentTitle: "Rakom Jama Kareein (Record Payment Recovery)",
      paymentLabel: "Jama Karda Raqam (Cash Collected)",
      paymentBtn: "Kasool Shuda Mehsul Save Karein",
      walkInLabel: "Walk-in Customer (Non-registered client)",
      outstandingLimit: "Zyaada Udhaar Alert (>10,000)",
      ledgerSelect: "Udhaar details aur invoice history dekhnay k liye kisi bhi client par click karein."
    },
    urdu: {
      searchPlaceholder: "گاہک کا نام یا فون تلاش کریں...",
      addClientBtn: "نیا گاہک رجسٹر کریں",
      totalClients: "کل رجسٹرڈ گاہک",
      outstandingLoan: "کل بقایا رقم (قرضہ جات)",
      clientTableId: "رقم",
      clientTableName: "کھاتیدار کا نام",
      clientTablePhone: "فون نمبر",
      clientTableBalance: "بقایا رقم (کھاتا)",
      cleanDebt: "بقیا صفر ہے (بباک)",
      actionEdit: "تبدیل",
      actionDelete: "حذف کریں",
      ledgerHistory: "کھاتہ لیجر کی تفصیلات",
      noClients: "ابھی تک کوئی گاہک رجسٹرڈ نہیں ہے۔ نیا شامل کریں!",
      paymentTitle: "پیسوں کی ادائیگی درج کریں (رقم کی وصولی)",
      paymentLabel: "وصول شدہ رقم (PKR)",
      paymentBtn: "رقم وصولی محفوظ کریں",
      walkInLabel: "عام کسٹمر (بغیر کھاتہ)",
      outstandingLimit: "زیادہ ادھار کا الرٹ",
      ledgerSelect: "انفرادی کھاتہ اور پچھلی خریداری کی تفصیلات دیکھنے کے لئے اوپر لسٹ پر کلک کریں۔"
    },
    english: {
      searchPlaceholder: "Search clients by name, address or mobile...",
      addClientBtn: "Register New Credit Client",
      totalClients: "Total Clients Book",
      outstandingLoan: "Accounts Receivable Outstanding",
      clientTableId: "Record ID",
      clientTableName: "Client Identity",
      clientTablePhone: "Mobile No",
      clientTableBalance: "Outstanding Khata Balance",
      cleanDebt: "Settled Account",
      actionEdit: "Modify",
      actionDelete: "Remove",
      ledgerHistory: "Client Ledger (Invoice & Deficit History)",
      noClients: "No clients registered in credit book. Click register above.",
      paymentTitle: "Record Cash Payment Recovery (Jama-Parchi)",
      paymentLabel: "Amount Received / Cash Recovered",
      paymentBtn: "Post Payment Ledger Alert",
      walkInLabel: "Walk-In Consumer Account",
      outstandingLimit: "Alert: Debt exceeds 10k!",
      ledgerSelect: "Select any client row from the registry to inspect individual invoices, logs, and loan accounts."
    }
  }[language];

  // Calculations
  const totalOutstanding = clients.reduce((sum, c) => sum + (c.balance || 0), 0);
  const selectedClient = clients.find(c => c.id === selectedClientId);

  // Invoices and payment recovery history matching selected client
  const clientActivityLogs = (() => {
    if (!selectedClientId) return [];
    
    // 1. Sales Logs
    const assocSales = sales.filter(s => s.clientId === selectedClientId);
    // 2. We could list other payments. For now history of invoices is computed
    const activities = assocSales.map(s => ({
      id: s.id,
      date: s.date,
      type: 'Sale (Invoice)',
      ref: s.invoiceNumber,
      amount: s.totalAmount,
      paid: s.paidAmount,
      status: s.paymentStatus,
      changeText: `purchased goods, remaining unpaid: Rs. ${s.totalAmount - s.paidAmount}`
    }));

    return activities.sort((a,b) => b.date.localeCompare(a.date));
  })();

  // Handle Create/Edit client submit
  const handleSaveClientSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    if (clientModalMode === 'add') {
      const newClient: Client = {
        id: 'CLI-' + Date.now().toString().slice(-5),
        name: name.trim(),
        phone: phone.trim() || 'No Number',
        address: address.trim() || 'No Address',
        balance: Number(initialBalance) || 0,
        lastTransactionDate: new Date().toISOString().split('T')[0]
      };
      onAddClient(newClient);
    } else {
      if (editingClientId) {
        const clientCopy = clients.find(c => c.id === editingClientId);
        const updated: Client = {
          id: editingClientId,
          name: name.trim(),
          phone: phone.trim() || 'No Number',
          address: address.trim() || 'No Address',
          balance: clientCopy ? clientCopy.balance : 0, // balance cannot be explicitly overwritten by typings unless recovering payments
          lastTransactionDate: new Date().toISOString().split('T')[0]
        };
        onUpdateClient(updated);
      }
    }
    setIsClientModalOpen(false);
  };

  const handleOpenAddClient = () => {
    setClientModalMode('add');
    setEditingClientId(null);
    setName('');
    setPhone('');
    setAddress('');
    setInitialBalance(0);
    setIsClientModalOpen(true);
  };

  const handleOpenEditClient = (c: Client) => {
    setClientModalMode('edit');
    setEditingClientId(c.id);
    setName(c.name);
    setPhone(c.phone);
    setAddress(c.address);
    setInitialBalance(c.balance);
    setIsClientModalOpen(true);
  };

  // Open direct payment gateway
  const handleOpenPaymentRecovery = (cId: string) => {
    setPaymentClientId(cId);
    setPaymentAmount(0);
    setIsPaymentModalOpen(true);
  };

  const handlePostRecoverySubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (paymentClientId && paymentAmount > 0) {
      onRecordClientPayment(paymentClientId, paymentAmount);
    }
    setIsPaymentModalOpen(false);
  };

  // Delete customer check
  const handleDeleteCheck = (id: string, name: string) => {
    const isAgree = window.confirm(`Bhaijaan, kiya aap waqai me customer " ${name} " ka khata hameshag k liye band (delete) karna chahte hain? Un k saare outstanding balances khatam hojayein ge.`);
    if (isAgree) {
      onDeleteClient(id);
      if (selectedClientId === id) setSelectedClientId(null);
    }
  };

  // Filter accounts
  const filteredClients = clients.filter(c => {
    return c.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
           c.phone.includes(searchQuery) ||
           c.address.toLowerCase().includes(searchQuery.toLowerCase());
  });

  return (
    <div className="space-y-6" id="clients-tab">
      
      {/* 1. Header Balance Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        
        {/* Total Outstanding Receivables */}
        <div id="clients-stats-outstanding" className="bg-white rounded-2xl p-5 border border-slate-100 flex items-center gap-4 shadow-sm">
          <div className="p-3 bg-rose-50 text-rose-600 rounded-xl"><DollarSign className="w-6 h-6" /></div>
          <div>
            <span className="text-[10px] font-bold text-slate-400 tracking-wider uppercase block">{t.outstandingLoan}</span>
            <h4 className="text-2xl font-bold font-sans text-rose-600 mt-1">Rs. {totalOutstanding.toLocaleString()}</h4>
            <span className="text-[10px] text-slate-500 font-medium block">Total market credit to recover</span>
          </div>
        </div>

        {/* Total Client Registries */}
        <div id="clients-stats-total" className="bg-white rounded-2xl p-5 border border-slate-100 flex items-center gap-4 shadow-sm">
          <div className="p-3 bg-blue-50 text-blue-600 rounded-xl"><Users className="w-6 h-6" /></div>
          <div>
            <span className="text-[10px] font-bold text-slate-400 tracking-wider uppercase block">{t.totalClients}</span>
            <h4 className="text-2xl font-bold font-sans text-slate-800 mt-1">{clients.length} Clients</h4>
            <span className="text-[10px] text-slate-500 font-medium block">Active wholesale/retail khata books</span>
          </div>
        </div>

        {/* Action Button */}
        <div className="bg-gradient-to-tr from-slate-850 to-slate-900 rounded-2xl p-4 flex items-center justify-center border border-slate-800">
          <button 
            onClick={handleOpenAddClient}
            className="flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs py-3 px-5 rounded-xl transition duration-300 w-full justify-center active:scale-95 shadow-lg shadow-blue-900/20"
          >
            <UserPlus className="w-4 h-4" />
            <span>{t.addClientBtn}</span>
          </button>
        </div>

      </div>

      {/* 2. Main Customer Registry & Transaction Ledger (Bento layout) */}
      <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">

        {/* Customer Directory List Column (3/5 width) */}
        <div id="customer-directory" className="lg:col-span-3 bg-white rounded-2xl p-6 border border-slate-100 shadow-sm space-y-4">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
            <div>
              <h3 className="font-semibold text-slate-800 text-base">Khata Book Registry (Debtor List)</h3>
              <p className="text-xs text-slate-400">Total list of credit customers</p>
            </div>
            
            <div className="relative w-full sm:max-w-[200px]">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4.5 h-4.5 text-slate-400" />
              <input 
                type="text" 
                placeholder={t.searchPlaceholder}
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-9 pr-3 py-1.5 bg-slate-50 border border-slate-200 outline-none focus:border-blue-500 text-xs rounded-lg transition"
              />
            </div>
          </div>

          {filteredClients.length === 0 ? (
            <div className="text-center py-12 text-xs text-slate-400 font-medium bg-slate-50/50 rounded-xl">
              {t.noClients}
            </div>
          ) : (
            <div className="overflow-y-auto max-h-[500px] border border-slate-100 rounded-xl">
              <table className="w-full text-left text-xs whitespace-nowrap">
                <thead>
                  <tr className="bg-slate-50 border-b border-slate-100 text-slate-400 font-bold uppercase text-[9px]">
                    <th className="py-2.5 px-4">{t.clientTableName}</th>
                    <th className="py-2.5 px-4 text-right">{t.clientTableBalance}</th>
                    <th className="py-2.5 px-4 text-center">Mehsul / Payment</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {filteredClients.map(client => {
                    const isHighDebt = client.balance > 10000;
                    const isSelected = selectedClientId === client.id;
                    return (
                      <tr 
                        key={client.id} 
                        onClick={() => setSelectedClientId(client.id)}
                        className={`cursor-pointer transition-colors ${
                          isSelected ? 'bg-blue-50/40 hover:bg-blue-50/60' : 'hover:bg-slate-50'
                        }`}
                      >
                        
                        {/* Name and general info */}
                        <td className="py-3 px-4 flex items-center gap-3">
                          <span className={`w-8 h-8 rounded-full font-bold flex items-center justify-center text-xs font-sans ${
                            isSelected ? 'bg-blue-600 text-white' : 'bg-slate-100 text-slate-600'
                          }`}>
                            {client.name.charAt(0).toUpperCase()}
                          </span>
                          <div>
                            <span className="font-bold text-slate-900 block">{client.name}</span>
                            <span className="text-[10px] text-slate-400 font-medium inline-flex items-center gap-1">
                              <Phone className="w-3 h-3 text-slate-300" /> {client.phone} • <MapPin className="w-3 h-3 text-slate-300" /> {client.address}
                            </span>
                          </div>
                        </td>

                        {/* Current Outstanding Debt (Rs) */}
                        <td className="py-3 px-4 text-right">
                          <div className="inline-flex flex-col items-end">
                            <span className={`font-sans font-bold text-sm ${
                              client.balance > 0 ? (isHighDebt ? 'text-rose-600 font-extrabold' : 'text-slate-800') : 'text-emerald-700'
                            }`}>
                              Rs. {client.balance.toLocaleString()}/-
                            </span>
                            {client.balance > 0 ? (
                              <span className={`text-[8px] font-bold px-1 rounded uppercase bg-rose-50 text-rose-500 mt-0.5 ${isHighDebt ? 'animate-pulse bg-rose-100' : ''}`}>
                                {isHighDebt ? t.outstandingLimit : 'Unpaid Loan'}
                              </span>
                            ) : (
                              <span className="text-[8px] px-1 bg-emerald-50 text-emerald-600 rounded font-bold uppercase mt-0.5">{t.cleanDebt}</span>
                            )}
                          </div>
                        </td>

                        {/* Direct Recover payment trigger button */}
                        <td className="py-3 px-4 text-center" onClick={(e) => e.stopPropagation()}>
                          <div className="inline-flex items-center gap-1.5">
                            <button 
                              onClick={() => handleOpenPaymentRecovery(client.id)}
                              disabled={client.balance <= 0}
                              className="inline-flex items-center gap-1 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-40 disabled:hover:bg-emerald-600 text-white text-[10px] px-2.5 py-1.5 rounded-lg font-bold transition duration-200 active:scale-95"
                            >
                              <Coins className="w-3 h-3" />
                              <span>Voucher (Jama)</span>
                            </button>
                            <button 
                              onClick={() => handleOpenEditClient(client)}
                              className="p-1 text-slate-400 hover:text-blue-600 rounded"
                            >
                              <Edit className="w-3.5 h-3.5" />
                            </button>
                            <button 
                              onClick={() => handleDeleteCheck(client.id, client.name)}
                              className="p-1 text-slate-400 hover:text-rose-600 rounded"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </td>

                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </div>

        {/* Selected Customer Transactions Ledger (2/5 width) */}
        <div id="customer-ledger" className="lg:col-span-2 bg-gradient-to-b from-slate-50 to-white/20 rounded-2xl p-6 border border-slate-100 shadow-sm flex flex-col justify-between">
          <div>
            <h3 className="font-semibold text-slate-800 text-base mb-1 inline-flex items-center gap-1.5">
              <BookOpen className="w-4 h-4 text-slate-500" />
              {t.ledgerHistory}
            </h3>
            <p className="text-xs text-slate-400 mb-4">Selected client ledger logs</p>

            {/* If Client is selected, load ledger list */}
            {selectedClient ? (
              <div className="space-y-4">
                
                {/* Visual Header profile for selected client */}
                <div className="bg-white p-4 rounded-xl border border-slate-200/50 shadow-sm">
                  <div className="flex justify-between items-start">
                    <div>
                      <h4 className="font-extrabold text-slate-900 text-sm leading-none">{selectedClient.name}</h4>
                      <p className="text-[10px] text-slate-400 font-mono mt-1">ID: {selectedClient.id}</p>
                    </div>
                    <div className="text-right">
                      <span className="text-[10px] font-bold text-slate-400 block uppercase">Outstanding:</span>
                      <span className="font-bold text-xs text-rose-600">Rs. {selectedClient.balance.toLocaleString()}</span>
                    </div>
                  </div>
                </div>

                {/* Log entries */}
                <div className="space-y-2 max-h-[300px] overflow-y-auto pr-1">
                  {clientActivityLogs.length === 0 ? (
                    <p className="text-center py-12 text-[10px] text-slate-400 font-medium">Is client k liye abhi koi sale/kharidari record nahi ki gaye hai.</p>
                  ) : (
                    clientActivityLogs.map(log => (
                      <div key={log.id} className="bg-white p-3 rounded-lg border border-slate-100 flex justify-between items-start text-xs relative overflow-hidden">
                        <div className="absolute left-0 top-0 bottom-0 w-1 bg-blue-500"></div>
                        <div className="pl-1.5">
                          <span className="font-bold text-slate-800 block text-[11px]">{log.type}</span>
                          <span className="text-[9px] text-slate-400 mt-0.5 inline-flex items-center gap-0.5"><History className="w-2.5 h-2.5" /> Ref: {log.ref}</span>
                          <span className="text-[10px] text-slate-500 font-medium block mt-1">{log.changeText}</span>
                        </div>
                        <div className="text-right flex flex-col justify-between h-full">
                          <span className="font-mono font-bold text-slate-900 leading-none">Rs. {log.amount.toLocaleString()}</span>
                          <span className="text-[9px] font-mono text-slate-400 mt-1 block">{log.date}</span>
                        </div>
                      </div>
                    ))
                  )}
                </div>

              </div>
            ) : (
              <div className="text-center py-20 bg-white border border-dashed border-slate-200 rounded-xl p-6 shadow-inner flex flex-col items-center justify-center">
                <Users className="w-12 h-12 text-slate-350 animate-pulse mb-3" />
                <p className="text-xs text-slate-400 font-medium max-w-xs">{t.ledgerSelect}</p>
              </div>
            )}
          </div>

          {selectedClient && (
            <div className="mt-8 border-t border-slate-150 pt-4 text-center">
              <span className="text-[10px] text-slate-400 font-medium">Showing auto audited ledger for {selectedClient.name}</span>
            </div>
          )}
        </div>

      </div>

      {/* 3. Client Registration / Edit overlay modal */}
      {isClientModalOpen && (
        <div id="client-modal" className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-sm">
          <div className="bg-white rounded-3xl w-full max-w-sm border border-slate-100 p-6 shadow-2xl relative">
            <h3 className="text-base font-extrabold text-slate-900 mb-4">
              {clientModalMode === 'add' ? t.addClientBtn : "Verify Client Address / Phone"}
            </h3>

            <form onSubmit={handleSaveClientSubmit} className="space-y-4 text-xs font-semibold">
              {/* Name */}
              <div>
                <label className="text-[10px] uppercase font-bold text-slate-400 tracking-wide block mb-1">Customer / Shop Name</label>
                <input 
                  type="text"
                  required
                  placeholder="e.g. Haji Bashir Garments"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 outline-none focus:border-blue-500 rounded-lg font-bold"
                />
              </div>

              {/* Phone */}
              <div>
                <label className="text-[10px] uppercase font-bold text-slate-400 tracking-wide block mb-1">Mobile Contact Phone</label>
                <input 
                  type="text"
                  placeholder="e.g. 0300-1234567"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 outline-none focus:border-blue-500 rounded-lg font-bold"
                />
              </div>

              {/* Address */}
              <div>
                <label className="text-[10px] uppercase font-bold text-slate-400 tracking-wide block mb-1">Shop Address / Location</label>
                <input 
                  type="text"
                  placeholder="e.g. Anarkali Bazar, Lahore Shop # 4"
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 outline-none focus:border-blue-500 rounded-lg font-medium"
                />
              </div>

              {/* Initial Loan balance, only active when adding new */}
              {clientModalMode === 'add' && (
                <div>
                  <label className="text-[10px] uppercase font-bold text-slate-400 tracking-wide block mb-1">Pehla Outstanding Loan Khata (Pehla Udhaar balance)</label>
                  <input 
                    type="number"
                    min="0"
                    value={initialBalance}
                    onChange={(e) => setInitialBalance(Number(e.target.value))}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 outline-none focus:border-blue-500 rounded-lg font-bold font-mono"
                  />
                </div>
              )}

              <div className="flex gap-2 pt-4 border-t border-slate-100">
                <button 
                  type="button" 
                  onClick={() => setIsClientModalOpen(false)}
                  className="bg-slate-100 hover:bg-slate-200 text-slate-700 py-2.5 px-4 rounded-xl transition font-sans"
                >
                  Cancel
                </button>
                <button 
                  type="submit" 
                  className="bg-blue-600 hover:bg-blue-700 text-white py-2.5 px-6 rounded-xl transition font-sans flex-1"
                >
                  Save Khatadar Info
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* 4. Payment Recovery (Jama Voucher Draw) Drawer Modal */}
      {isPaymentModalOpen && (
        <div id="payment-recovery-modal" className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-sm">
          <div className="bg-white rounded-3xl w-full max-w-xs border border-slate-100 p-6 shadow-2xl">
            <h3 className="text-base font-extrabold text-slate-900 mb-2 inline-flex items-center gap-1">
              <Coins className="w-5 h-5 text-emerald-600 animate-bounce" />
              {t.paymentTitle}
            </h3>
            <p className="text-[10px] text-slate-500 leading-normal mb-4">Un k khata book balance me koutoti k liye jama parchi record karein.</p>

            <form onSubmit={handlePostRecoverySubmit} className="space-y-4">
              <div>
                <label className="text-[10px] font-bold text-slate-400 block mb-1">{t.paymentLabel}</label>
                <input 
                  type="number"
                  required
                  min="1"
                  value={paymentAmount}
                  onChange={(e) => setPaymentAmount(Number(e.target.value))}
                  className="w-full p-3 bg-slate-50 border border-slate-200 outline-none focus:border-emerald-500 rounded-xl text-center font-mono font-bold text-lg"
                  placeholder="Rs. Cash Amount Collected"
                />
              </div>

              <div className="flex gap-2 pt-3 border-t border-slate-100">
                <button 
                  type="button" 
                  onClick={() => setIsPaymentModalOpen(false)}
                  className="bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold py-2.5 px-4 rounded-lg"
                >
                  Cancel
                </button>
                <button 
                  type="submit" 
                  className="bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold py-2.5 px-5 rounded-lg flex-1"
                >
                  Verify Payment Recovery
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
}
