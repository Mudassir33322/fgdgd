/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  Send, 
  MessageSquare, 
  Sparkles, 
  Share2, 
  Facebook, 
  Instagram, 
  AlertTriangle,
  Clipboard, 
  Check, 
  ArrowRight,
  Phone,
  Layers,
  CheckCircle,
  TrendingUp,
  Coins,
  Bot,
  RefreshCw,
  ShoppingBag,
  Grid
} from 'lucide-react';
import { Product, Client, Sale } from '../types';

interface SocialHubProps {
  products: Product[];
  clients: Client[];
  sales: Sale[];
  language: 'roman_urdu' | 'urdu' | 'english';
}

export default function SocialHub({ products, clients, sales, language }: SocialHubProps) {
  // Selected marketing active pane: 'ai-copy' | 'supplier' | 'invoice_dispatch'
  const [activePane, setActivePane] = useState<'ai-copy' | 'supplier' | 'invoice_dispatch'>('ai-copy');

  // AI Content Generator states
  const [selectedProductId, setSelectedProductId] = useState('');
  const [targetPlatform, setTargetPlatform] = useState<'whatsapp' | 'facebook' | 'instagram'>('whatsapp');
  const [tonality, setTonality] = useState<'funny_urdu' | 'offer_promotion' | 'professional_bhai' | 'whatsapp_broadcast'>('offer_promotion');
  const [customNote, setCustomNote] = useState('');
  const [generatedPost, setGeneratedPost] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [isCopied, setIsCopied] = useState(false);

  // Supplier low-stock ordering states
  const [supplierPhone, setSupplierPhone] = useState('');
  const [selectedLowStockIds, setSelectedLowStockIds] = useState<string[]>(() => 
    products.filter(p => p.stock <= p.minStockAlert).map(p => p.id)
  );
  const [orderQuantities, setOrderQuantities] = useState<Record<string, number>>(() => {
    const initial: Record<string, number> = {};
    products.forEach(p => {
      initial[p.id] = Math.max(5, (p.minStockAlert * 2) - p.stock);
    });
    return initial;
  });

  // Invoice Dispatch states
  const [selectedClientId, setSelectedClientId] = useState('');
  const [customInvoiceNote, setCustomInvoiceNote] = useState('');

  const t = {
    roman_urdu: {
      socialTitle: "Social Hub & WhatsApp",
      socialSubtitle: "AI Marketing posts, Customer balance alerts aur WhatsApp connectivity center",
      tabMarketing: "AI Post Creator",
      tabSupplier: "Supplier Order Maker",
      tabInvoice: "Client Bill Dispatcher",
      labelSelectProduct: "Maal select karein (Select Product)",
      labelPlatform: "Platform chunein",
      labelTone: "Kaise likhein (Tonality Style)",
      btnGenerate: "AI Post Likhein",
      btnGenerating: "AI Likh Raha Hai...",
      previewTitle: "Live Social Post Mockup",
      btnCopy: "Post Copy Karein",
      btnShare: "WhatsApp Par Share Karein",
      noProduct: "Plz pehlay dukan ka koi maal select karein.",
      lowStockTitle: "Kam Stock Wala Maal",
      supplierDisclaimer: "Dealer ko automatic WhatsApp message bhejne k liye low stock maal select karen.",
      sendToSupplier: "Supplier ko list WhatsApp karen",
      buyerTitle: "Grahak Ka Khata Share Karen",
      buyerDisclaimer: "Customer ka baqi udhaar statement and payment link generator WhatsApp per bhejein.",
      selectClient: "Client / Customer Chunein",
      customNotePlace: "Upto 15% Off / Jaldi aayen!",
      copied: "Mubarak! Text Clipboard me copy ho gaya.",
      successMessage: "Baji / Bhai, click karne se WhatsApp web ya app open hojayegi."
    },
    urdu: {
      socialTitle: "میڈیا ہب اور واٹس ایپ",
      socialSubtitle: "آٹو سوشل میڈیا پوسٹس، کسٹمر کو الرٹ اور سپلائر آرڈر ز",
      tabMarketing: "بنائیں پوسٹ (AI)",
      tabSupplier: "آرڈر سپلائر",
      tabInvoice: "گاہک کو بل بھیجیں",
      labelSelectProduct: "پروڈکٹ کا انتخاب کریں",
      labelPlatform: "پلیٹ فارم منتخب کریں",
      labelTone: "انداز تحریر (ٹون)",
      btnGenerate: "AI پوسٹ تحریر کریں",
      btnGenerating: "لکھا جا رہا ہے...",
      previewTitle: "سوشل پوسٹ کا لائیو منظر",
      btnCopy: "کاپی کریں",
      btnShare: "واٹس ایپ شیئر کریں",
      noProduct: "برائے مہربانی پہلے کسی پروڈکٹ کو منتخب کریں۔",
      lowStockTitle: "کم اسٹاک کا سارا سامان",
      supplierDisclaimer: "کم اسٹاک مصنوعات تھوک ڈیلر کو براہ راست واٹس ایپ پر آرڈر کرنے کے لیے منتخب کریں۔",
      sendToSupplier: "ڈیلر کو واٹس ایپ بھیجیں",
      buyerTitle: "کھاتہ دار کا واجب الادا بل واٹس ایپ کریں",
      buyerDisclaimer: "گاہک کا بیلنس شیئر کرنے کے لیے کسٹمر کو منتخب کریں۔",
      selectClient: "گاہک منتخب کریں",
      customNotePlace: "خصوصی ڈسکاؤنٹ یا آفر",
      copied: "تحریر کاپی کر لی گئی ہے!",
      successMessage: "کلک کرنے سے واٹس ایپ پیج کھل جائے گا۔"
    },
    english: {
      socialTitle: "AI Social Marketing & WhatsApp Hub",
      socialSubtitle: "Create viral Facebook promos, generate supplier orders & dispatch client balances via WhatsApp",
      tabMarketing: "AI Post Engine",
      tabSupplier: "Supplier Order System",
      tabInvoice: "Client Ledgers Dispatch",
      labelSelectProduct: "Select Product Source",
      labelPlatform: "Target Social Media Platform",
      labelTone: "Copywriting Tonality & Vibe",
      btnGenerate: "Generate Promo Copy via AI",
      btnGenerating: "Writing Creative Pitch...",
      previewTitle: "Platform Feed Mockup Preview",
      btnCopy: "Copy To Clipboard",
      btnShare: "Send Directly on WhatsApp",
      noProduct: "Select a retail item to trigger the copy generator.",
      lowStockTitle: "Out-of-Stock Supplier Orders",
      supplierDisclaimer: "Generate instant wholesale order sheets based on empty inventory limits.",
      sendToSupplier: "Send Wholesale List via WhatsApp",
      buyerTitle: "Outstanding Khata Bill Reminders",
      buyerDisclaimer: "Select client account to auto-generate warm debt recovery template to resolve.",
      selectClient: "Select Client Ledger Account",
      customNotePlace: "Include extra notes/discounts...",
      copied: "Success! Post details copied to clipboard.",
      successMessage: "Clicking will redirect to WhatsApp with the message prefilled securely."
    }
  }[language];

  // Helper lists
  const lowStockProducts = products.filter(p => p.stock <= p.minStockAlert);

  // Trigger Content Generator API Call
  const handleGeneratePost = async () => {
    setIsGenerating(true);
    setGeneratedPost('');
    try {
      const prod = products.find(p => p.id === selectedProductId);
      const res = await fetch('/api/ai/generate-social-post', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          productName: prod ? prod.name : 'All Shop Products Catalog',
          category: prod ? prod.category : 'General',
          price: prod ? prod.sellingPrice : 0,
          platform: targetPlatform,
          tonality: tonality,
          customNote: customNote
        })
      });
      const data = await res.json();
      if (data.post) {
        setGeneratedPost(data.post);
      } else {
        setGeneratedPost("Kuch masla aya hai, AI text likh nahi saka.");
      }
    } catch (err) {
      console.error(err);
      setGeneratedPost("Bhai jaan, network issue ya system failure. Standard prompt responses check karein.");
    } finally {
      setIsGenerating(false);
    }
  };

  // Safe client copy action
  const handleCopyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    setIsCopied(true);
    setTimeout(() => setIsCopied(false), 2000);
  };

  // WhatsApp trigger launcher helper
  const launchWhatsApp = (phone: string, text: string) => {
    // Sanitise phone
    let formattedPhone = phone.trim().replace(/[^0-9]/g, '');
    if (formattedPhone.startsWith('0')) {
      // Local Pak phone conversion to international country code 92
      formattedPhone = '92' + formattedPhone.substring(1);
    }
    const apiLink = `https://api.whatsapp.com/send?phone=${formattedPhone}&text=${encodeURIComponent(text)}`;
    window.open(apiLink, '_blank');
  };

  // Produce supplier low-stock bulk order string 
  const generateSupplierOrderString = () => {
    let orderText = `*Bhai Shop ERP - WHOLESALE ORDER REQUISITION*\n`;
    orderText += `Date: ${new Date().toLocaleDateString()}\n`;
    orderText += `=======================\n\n`;
    orderText += `Assalam-o-Alaikum! Please arrange the following replenishment stock items for our shop:\n\n`;

    let itemAdded = false;
    products.forEach(p => {
      if (selectedLowStockIds.includes(p.id)) {
        const qtyToOrder = orderQuantities[p.id] || 10;
        orderText += `• *${p.name}* (Urgent Category: ${p.category})\n`;
        orderText += `  Current Stock: _${p.stock} units_ | *Order Quantity: ${qtyToOrder} units*\n\n`;
        itemAdded = true;
      }
    });

    if (!itemAdded) {
      orderText += `(Bhai stock looks fresh. No short items added.)\n`;
    }

    orderText += `=======================\n`;
    orderText += `📱 Generated automatically via Siana ERP Assistant. Pack carefully and send invoice bills. JazakAllah!`;
    return orderText;
  };

  // Produce client reminder order string
  const generateClientReminderString = () => {
    const client = clients.find(c => c.id === selectedClientId);
    if (!client) return '';

    let text = `*BHAI SHOP ERP Ledger - OUTSTANDING STATEMENT* 📝\n`;
    text += `Dear *${client.name}*,\n\n`;
    text += `Assalam-o-Alaikum! Hope you are doing well.\n`;
    text += `We have audited our retail credit records on ${new Date().toLocaleDateString()}.\n\n`;
    text += `💰 *Total Outstanding Balance Balance*: *Rs. ${client.balance.toLocaleString()}/-*\n\n`;

    if (customInvoiceNote.trim()) {
      text += `Note: _${customInvoiceNote.trim()}_\n\n`;
    } else {
      text += `Kindly arrange the outstanding dues at your earliest convenience to clear local ledger balances. Direct Bank online transfer and spot cash are both available.\n\n`;
    }

    text += `=======================\n`;
    text += `📞 For any adjustments or query, contact shop office directly.\n`;
    text += `Thank you for your valuable commercial trade partner relationship! 👍🏼`;
    return text;
  };

  return (
    <div className="space-y-6" id="social-hub-canvas">
      
      {/* 1. Header Banner */}
      <div className="bg-white rounded-3xl p-6 border border-slate-100 shadow-sm flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div className="flex items-center gap-3">
          <span className="p-3 bg-gradient-to-br from-green-500 to-emerald-600 text-white rounded-2xl shadow-lg">
            <Share2 className="w-6 h-6" />
          </span>
          <div>
            <h2 className="text-base font-extrabold text-slate-900">{t.socialTitle}</h2>
            <p className="text-xs text-slate-400 mt-1">{t.socialSubtitle}</p>
          </div>
        </div>

        {/* Dynamic sub navigation buttons */}
        <div className="flex bg-slate-100 p-1 rounded-xl text-xs font-bold shrink-0">
          <button 
            onClick={() => setActivePane('ai-copy')}
            className={`px-4 py-2 rounded-lg transition ${activePane === 'ai-copy' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-500 hover:text-slate-900'}`}
          >
            {t.tabMarketing}
          </button>
          <button 
            onClick={() => setActivePane('supplier')}
            className={`px-4 py-2 rounded-lg transition ${activePane === 'supplier' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-500 hover:text-slate-900'}`}
          >
            {t.tabSupplier}
          </button>
          <button 
            onClick={() => setActivePane('invoice_dispatch')}
            className={`px-4 py-2 rounded-lg transition ${activePane === 'invoice_dispatch' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-500 hover:text-slate-900'}`}
          >
            {t.tabInvoice}
          </button>
        </div>
      </div>

      {/* 2. active Render layout panel */}
      
      {/* SECTION A: AI SOCIAL POST GENERATOR */}
      {activePane === 'ai-copy' && (
        <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
          
          {/* Post custom controls selector */}
          <div className="lg:col-span-2 bg-white rounded-2xl p-6 border border-slate-100 shadow-sm space-y-4">
            <h3 className="text-sm font-black text-slate-900 flex items-center gap-1">
              <Sparkles className="w-4 h-4 text-amber-500" />
              AI Copywriting Engine
            </h3>

            <div className="space-y-3.5 text-xs">
              
              {/* Select Product */}
              <div>
                <label className="text-[10px] uppercase font-bold text-slate-400 tracking-wide block mb-1.5">{t.labelSelectProduct}</label>
                <select 
                  value={selectedProductId}
                  onChange={(e) => setSelectedProductId(e.target.value)}
                  className="w-full p-2.5 bg-slate-50 hover:bg-slate-100 border border-slate-200 outline-none focus:border-blue-500 rounded-lg font-bold"
                >
                  <option value="">-- Sabhi Dukan Maal Ki List --</option>
                  {products.map(prod => (
                    <option key={prod.id} value={prod.id}>
                      {prod.name} (Rs. {prod.sellingPrice})
                    </option>
                  ))}
                </select>
              </div>

              {/* Target Platform */}
              <div>
                <label className="text-[10px] uppercase font-bold text-slate-400 block mb-1.5">{t.labelPlatform}</label>
                <div className="grid grid-cols-3 gap-2">
                  <button
                    type="button"
                    onClick={() => setTargetPlatform('whatsapp')}
                    className={`p-2 rounded-lg border font-bold text-center flex items-center justify-center gap-1.5 transition ${
                      targetPlatform === 'whatsapp' ? 'bg-emerald-50 border-emerald-400 text-emerald-700' : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
                    }`}
                  >
                    <MessageSquare className="w-3.5 h-3.5" /> WhatsApp
                  </button>
                  <button
                    type="button"
                    onClick={() => setTargetPlatform('facebook')}
                    className={`p-2 rounded-lg border font-bold text-center flex items-center justify-center gap-1.5 transition ${
                      targetPlatform === 'facebook' ? 'bg-blue-50 border-blue-400 text-blue-700' : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
                    }`}
                  >
                    <Facebook className="w-3.5 h-3.5" /> Facebook
                  </button>
                  <button
                    type="button"
                    onClick={() => setTargetPlatform('instagram')}
                    className={`p-2 rounded-lg border font-bold text-center flex items-center justify-center gap-1.5 transition ${
                      targetPlatform === 'instagram' ? 'bg-fuchsia-50 border-fuchsia-400 text-fuchsia-700' : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
                    }`}
                  >
                    <Instagram className="w-3.5 h-3.5" /> Instagram
                  </button>
                </div>
              </div>

              {/* Choose tonality vibe */}
              <div>
                <label className="text-[10px] uppercase font-bold text-slate-400 block mb-1.5">{t.labelTone}</label>
                <select
                  value={tonality}
                  onChange={(e) => setTonality(e.target.value as any)}
                  className="w-full p-2.5 bg-slate-50 hover:bg-slate-100 border border-slate-200 outline-none focus:border-blue-500 rounded-lg font-bold"
                >
                  <option value="offer_promotion">Urgent Discount Offer (FOMO + Emojis)</option>
                  <option value="funny_urdu">Mazedaar Roman Urdu Commercial (Viral Pitch)</option>
                  <option value="professional_bhai">Respectful & Elegant Professional Style</option>
                  <option value="whatsapp_broadcast">Beautiful Itemized WhatsApp Catalogue Listing</option>
                </select>
              </div>

              {/* Extra Custom notes */}
              <div>
                <label className="text-[10px] uppercase font-bold text-slate-400 block mb-1.5">Custom Notes / Discount (Optional)</label>
                <textarea
                  placeholder="e.g. Free delivery over Lahore / Stock is limited / Special 20% discount"
                  value={customNote}
                  onChange={(e) => setCustomNote(e.target.value)}
                  className="w-full p-2.5 bg-slate-50 hover:bg-slate-100 border border-slate-200 outline-none focus:border-blue-500 rounded-lg h-20 resize-none font-semibold"
                />
              </div>

              {/* Generate Button */}
              <button
                type="button"
                onClick={handleGeneratePost}
                disabled={isGenerating}
                className="w-full py-3 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white font-extrabold text-xs rounded-xl shadow-md flex items-center justify-center gap-1.5 transition disabled:opacity-50"
              >
                {isGenerating ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4 animate-pulse" />}
                <span>{isGenerating ? t.btnGenerating : t.btnGenerate}</span>
              </button>

            </div>
          </div>

          {/* Social feed mockup column (3/5 width) */}
          <div className="lg:col-span-3 bg-[#f8fafc] border border-slate-150 rounded-2xl p-6 flex flex-col justify-between">
            <div>
              <div className="flex justify-between items-center mb-4">
                <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider">{t.previewTitle}</h4>
                {targetPlatform === 'facebook' && <span className="text-[10px] bg-blue-100 text-blue-700 px-2 py-0.5 rounded font-bold">Facebook Feed Preview</span>}
                {targetPlatform === 'instagram' && <span className="text-[10px] bg-fuchsia-100 text-fuchsia-700 px-2 py-0.5 rounded font-bold">Instagram Post Preview</span>}
                {targetPlatform === 'whatsapp' && <span className="text-[10px] bg-green-100 text-green-700 px-2 py-0.5 rounded font-bold">WhatsApp Group Preview</span>}
              </div>

              {/* Responsive Phone container preview frame */}
              <div className="bg-white border rounded-3xl p-5 shadow-lg max-w-md mx-auto relative overflow-hidden text-xs">
                
                {/* Visual rendering of visual poster inside feed */}
                <div className="flex items-center gap-2 mb-3">
                  <div className="w-8 h-8 rounded-full bg-slate-800 text-white flex items-center justify-center font-bold text-[10px]">
                    B
                  </div>
                  <div>
                    <span className="font-bold text-slate-800 block leading-none">Bhai Cloth & Shoes Centre</span>
                    <span className="text-[9px] text-slate-400 block mt-0.5">Sponsored • Pakistan Retail Ledger</span>
                  </div>
                </div>

                <div className="text-slate-700 font-medium leading-relaxed whitespace-pre-wrap font-mono p-4 bg-slate-50 border border-slate-150 rounded-2xl">
                  {generatedPost ? generatedPost : (
                    <div className="text-center py-16 text-slate-400">
                      <Bot className="w-10 h-10 mx-auto text-blue-500 mb-2 animate-bounce" />
                      <span>Uper parameters select kar k "AI Post Likhein" ka button dabayein bhai!</span>
                    </div>
                  )}
                </div>

                {selectedProductId && products.find(p => p.id === selectedProductId) && (
                  <div className="mt-3 border rounded-2xl overflow-hidden flex items-center gap-3 bg-slate-50 p-2.5">
                    <img 
                      src={products.find(p => p.id === selectedProductId)?.image || `https://picsum.photos/seed/${selectedProductId}/200/200`}
                      alt="promo"
                      className="w-14 h-14 object-contain rounded-xl bg-white border"
                      referrerPolicy="no-referrer"
                    />
                    <div>
                      <span className="font-bold text-slate-800 text-[11px] block">{products.find(p => p.id === selectedProductId)?.name}</span>
                      <span className="text-xs text-blue-600 block font-semibold">Price tag: Rs. {products.find(p => p.id === selectedProductId)?.sellingPrice.toLocaleString()}/-</span>
                    </div>
                  </div>
                )}
                
              </div>
            </div>

            {/* Bottom actions trigger */}
            {generatedPost && (
              <div className="flex flex-col md:flex-row gap-3 pt-5 border-t border-slate-200 mt-6 bg-slate-50 p-4 rounded-xl">
                <button
                  type="button"
                  onClick={() => handleCopyToClipboard(generatedPost)}
                  className="flex items-center justify-center gap-1 px-4 py-2 bg-white border border-slate-200 hover:bg-slate-100 rounded-xl font-bold text-xs text-slate-700 flex-1 active:scale-95 transition"
                >
                  {isCopied ? <Check className="w-4 h-4 text-emerald-500" /> : <Clipboard className="w-4 h-4 text-slate-400" />}
                  <span>{isCopied ? "Copy Ho Gaya!" : t.btnCopy}</span>
                </button>
                <button
                  type="button"
                  onClick={() => launchWhatsApp('', generatedPost)}
                  className="flex items-center justify-center gap-1.5 px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl font-extrabold text-xs flex-1 active:scale-95 transition"
                >
                  <MessageSquare className="w-4 h-4 text-white" />
                  <span>{t.btnShare}</span>
                </button>
              </div>
            )}

          </div>

        </div>
      )}

      {/* SECTION B: SUPPLIER ORDERS */}
      {activePane === 'supplier' && (
        <div id="supplier-pane" className="bg-white rounded-2xl border border-slate-100 shadow-sm p-6 space-y-6">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 border-b pb-4">
            <div>
              <h3 className="font-bold text-slate-900 border-none inline-flex items-center gap-1.5">
                <AlertTriangle className="w-5 h-5 text-amber-500" />
                {t.lowStockTitle} ({lowStockProducts.length} items critical)
              </h3>
              <p className="text-xs text-slate-500 mt-1">{t.supplierDisclaimer}</p>
            </div>

            <div className="flex gap-2">
              <input
                type="text"
                placeholder="Dealer ka phone num (e.g. 03001234567)"
                value={supplierPhone}
                onChange={(e) => setSupplierPhone(e.target.value)}
                className="p-2 border rounded-xl text-xs outline-none focus:border-blue-500 font-mono font-bold"
              />
            </div>
          </div>

          {lowStockProducts.length === 0 ? (
            <div className="text-center py-16 bg-slate-50 rounded-2xl text-xs text-slate-400 font-semibold p-4">
              Mubarak! Tamam maal check ho chuka ha. Koi bhi cheez short stock me nahi ha.
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              
              {/* Checklist details block */}
              <div className="space-y-3.5 border border-slate-100 p-4 rounded-xl bg-slate-50/50">
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block">Choose stock to order</span>
                
                <div className="space-y-2.5 max-h-[300px] overflow-y-auto pr-1">
                  {lowStockProducts.map(p => (
                    <div key={p.id} className="flex items-center justify-between p-3 bg-white border rounded-xl text-xs">
                      <div className="flex items-center gap-3">
                        <input
                          type="checkbox"
                          checked={selectedLowStockIds.includes(p.id)}
                          onChange={(e) => {
                            if (e.target.checked) {
                              setSelectedLowStockIds([...selectedLowStockIds, p.id]);
                            } else {
                              setSelectedLowStockIds(selectedLowStockIds.filter(id => id !== p.id));
                            }
                          }}
                          className="w-4 h-4 text-blue-600 rounded"
                        />
                        <div>
                          <span className="font-extrabold text-slate-800 block mt-0.5">{p.name}</span>
                          <span className="text-[10px] text-rose-500 block">Current stock: {p.stock} units! (Limit: {p.minStockAlert})</span>
                        </div>
                      </div>

                      {/* Config order quantity */}
                      <div className="flex items-center gap-1">
                        <span className="text-[10px] text-slate-400">Order:</span>
                        <input
                          type="number"
                          min="1"
                          value={orderQuantities[p.id] || 10}
                          onChange={(e) => setOrderQuantities({
                            ...orderQuantities,
                            [p.id]: Math.max(1, Number(e.target.value))
                          })}
                          className="w-14 p-1 border font-bold text-center rounded focus:border-blue-500"
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Text draft preview block */}
              <div className="border border-slate-100 p-4 rounded-xl bg-emerald-50/10 flex flex-col justify-between">
                <div>
                  <span className="text-[10px] font-bold text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded-full mb-3 inline-block">Draft Order Slip Text</span>
                  <div className="p-3 bg-slate-900 text-slate-300 font-mono text-[11px] leading-relaxed rounded-lg whitespace-pre-wrap h-[240px] overflow-y-auto">
                    {generateSupplierOrderString()}
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => launchWhatsApp(supplierPhone, generateSupplierOrderString())}
                  className="w-full mt-4 py-3 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl flex items-center justify-center gap-1.5 transition active:scale-95"
                >
                  <Phone className="w-4 h-4 text-emerald-100" />
                  <span>{t.sendToSupplier}</span>
                </button>
              </div>

            </div>
          )}

        </div>
      )}

      {/* SECTION C: INVOICES DISPATCH FOR RECOVERY */}
      {activePane === 'invoice_dispatch' && (
        <div id="dispatch-pane" className="bg-white rounded-2xl border border-slate-100 shadow-sm p-6 space-y-6">
          <div className="border-b pb-4">
            <h3 className="font-bold text-slate-900 border-none inline-flex items-center gap-1.5">
              <Coins className="w-5 h-5 text-amber-500 animate-spin" />
              {t.buyerTitle}
            </h3>
            <p className="text-xs text-slate-500 mt-1">{t.buyerDisclaimer}</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            
            {/* Form details block */}
            <div className="space-y-4 text-xs font-semibold">
              
              {/* Select Client */}
              <div>
                <label className="text-[10px] uppercase font-bold text-slate-400 block mb-1.5">{t.selectClient}</label>
                <select
                  value={selectedClientId}
                  onChange={(e) => setSelectedClientId(e.target.value)}
                  className="w-full p-2.5 bg-slate-50 hover:bg-slate-100 border border-slate-200 outline-none focus:border-blue-500 rounded-lg font-bold"
                >
                  <option value="">-- Client Chunein (Select Account) --</option>
                  {clients.filter(c => c.balance > 0).map(c => (
                    <option key={c.id} value={c.id}>
                      {c.name} (Outstandings Dues: Rs.{c.balance})
                    </option>
                  ))}
                </select>
              </div>

              {/* Custom sweet note draft */}
              <div>
                <label className="text-[10px] uppercase font-bold text-slate-400 block mb-1.5">Custom Adjustment Message Note</label>
                <textarea
                  placeholder="e.g. Apki purani payment reh gayi hai, plz bank me transfer karwa den."
                  value={customInvoiceNote}
                  onChange={(e) => setCustomInvoiceNote(e.target.value)}
                  className="w-full p-2.5 bg-slate-50 hover:bg-slate-100 border border-slate-200 outline-none focus:border-blue-500 rounded-lg h-24 resize-none"
                />
              </div>

              {selectedClientId && (
                <div className="bg-blue-50/50 p-4 border border-blue-100 rounded-xl space-y-1">
                  <span className="font-extrabold text-blue-900 block text-[11px]">Audit Ledger Summary:</span>
                  <div className="grid grid-cols-2 text-[11px] text-slate-650">
                    <span>Contact Number:</span>
                    <span className="font-bold text-slate-800">{clients.find(c => c.id === selectedClientId)?.phone}</span>
                    <span>Total Borrow Debt:</span>
                    <span className="font-heavy text-rose-600 font-bold">Rs. {clients.find(c => c.id === selectedClientId)?.balance}</span>
                  </div>
                </div>
              )}

            </div>

            {/* Generated results statement text preview container */}
            <div className="border border-slate-100 p-4 rounded-xl bg-slate-50 flex flex-col justify-between">
              <div>
                <span className="text-[10px] font-bold text-slate-400 block mb-3">CLIENT STATEMENTS DISPATCH SLIP</span>
                <div className="p-3 bg-white border text-[11px] leading-relaxed text-slate-800 font-mono rounded-lg whitespace-pre-wrap h-[200px] overflow-y-auto shadow-inner">
                  {selectedClientId ? generateClientReminderString() : "(Plz select are indebted client from ledger list to compile message slip.)"}
                </div>
              </div>

              <button
                type="button"
                disabled={!selectedClientId}
                onClick={() => {
                  const client = clients.find(c => c.id === selectedClientId);
                  if (client) {
                    launchWhatsApp(client.phone, generateClientReminderString());
                  }
                }}
                className="w-full mt-4 py-3 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-40 text-white text-xs font-bold rounded-xl flex items-center justify-center gap-1.5 transition active:scale-95"
              >
                <Phone className="w-4 h-4 text-emerald-100" />
                <span>Client ko Statement WhatsApp Bhejein</span>
              </button>
            </div>

          </div>
        </div>
      )}

    </div>
  );
}
