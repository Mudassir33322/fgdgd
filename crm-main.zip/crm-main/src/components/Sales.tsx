/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  Plus, 
  Trash2, 
  ShoppingBag, 
  CheckCircle2, 
  User, 
  Coins, 
  Bookmark, 
  FileText,
  Printer,
  ChevronDown,
  Percent,
  Calculator,
  Tag,
  AlertCircle,
  FileDown
} from 'lucide-react';
import { jsPDF } from 'jspdf';
import { Product, Client, Sale, SaleItem } from '../types';

interface SalesProps {
  products: Product[];
  clients: Client[];
  sales: Sale[];
  onAddSale: (sale: Sale) => void;
  language: 'roman_urdu' | 'urdu' | 'english';
}

interface SelectedCartItem {
  productId: string;
  productName: string;
  qty: number;
  costPrice: number;    // tracked for profit computation
  sellingPrice: number; // custom base sell price setting
  stockLimit: number;
}

export default function Sales({ 
  products, 
  clients, 
  sales, 
  onAddSale, 
  language 
}: SalesProps) {

  // Cart / Basket items State
  const [basket, setBasket] = useState<SelectedCartItem[]>([]);
  
  // Selection States
  const [selectedClientId, setSelectedClientId] = useState('walk-in');
  const [discount, setDiscount] = useState(0);
  const [cashReceived, setCashReceived] = useState(0);

  // Active Item Selector states
  const [activeProductId, setActiveProductId] = useState('');
  const [activeQty, setActiveQty] = useState(1);

  // Printable Receipt Invoice State
  const [completedInvoice, setCompletedInvoice] = useState<Sale | null>(null);
  const [showReceiptOverlay, setShowReceiptOverlay] = useState(false);

  // Generate PDF Invoice
  const generateInvoicePDF = (sale: Sale) => {
    const doc = new jsPDF({
      orientation: 'portrait',
      unit: 'mm',
      format: 'a4'
    });

    // Color Palette
    const primaryColor = [30, 41, 59]; // slate-800
    const accentColor = [37, 99, 235]; // blue-600
    const textColor = [51, 65, 85]; // slate-700
    const lightGrey = [241, 245, 249]; // slate-100
    const borderGrey = [226, 232, 240]; // slate-200

    // Header / Branding Banner
    doc.setFillColor(primaryColor[0], primaryColor[1], primaryColor[2]);
    doc.rect(0, 0, 210, 40, 'F');
    
    doc.setTextColor(255, 255, 255);
    doc.setFont('Helvetica', 'bold');
    doc.setFontSize(22);
    doc.text('SIANA ERP & LOGISTICS', 15, 18);
    
    doc.setFont('Helvetica', 'normal');
    doc.setFontSize(10);
    doc.setTextColor(191, 219, 254);
    doc.text('Premium Business Management & Khata Suite', 15, 25);
    doc.text('Official Auto-Generated Transaction Record', 15, 30);
    
    // Status Badge Block inside Header
    doc.setFillColor(accentColor[0], accentColor[1], accentColor[2]);
    doc.rect(142, 10, 53, 12, 'F');
    doc.setTextColor(255, 255, 255);
    doc.setFont('Helvetica', 'bold');
    doc.setFontSize(10);
    doc.text('RETAIL INVOICE', 147, 18);

    // Metadata section line
    doc.setTextColor(30, 41, 59);
    doc.setFont('Helvetica', 'bold');
    doc.setFontSize(11);
    doc.text('INVOICE IDENTIFICATION', 15, 52);
    doc.setLineWidth(0.4);
    doc.setDrawColor(borderGrey[0], borderGrey[1], borderGrey[2]);
    doc.line(15, 55, 195, 55);

    doc.setFont('Helvetica', 'normal');
    doc.setFontSize(9.5);
    doc.setTextColor(textColor[0], textColor[1], textColor[2]);
    
    // Invoice details parameters
    doc.text(`Invoice Number:`, 15, 63);
    doc.setFont('Helvetica', 'bold');
    doc.text(`${sale.invoiceNumber}`, 45, 63);
    
    doc.setFont('Helvetica', 'normal');
    doc.text(`Transaction Date:`, 15, 69);
    doc.text(`${sale.date}`, 45, 69);

    doc.text(`Payment Status:`, 15, 75);
    doc.setFont('Helvetica', 'bold');
    if (sale.paymentStatus === 'Paid') {
      doc.setTextColor(16, 185, 129); // emerald-600
    } else if (sale.paymentStatus === 'Partially Paid') {
      doc.setTextColor(217, 119, 6); // amber-600
    } else {
      doc.setTextColor(220, 38, 38); // red-600
    }
    doc.text(`${sale.paymentStatus}`, 45, 75);

    // Customer Column on right
    doc.setTextColor(textColor[0], textColor[1], textColor[2]);
    doc.setFont('Helvetica', 'bold');
    doc.setFontSize(11);
    doc.text('CLIENT DETAILS', 120, 52);
    doc.setFont('Helvetica', 'normal');
    doc.setFontSize(9.5);
    doc.text(`Name:`, 120, 63);
    doc.text(`${sale.clientName}`, 145, 63);
    doc.text(`Client ID:`, 120, 69);
    doc.text(`${sale.clientId === 'walk-in' ? 'Walk-in Cash Client' : sale.clientId}`, 145, 69);

    // Separation
    let startY = 88;
    doc.setFont('Helvetica', 'bold');
    doc.setFontSize(11);
    doc.setTextColor(primaryColor[0], primaryColor[1], primaryColor[2]);
    doc.text('PURCHASED ITEMS', 15, startY);
    doc.line(15, startY + 3, 195, startY + 3);

    // Draw table headers
    startY = startY + 11;
    doc.setFillColor(lightGrey[0], lightGrey[1], lightGrey[2]);
    doc.rect(15, startY - 5, 180, 8, 'F');
    
    doc.setFont('Helvetica', 'bold');
    doc.setFontSize(9);
    doc.setTextColor(71, 85, 105);
    doc.text('#', 18, startY);
    doc.text('ITEM NAME', 25, startY);
    doc.text('QTY', 115, startY, { align: 'center' });
    doc.text('RATE (PKR)', 145, startY, { align: 'right' });
    doc.text('TOTAL PRICE', 190, startY, { align: 'right' });

    // Reset layout for list items
    doc.setTextColor(textColor[0], textColor[1], textColor[2]);
    doc.setFont('Helvetica', 'normal');
    doc.setFontSize(9.5);

    let currentY = startY + 7;
    sale.items.forEach((item, idx) => {
      doc.text(`${idx + 1}`, 18, currentY);
      
      let itmName = item.productName;
      if (itmName.length > 40) {
        itmName = itmName.substring(0, 37) + '...';
      }
      doc.text(itmName, 25, currentY);
      doc.text(`${item.qty}`, 115, currentY, { align: 'center' });
      doc.text(`Rs. ${item.sellingPrice}`, 145, currentY, { align: 'right' });
      doc.text(`Rs. ${item.qty * item.sellingPrice}`, 190, currentY, { align: 'right' });
      
      doc.setDrawColor(borderGrey[0], borderGrey[1], borderGrey[2]);
      doc.setLineWidth(0.15);
      doc.line(15, currentY + 3.5, 195, currentY + 3.5);

      currentY += 8;
    });

    // Summary calculation rows
    currentY += 4;
    const rightColAlign = 120;
    const valueAlign = 190;
    
    doc.setFontSize(9.5);
    doc.setTextColor(71, 85, 105);
    
    const originalGross = sale.items.reduce((acc, itm) => acc + (itm.qty * itm.sellingPrice), 0);
    
    doc.text('Subtotal Gross Amount:', rightColAlign, currentY);
    doc.text(`Rs. ${originalGross.toLocaleString()}`, valueAlign, currentY, { align: 'right' });
    
    if (sale.discount > 0) {
      currentY += 6;
      doc.text('Discount / Choot:', rightColAlign, currentY);
      doc.setTextColor(220, 38, 38);
      doc.text(`-Rs. ${sale.discount.toLocaleString()}`, valueAlign, currentY, { align: 'right' });
      doc.setTextColor(71, 85, 105);
    }

    currentY += 7;
    doc.setFillColor(lightGrey[0], lightGrey[1], lightGrey[2]);
    doc.rect(rightColAlign - 5, currentY - 5, 80, 23, 'F');
    
    doc.setFont('Helvetica', 'bold');
    doc.setTextColor(primaryColor[0], primaryColor[1], primaryColor[2]);
    doc.text('Net Amount Due:', rightColAlign, currentY);
    doc.text(`Rs. ${sale.totalAmount.toLocaleString()}/-`, valueAlign, currentY, { align: 'right' });

    currentY += 5.5;
    doc.setFont('Helvetica', 'normal');
    doc.setTextColor(textColor[0], textColor[1], textColor[2]);
    doc.text('Cash Paid / Recovered:', rightColAlign, currentY);
    doc.text(`Rs. ${sale.paidAmount.toLocaleString()}/-`, valueAlign, currentY, { align: 'right' });

    const outstandingAmt = sale.totalAmount - sale.paidAmount;
    currentY += 5.5;
    if (outstandingAmt > 0) {
      doc.setFont('Helvetica', 'bold');
      doc.setTextColor(220, 38, 38);
      doc.text('Remaining Balance (Khata):', rightColAlign, currentY);
      doc.text(`Rs. ${outstandingAmt.toLocaleString()}/-`, valueAlign, currentY, { align: 'right' });
    } else {
      doc.setFont('Helvetica', 'bold');
      doc.setTextColor(16, 185, 129);
      doc.text('Invoice Fully Cleared / Paid', rightColAlign, currentY);
    }

    // Footnotes branding
    doc.setFont('Helvetica', 'oblique');
    doc.setFontSize(9);
    doc.setTextColor(148, 163, 184);
    doc.text('Shukriya! Thank you for buying from our store.', 105, 273, { align: 'center' });
    
    doc.setFont('Helvetica', 'normal');
    doc.setFontSize(8);
    doc.text('This is an official computer-formatted invoice generated securely on Siana ERP.', 105, 278, { align: 'center' });

    // Download / Save pdf trigger
    doc.save(`Invoice_${sale.invoiceNumber}.pdf`);
  };

  const t = {
    roman_urdu: {
      newInvoice: "Naya bechny ka record (New Invoice)",
      selectClient: "Client / Grahak Chunein",
      walkIn: "Walk-in Grahak (Normal Client)",
      addItem: "Maal Shamil Karein (Add Product)",
      selectProduct: "Maal Chunein",
      qtyLabel: "Tadaad (Qty)",
      addToBasket: "Cart me Dalein",
      cartTitle: "Kharidari Cart Basket",
      emptyBasket: "Bhai cart khali hai. Uper se maal select kar k dukan ka sauda cart me dalein.",
      grossTotal: "Gross Total (Kul Raqam)",
      discountLabel: "Discount Choot (Rs.)",
      netTotal: "Net Receivable (Total Pay)",
      cashPaid: "Cash Wasool Shuda (Cash Paid)",
      checkoutBtn: "Invoice Save & Parchi Banaen",
      invoiceDetail: "Invoice Slip",
      invoiceSaved: "Mubarak! Invoice Record Save ho gaya.",
      statusPaid: "Paid (Kul Ada)",
      statusUnpaid: "Unpaid / Baqi Khata",
      statusPartial: "Partial (Kuch Baqi)",
      stockLimitAlert: "Dukan me is maal ka stock khatam hai!",
      printSlip: "Parchi Print Karein",
      historyTitle: "Purani Parchi History (Sales Invoices Ledger)",
      historyDesc: "Tamam puraye bills aur invoices yahan se download ya print karehein",
      downloadPdf: "PDF Parchi",
      noInvoicesYet: "Dukan me abhi koi bikri history nahi hai."
    },
    urdu: {
      newInvoice: "نیا سیل انوائس (فروخت ریکارڈ)",
      selectClient: "گاہک منتخب کریں",
      walkIn: "عام گاہک (نقد خرید)",
      addItem: "مصنوعات شامل کریں",
      selectProduct: "پروڈکٹ کا انتخاب کریں",
      qtyLabel: "تعداد (کوانٹٹی)",
      addToBasket: "کارٹ میں شامل کریں",
      cartTitle: "شاپنگ کارٹ (خریداری)",
      emptyBasket: "خریداری کارٹ خالی ہے۔ برائے مہربانی پروڈکٹس کواڈ کریں۔",
      grossTotal: "کل رقم (گراس ٹوٹل)",
      discountLabel: "رعایت / ڈسکاؤنٹ",
      netTotal: "نیٹ واجب الادا رقم",
      cashPaid: "وصول شدہ رقم (کیش)",
      checkoutBtn: "انوائس اور فروخت مکمل کریں",
      invoiceDetail: "انوائس کی مہر",
      invoiceSaved: "فروخت کامیابی سے ریکارڈ کی گئی ہے!",
      statusPaid: "مکمل ادا",
      statusUnpaid: "بقایا رقم (ادھار)",
      statusPartial: "کچھ بقایا رقم",
      stockLimitAlert: "اس پروڈکٹ کا اسٹاک ناکافی ہے۔",
      printSlip: "پرچی پرنٹ کریں(PRINT)",
      historyTitle: "سابقہ فروخت انوائسز (بلز ہسٹری)",
      historyDesc: "یہاں سے آپ تمام پرانے بلز دیکھ اور ان کی پی ڈی ایف (PDF) ڈاؤن لوڈ کر سکتے ہیں",
      downloadPdf: "پی ڈی ایف بل",
      noInvoicesYet: "ابھی تک کوئی سابقہ بل ریکارڈ نہیں ہے۔"
    },
    english: {
      newInvoice: "Generate New Sales Transaction / Retail Invoice",
      selectClient: "Select Client / Account",
      walkIn: "Walk-In Customer (Cash Only)",
      addItem: "Select Item to Invoice",
      selectProduct: "Choose Product Item",
      qtyLabel: "Quantity",
      addToBasket: "Add Item to Invoice",
      cartTitle: "Active Cart Items",
      emptyBasket: "The checkout basket is empty. Select products from catalogue to post invoice.",
      grossTotal: "Gross Amount",
      discountLabel: "Manual Discount (Rs.)",
      netTotal: "Net Payable Due",
      cashPaid: "Cash Recovered on Spot",
      checkoutBtn: "Post & Print Custom Receipt",
      invoiceDetail: "Official Retail Invoice Receipt",
      invoiceSaved: "Transaction posted and recorded successfully into account ledger.",
      statusPaid: "Paid",
      statusUnpaid: "Unpaid",
      statusPartial: "Partially Paid",
      stockLimitAlert: "Selected item exceeds physical inventory limits!",
      printSlip: "Print Invoice Receipt",
      historyTitle: "Sales Invoice History & Reprint Center",
      historyDesc: "Retrieve, review, and download PDF receipts for all historical sales transactions",
      downloadPdf: "Download PDF",
      noInvoicesYet: "No invoices posted in history yet."
    }
  }[language];

  // Pick helper item for validation
  const activeProduct = products.find(p => p.id === activeProductId);

  // Cart addition handler
  const handleAddItemToBasket = (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeProductId) return;

    const prod = products.find(p => p.id === activeProductId);
    if (!prod) return;

    // Check if item is already in basket
    const existing = basket.find(item => item.productId === activeProductId);
    const addedQty = existing ? existing.qty + Number(activeQty) : Number(activeQty);

    // Stock level checks
    if (addedQty > prod.stock) {
      alert(`Bhaijaan, " ${prod.name} " ka stock kafi nhi hai. Mojuda stock serf: ${prod.stock} hai.`);
      return;
    }

    if (existing) {
      setBasket(basket.map(item => 
        item.productId === activeProductId ? { ...item, qty: addedQty } : item
      ));
    } else {
      const newItem: SelectedCartItem = {
        productId: prod.id,
        productName: prod.name,
        qty: Number(activeQty),
        costPrice: prod.costPrice,
        sellingPrice: prod.sellingPrice,
        stockLimit: prod.stock
      };
      setBasket([...basket, newItem]);
    }

    // Reset selection defaults
    setActiveProductId('');
    setActiveQty(1);
  };

  // Remove basket item
  const handleRemoveBasketItem = (prodId: string) => {
    setBasket(basket.filter(item => item.productId !== prodId));
  };

  // Computations
  const subTotal = basket.reduce((acc, item) => acc + (item.qty * item.sellingPrice), 0);
  const netTotal = Math.max(subTotal - Number(discount), 0);

  // Checkout submit handler (post invoice)
  const handleCheckoutSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (basket.length === 0) return;

    // Determine client name
    let clientName = t.walkIn;
    if (selectedClientId !== 'walk-in') {
      const cl = clients.find(c => c.id === selectedClientId);
      if (cl) clientName = cl.name;
    }

    // Map cart items into typing SaleItem
    const saleItems: SaleItem[] = basket.map(item => ({
      productId: item.productId,
      productName: item.productName,
      qty: item.qty,
      costPrice: item.costPrice,
      sellingPrice: item.sellingPrice
    }));

    // Auto-calculate profit = (sellingPrice - costPrice) * qty - discount (proportional)
    const totalCostOfSoldItems = basket.reduce((sum, item) => sum + (item.costPrice * item.qty), 0);
    const calculatedProfit = netTotal - totalCostOfSoldItems;

    // Determine payment state
    let status: 'Paid' | 'Unpaid' | 'Partially Paid' = 'Paid';
    const parsedCash = Number(cashReceived) || 0;
    if (parsedCash === 0) {
      status = 'Unpaid';
    } else if (parsedCash < netTotal) {
      status = 'Partially Paid';
    }

    const uniqueInvoiceNumber = 'INV-' + Date.now().toString().slice(-6);

    const newSale: Sale = {
      id: 'SALE-' + Date.now().toString(),
      invoiceNumber: uniqueInvoiceNumber,
      date: new Date().toISOString().split('T')[0],
      clientId: selectedClientId,
      clientName: clientName,
      items: saleItems,
      totalAmount: netTotal,
      discount: Number(discount) || 0,
      paidAmount: parsedCash,
      paymentStatus: status,
      profit: calculatedProfit
    };

    // Trigger save
    onAddSale(newSale);

    // Save temporary reference for printable overlay modal receipt show
    setCompletedInvoice(newSale);
    setShowReceiptOverlay(true);

    // Flush active basket cart
    setBasket([]);
    setDiscount(0);
    setCashReceived(0);
    setSelectedClientId('walk-in');
  };

  // Direct cash helper fast buttons
  const setCashReceivedExact = () => {
    setCashReceived(netTotal);
  };

  return (
    <div className="space-y-6" id="sales-tab">
      
      {/* Receipts Overlay Modal */}
      {showReceiptOverlay && completedInvoice && (
        <div id="receipt-printed-modal" className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
          <div className="bg-white rounded-3xl w-full max-w-md border border-slate-200 shadow-2xl relative p-6 max-h-[90vh] overflow-y-auto font-sans text-slate-800">
            
            <div className="text-center pb-4 border-b border-dashed border-slate-200">
              <span className="p-3 bg-emerald-50 text-emerald-600 rounded-full inline-block mb-3 animate-pulse">
                <CheckCircle2 className="w-8 h-8" />
              </span>
              <h3 className="text-base font-extrabold text-slate-900">{t.invoiceSaved}</h3>
              <p className="text-xs text-slate-400 mt-1">Siana ERP automatic ledger synced</p>
            </div>

            {/* FBR Style Printed Receipt Body layout */}
            <div className="py-5 text-xs space-y-4 font-mono">
              <div className="flex justify-between font-bold text-slate-900 border-b border-slate-100 pb-2">
                <span>RETAIL RECEIPT SLIP</span>
                <span>{completedInvoice.invoiceNumber}</span>
              </div>

              <div className="space-y-1 text-[11px] text-slate-500">
                <p><span className="font-semibold text-slate-700">Date Log:</span> {completedInvoice.date}</p>
                <p><span className="font-semibold text-slate-700">Client Info:</span> {completedInvoice.clientName}</p>
                <p><span className="font-semibold text-slate-700">Status Check:</span> <span className="font-bold text-slate-800">{completedInvoice.paymentStatus}</span></p>
              </div>

              {/* Items List */}
              <div className="border-y border-dashed border-slate-200 py-3 mt-4">
                <div className="grid grid-cols-5 text-slate-400 font-bold mb-1.5 text-[10px]">
                  <span className="col-span-2">PRODUCT ITEM</span>
                  <span className="text-center">QTY</span>
                  <span className="text-right">PRICE</span>
                  <span className="text-right">TOTAL</span>
                </div>
                <div className="space-y-1.5 text-[11px] text-slate-700">
                  {completedInvoice.items.map(item => (
                    <div key={item.productId} className="grid grid-cols-5 font-medium leading-tight">
                      <span className="col-span-2 truncate font-semibold text-slate-800">{item.productName}</span>
                      <span className="text-center">{item.qty}</span>
                      <span className="text-right">Rs.{item.sellingPrice}</span>
                      <span className="text-right font-bold">Rs.{item.qty * item.sellingPrice}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Totals computation */}
              <div className="space-y-1 text-slate-600 pl-24 text-[11px]">
                {completedInvoice.discount > 0 && (
                  <div className="flex justify-between">
                    <span>Discount Choot:</span>
                    <span>-Rs. {completedInvoice.discount}</span>
                  </div>
                )}
                <div className="flex justify-between font-bold text-slate-900 text-xs border-t border-slate-100 pt-1.5">
                  <span>Net Paid:</span>
                  <span>Rs. {completedInvoice.totalAmount.toLocaleString()}</span>
                </div>
                <div className="flex justify-between text-slate-500">
                  <span>Cash Paid:</span>
                  <span>Rs. {completedInvoice.paidAmount.toLocaleString()}</span>
                </div>
                {completedInvoice.totalAmount - completedInvoice.paidAmount > 0 && (
                  <div className="flex justify-between text-rose-600 font-bold">
                    <span>Khata Outstanding:</span>
                    <span>Rs. {(completedInvoice.totalAmount - completedInvoice.paidAmount).toLocaleString()}</span>
                  </div>
                )}
              </div>
            </div>

            <div className="flex flex-col gap-2 pt-4 border-t border-slate-100 mt-6">
              <div className="flex gap-2.5">
                <button 
                  onClick={() => {
                    window.print();
                  }}
                  className="flex items-center justify-center gap-1.5 border border-slate-200 hover:bg-slate-50 text-slate-700 font-bold text-[11px] py-2.5 px-3 rounded-xl flex-1 active:scale-95 transition"
                >
                  <Printer className="w-4 h-4 text-slate-500" />
                  <span>{t.printSlip}</span>
                </button>
                <button 
                  onClick={() => generateInvoicePDF(completedInvoice)}
                  className="flex items-center justify-center gap-1.5 bg-blue-50 border border-blue-100 hover:bg-blue-100 text-blue-700 font-bold text-[11px] py-2.5 px-3 rounded-xl flex-1 active:scale-95 transition"
                >
                  <FileDown className="w-4 h-4 text-blue-600" />
                  <span>{t.downloadPdf}</span>
                </button>
              </div>
              <button 
                onClick={() => setShowReceiptOverlay(false)}
                className="w-full bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs py-2.5 rounded-xl text-center active:scale-95 transition"
              >
                Theek Hai (Close)
              </button>
            </div>

          </div>
        </div>
      )}

      {/* Main Billing Canvas Block (Bento Layout) */}
      <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">

        {/* Dynamic Billing Form Controls Section (3/5 width) */}
        <div id="billing-form" className="lg:col-span-3 bg-white rounded-2xl p-6 border border-slate-100 shadow-sm space-y-6">
          <div>
            <h3 className="font-semibold text-slate-800 text-base">{t.newInvoice}</h3>
            <p className="text-xs text-slate-400">Add products to record transactions</p>
          </div>

          <form onSubmit={handleAddItemToBasket} className="space-y-4 bg-slate-50 p-4 border border-slate-100 rounded-xl text-xs">
            
            {/* 1. Client Choice */}
            <div>
              <label className="text-[10px] uppercase font-bold text-slate-400 tracking-wide block mb-1.5">{t.selectClient}</label>
              <div className="relative">
                <User className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                <select 
                  value={selectedClientId}
                  onChange={(e) => setSelectedClientId(e.target.value)}
                  className="w-full pl-9 pr-4 py-2.5 bg-white border border-slate-200 outline-none focus:border-blue-500 rounded-lg text-xs font-bold transition"
                >
                  <option value="walk-in" className="font-bold">{t.walkIn}</option>
                  {clients.map(client => (
                    <option key={client.id} value={client.id}>
                      {client.name} (Outstanding: Rs.{client.balance})
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {/* 2. Product selection & qty */}
            <div className="grid grid-cols-1 sm:grid-cols-4 gap-3 items-end">
              <div className="sm:col-span-3 font-semibold">
                <label className="text-[10px] uppercase font-bold text-slate-400 tracking-wide block mb-1.5">{t.selectProduct}</label>
                <select 
                  value={activeProductId}
                  onChange={(e) => setActiveProductId(e.target.value)}
                  className="w-full p-2.5 bg-white border border-slate-200 outline-none focus:border-blue-500 rounded-lg text-xs font-semibold"
                >
                  <option value="">-- {t.selectProduct} --</option>
                  {products.map(prod => (
                    <option key={prod.id} value={prod.id} disabled={prod.stock <= 0}>
                      {prod.name} (Saad Price: Rs.{prod.sellingPrice} | Stock: {prod.stock})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="text-[10px] uppercase font-bold text-slate-400 tracking-wide block mb-1.5">{t.qtyLabel}</label>
                <input 
                  type="number" 
                  min="1"
                  required
                  value={activeQty}
                  onChange={(e) => setActiveQty(Math.max(1, Number(e.target.value)))}
                  className="w-full p-2.5 bg-white border border-slate-200 outline-none focus:border-blue-500 rounded-lg text-center font-bold"
                />
              </div>
            </div>

            {/* If product is chose, render stock alerts inside block */}
            {activeProduct && (
              <div className="bg-blue-50 border border-blue-100 text-blue-800 p-3 rounded-lg text-[11px] leading-relaxed">
                <span className="font-bold block">Items details:</span>
                • Category: {activeProduct.category} | Buying price tracked on accounts ledger: Rs. {activeProduct.costPrice}
                <br />
                • Sale Price: <span className="font-bold">Rs. {activeProduct.sellingPrice}</span> | Current Stock in hand: <span className="font-bold">{activeProduct.stock} units</span>
              </div>
            )}

            <button 
              type="submit"
              disabled={!activeProductId}
              className="w-full py-2.5 bg-blue-600 hover:bg-blue-700 disabled:opacity-40 text-white font-bold text-xs rounded-xl transition duration-300 active:scale-98 shadow-md shadow-blue-100 flex items-center justify-center gap-2"
            >
              <Plus className="w-4 h-4" />
              <span>{t.addToBasket}</span>
            </button>

          </form>

          {/* Active ledger summary of sale details */}
          <div id="active-cart" className="border border-slate-100 rounded-2xl overflow-hidden shadow-sm">
            <h4 className="bg-slate-50 border-b border-slate-100 p-4 font-bold text-xs text-slate-700 flex items-center gap-2">
              <ShoppingBag className="w-4 h-4 text-slate-500" />
              <span>{t.cartTitle} ({basket.length} items selected)</span>
            </h4>

            {basket.length === 0 ? (
              <div className="py-12 bg-white text-center text-xs text-slate-400 font-medium p-4">
                {t.emptyBasket}
              </div>
            ) : (
              <div className="divide-y divide-slate-100">
                {basket.map(item => (
                  <div key={item.productId} className="p-4 bg-white hover:bg-slate-50/50 transition flex justify-between items-center text-xs">
                    <div>
                      <span className="font-bold text-slate-900 block">{item.productName}</span>
                      <span className="text-[10px] text-slate-400 block mt-0.5">Rate setting: Rs.{item.sellingPrice} • Qty: {item.qty} items</span>
                    </div>
                    <div className="flex items-center gap-4">
                      <span className="font-sans font-bold text-slate-800">Rs. {(item.qty * item.sellingPrice).toLocaleString()}/-</span>
                      <button 
                        onClick={() => handleRemoveBasketItem(item.productId)}
                        className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

        </div>

        {/* Cash Register checkout side column (2/5 width) */}
        <div id="checkout-register" className="lg:col-span-2 bg-gradient-to-b from-slate-50 to-white/20 rounded-2xl p-6 border border-slate-100 shadow-sm flex flex-col justify-between">
          <div>
            <h3 className="font-bold text-slate-800 text-base mb-1 inline-flex items-center gap-1.5">
              <Calculator className="w-4 h-4 text-slate-500" />
              Bill Check-out Register
            </h3>
            <p className="text-xs text-slate-400 mb-6">Payment verification settings</p>

            <div className="space-y-4">
              
              {/* Gross total display details */}
              <div className="bg-white p-4 rounded-xl border border-slate-100 shadow-sm flex justify-between items-center">
                <span className="text-xs font-bold text-slate-400 uppercase tracking-widest">{t.grossTotal}</span>
                <span className="text-xl font-black font-mono text-slate-800">Rs. {subTotal.toLocaleString()}/-</span>
              </div>

              {/* Discount custom input row */}
              <div className="space-y-1">
                <label className="text-[10px] font-bold text-slate-400 uppercase block tracking-wider">{t.discountLabel}</label>
                <div className="relative">
                  <Tag className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                  <input 
                    type="number"
                    min="0"
                    placeholder="Enter Custom Discount (PKR)"
                    value={discount}
                    onChange={(e) => setDiscount(Math.max(0, Number(e.target.value)))}
                    className="w-full pl-9 pr-3 py-2 bg-white border border-slate-200 outline-none focus:border-blue-500 text-xs font-mono font-bold rounded-lg transition"
                  />
                </div>
              </div>

              {/* Net total payable */}
              <div className="bg-blue-600 p-4 rounded-xl shadow-lg shadow-blue-100 text-white flex justify-between items-center transition">
                <div>
                  <span className="text-[9px] font-bold uppercase tracking-widest text-blue-100">{t.netTotal}</span>
                  <span className="text-xs font-bold block">Remaining receivable due</span>
                </div>
                <span className="text-2xl font-black font-mono">Rs. {netTotal.toLocaleString()}/-</span>
              </div>

              {/* Cash Paid input row */}
              <div className="space-y-1">
                <div className="flex justify-between items-center">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">{t.cashPaid}</label>
                  <button 
                    type="button"
                    onClick={setCashReceivedExact}
                    disabled={netTotal === 0}
                    className="text-[10px] font-bold text-blue-600 hover:underline"
                  >
                    Set Full Recovery
                  </button>
                </div>
                <div className="relative">
                  <Coins className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                  <input 
                    type="number"
                    min="0"
                    value={cashReceived}
                    onChange={(e) => setCashReceived(Math.max(0, Number(e.target.value)))}
                    className="w-full pl-9 pr-3 py-2.5 bg-white border border-slate-200 outline-none focus:border-blue-500 text-xs font-mono font-bold rounded-lg transition"
                    placeholder="Cash Amount received on drawer"
                  />
                </div>
              </div>

              {/* Outstanding loan warning if client pays partial/unpaid */}
              {selectedClientId !== 'walk-in' && netTotal - cashReceived > 0 && (
                <div className="bg-amber-50 border border-amber-200 text-amber-800 p-3 rounded-xl flex gap-2 items-start text-[11px] leading-relaxed">
                  <AlertCircle className="w-4 h-4 text-amber-600 flex-shrink-0 mt-0.5" />
                  <div>
                    <span className="font-bold block">Outstanding Khata warning:</span>
                    Rs. {(netTotal - cashReceived).toLocaleString()}/- unpaid balance is going to be written into customer's account debt log.
                  </div>
                </div>
              )}

            </div>
          </div>

          <div className="mt-8">
            <button 
              onClick={handleCheckoutSubmit}
              disabled={basket.length === 0}
              className="w-full py-4 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white font-extrabold text-xs tracking-wider rounded-xl transition duration-300 shadow-md shadow-emerald-100 flex items-center justify-center gap-2 uppercase active:scale-98"
            >
              <CheckCircle2 className="w-5 h-5" />
              <span>{t.checkoutBtn}</span>
            </button>
          </div>
        </div>

      </div>

      {/* HISTORICAL INVOICES LEDGER SECTION */}
      <div id="sales-history-ledger" className="bg-white rounded-2xl p-6 border border-slate-100 shadow-sm space-y-4">
        <div>
          <h3 className="font-semibold text-slate-800 text-base">{t.historyTitle}</h3>
          <p className="text-xs text-slate-400">{t.historyDesc}</p>
        </div>

        {sales.length === 0 ? (
          <div className="text-center py-10 bg-slate-50 border border-dashed border-slate-200 rounded-xl p-4 font-medium text-xs text-slate-400">
            {t.noInvoicesYet}
          </div>
        ) : (
          <div className="overflow-x-auto border border-slate-100 rounded-xl text-xs">
            <table className="w-full text-left whitespace-nowrap">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-100 text-slate-400 font-bold uppercase text-[9px]">
                  <th className="py-2.5 px-4">Invoice #</th>
                  <th className="py-2.5 px-4">Customer</th>
                  <th className="py-2.5 px-4 text-center">Items Count</th>
                  <th className="py-2.5 px-4 text-right">Net Amount</th>
                  <th className="py-2.5 px-4 text-center">Payment Status</th>
                  <th className="py-2.5 px-4 text-center">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 font-medium text-slate-700">
                {sales.map(sale => {
                  const itemsCount = sale.items.reduce((sum, item) => sum + item.qty, 0);
                  return (
                    <tr key={sale.id} className="hover:bg-slate-50 transition-colors">
                      <td className="py-3 px-4 font-mono font-bold text-slate-900">{sale.invoiceNumber}</td>
                      <td className="py-3 px-4">
                        <div>
                          <span className="font-bold text-slate-800 block">{sale.clientName}</span>
                          <span className="text-[10px] text-slate-400 font-medium font-sans">Date: {sale.date}</span>
                        </div>
                      </td>
                      <td className="py-3 px-4 text-center font-bold font-mono">{itemsCount}</td>
                      <td className="py-3 px-4 text-right font-sans font-black text-slate-900">
                        Rs. {sale.totalAmount.toLocaleString()}
                      </td>
                      <td className="py-3 px-4 text-center">
                        <span className={`inline-block px-2.5 py-0.5 rounded-full text-[10px] font-extrabold ${
                          sale.paymentStatus === 'Paid' ? 'bg-emerald-50 text-emerald-700' :
                          sale.paymentStatus === 'Partially Paid' ? 'bg-amber-50 text-amber-700' :
                          'bg-rose-50 text-rose-700'
                        }`}>
                          {sale.paymentStatus}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-center">
                        <div className="flex justify-center gap-2">
                          <button 
                            onClick={() => generateInvoicePDF(sale)}
                            className="flex items-center gap-1.5 px-3 py-1.5 bg-blue-50 text-blue-700 font-bold text-[11px] rounded-lg border border-blue-100 hover:bg-blue-100 active:scale-95 transition cursor-pointer"
                          >
                            <FileDown className="w-3.5 h-3.5" />
                            <span>{t.downloadPdf}</span>
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

    </div>
  );
}
