/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  Plus, 
  Trash2, 
  Wallet, 
  ArrowDownRight, 
  DollarSign, 
  AlertCircle, 
  Tag, 
  Receipt, 
  Sparkles,
  Award,
  CircleDollarSign,
  Coffee,
  CheckCircle,
  TrendingDown,
  Settings,
  HardDriveDownload,
  Calendar,
  BarChart2,
  FileText,
  TrendingUp,
  FileDown
} from 'lucide-react';
import { jsPDF } from 'jspdf';
import { Expense, Sale } from '../types';

interface AccountantProps {
  expenses: Expense[];
  sales: Sale[];
  onAddExpense: (expense: Expense) => void;
  onDeleteExpense: (id: string) => void;
  language: 'roman_urdu' | 'urdu' | 'english';
  onResetAllData?: () => void;
}

export default function Accountant({ 
  expenses, 
  sales, 
  onAddExpense, 
  onDeleteExpense,
  language,
  onResetAllData
}: AccountantProps) {

  // Form states
  const [title, setTitle] = useState('');
  const [category, setCategory] = useState('General');
  const [amount, setAmount] = useState(0);

  // Dynamic expense categories state
  const [expenseCategories, setExpenseCategories] = useState<string[]>(() => {
    const saved = localStorage.getItem('bhai_erp_expense_categories');
    return saved ? JSON.parse(saved) : ['General', 'Rent', 'Salary', 'Bill', 'Chai'];
  });
  const [showCategoryManager, setShowCategoryManager] = useState(false);
  const [newCategoryInput, setNewCategoryInput] = useState('');

  const handleCreateCategory = () => {
    const trimmed = newCategoryInput.trim();
    if (!trimmed) return;
    
    // Prevent duplicates (case-insensitive)
    const exists = expenseCategories.some(c => c.toLowerCase() === trimmed.toLowerCase());
    if (exists) {
      alert(language === 'english' ? 'Category already exists!' : 'Yeh category pehle se mojood hai!');
      return;
    }

    const updated = [...expenseCategories, trimmed];
    setExpenseCategories(updated);
    localStorage.setItem('bhai_erp_expense_categories', JSON.stringify(updated));
    setNewCategoryInput('');
  };

  const handleDeleteCategory = (catToDelete: string) => {
    if (catToDelete === 'General') return;
    const updated = expenseCategories.filter(c => c !== catToDelete);
    setExpenseCategories(updated);
    localStorage.setItem('bhai_erp_expense_categories', JSON.stringify(updated));
    
    // If the currently selected category is the deleted one, switch back to 'General'
    if (category === catToDelete) {
      setCategory('General');
    }
  };

  // Monthly Report states
  const [showReportModal, setShowReportModal] = useState(false);
  const [selectedMonth, setSelectedMonth] = useState(() => {
    // Default to the current month in YYYY-MM format
    return new Date().toISOString().slice(0, 7);
  });

  const t = {
    roman_urdu: {
      ledgerTitle: "Khazana & Kharchay (Expense Tracker)",
      addExpense: "Naya Kharcha (Add Expense)",
      grossProfit: "Sari Bikri Munafa (Gross Profit)",
      netProfit: "Net Munafa (Net Profit)",
      totalExpensesCount: "Kul Kharchay (Total Expenses)",
      expenseTitle: "Kharchay Ka Title",
      amountLabel: "Kharchay Ki Raqam",
      tableTitle: "Haliya Kharchay Ki Fehrist",
      categoryGeneral: "Aam Kharcha",
      categoryRent: "Dukan Ka Kiraya",
      categorySalary: "Mulazim ki tankhwah",
      categoryBill: "Bijli/Gas Bills",
      categoryChai: "Chai/Chana Bill",
      noExpenses: "Dukan k koi kharchay abhi record nahi hain. Mubarak!",
      profitSuccess: "Masha'Allah! Aap ka business munafay me hai.",
      profitLoss: "Khabardaar! Kharchay zyada ho gae hain, munafa kam hai.",
      settingsTitle: "Dukan Settings & Data Hifazat (Security)",
      settingsDesc: "Apni dukan ka sara data mehfooz (safe) rakhney k liye backup file download karein.",
      backupBtn: "System Backup Download Karein",
      generateMonthlyReport: "Monthly Report",
      monthlyReportTitle: "Mahana Karobari Summary",
      monthlyReportDesc: "Ek mahinay ki mukammal bikri, kharchay, aur saaf munafa ka khulasa.",
      chooseMonth: "Mahina Select Karein:",
      numSales: "Kul Invoices Parchi:",
      grossSalesVal: "Bikri Turnover (Sales):",
      totalProfitVal: "Khair/Bachat (Gross Profit):",
      totalExpensesVal: "Kul Kharchay (Expenses):",
      netProfitVal: "Miyan (Net Profit):",
      closeReport: "Theek Hai (Close)",
      downloadReportPdf: "Report Download (PDF)",
      manageCategories: "Expense Categories Manage Karein",
      addCategoryBtn: "Add Karein",
      categoryPlaceholder: "Nayi category, e.g. Transport"
    },
    urdu: {
      ledgerTitle: "کھاتہ اخراجات (اضافی اخراجات کا ریکارڈ)",
      addExpense: "نیا خرچہ درج کریں",
      grossProfit: "کل بکری کا منافع",
      netProfit: "خالص منافع",
      totalExpensesCount: "کل اخراجات کی رقم",
      expenseTitle: "خرچہ کا عنوان",
      amountLabel: "رقم",
      tableTitle: "حالیہ اخراجات کی تفصیل",
      categoryGeneral: "عام اخراجات",
      categoryRent: "دکان کا کرایہ",
      categorySalary: "ملازمین کی تنخواہ",
      categoryBill: "بجلی اور گیس کا بل",
      categoryChai: "چائے اور کھانا کا خرچہ",
      noExpenses: "ابھی تک کوئی اضافی خرچہ درج نہیں ہوا ہے۔ بہترین!",
      profitSuccess: "ماشاءاللہ! کاروبار نفع بخش پوزیشن میں ہے۔",
      profitLoss: "ہوشیار! آپ کے اخراجات منافع سے زیادہ ہو رہے ہیں۔",
      settingsTitle: "ترجیحات اور ڈیٹا کی حفاظت (سیکیورٹی)",
      settingsDesc: "اپنے کاروبار اور دکان کا تمام ڈیٹا محفوظ رکھنے کے لیے بیک اب فائل ڈاؤن لوڈ کریں۔",
      backupBtn: "سستم ڈیٹا بیک آپ ڈاؤن لوڈ کریں",
      generateMonthlyReport: "ماہانہ رپورٹ",
      monthlyReportTitle: "ماہانہ کاروباری رپورٹ کارکردگی",
      monthlyReportDesc: "موجودہ منتخب مہینے کے کل سیلز، اخراجات، اور نیٹ مٹکا منافع کی تفصیل۔",
      chooseMonth: "مہینہ تبدیل کریں:",
      numSales: "کل جاری کردہ بلز:",
      grossSalesVal: "کل فروخت ٹرن اوور:",
      totalProfitVal: "مجموعی بکری منافع:",
      totalExpensesVal: "کل اخراجات (رقم):",
      netProfitVal: "خالص بچت منافع:",
      closeReport: "ٹھیک ہے (بند کریں)",
      downloadReportPdf: "رپورٹ پی ڈی ایف ڈاؤن لوڈ کریں",
      manageCategories: "ذیلی زمرہ جات تبدیل کریں",
      addCategoryBtn: "شامل کریں",
      categoryPlaceholder: "نیا زمرہ جیسے ٹرانسپورٹ"
    },
    english: {
      ledgerTitle: "Financial General Ledger & Expense Manager",
      addExpense: "Log New Shop Expense",
      grossProfit: "Accumulated Gross Profits",
      netProfit: "Net Business Margin",
      totalExpensesCount: "Total Logged Expenses",
      expenseTitle: "Expense Description",
      amountLabel: "Cash Outflow Amount",
      tableTitle: "Recent Deficit Expense Records",
      categoryGeneral: "General Outflow",
      categoryRent: "Shop Renting cost",
      categorySalary: "Wages & Salaries",
      categoryBill: "Electricity / Utility charges",
      categoryChai: "Entertainment / Chai / Meal logs",
      noExpenses: "No business expenditures registered in this session yet.",
      profitSuccess: "Masha'Allah! Shop is generating positive net margins.",
      profitLoss: "Warning! Shop expenditures exceed earnings. Review operations.",
      settingsTitle: "Enterprise Configuration & Data Security",
      settingsDesc: "Download an instant copy of your entire local ERP database instance to protect against session losses.",
      backupBtn: "Download System Data Backup",
      generateMonthlyReport: "Monthly Report",
      monthlyReportTitle: "Monthly Performance Statement",
      monthlyReportDesc: "Overview of invoice count, billing, margin gains, and expense categories for the selected calendar month.",
      chooseMonth: "Select Statement Month:",
      numSales: "Total Invoice Count:",
      grossSalesVal: "Total Sales Turnover:",
      totalProfitVal: "Estimated Gross Profit:",
      totalExpensesVal: "Total Logged Outflows:",
      netProfitVal: "Net Operating Margins:",
      closeReport: "Close Report View",
      downloadReportPdf: "Export Report to PDF",
      manageCategories: "Customize Expense Labels",
      addCategoryBtn: "Add Category",
      categoryPlaceholder: "New category, e.g. Transport"
    }
  }[language];

  // Calculations
  const grossProfit = sales.reduce((acc, s) => acc + s.profit, 0);
  const totalExpenses = expenses.reduce((acc, e) => acc + e.amount, 0);
  const netProfit = grossProfit - totalExpenses;

  // Monthly breakdown calculations
  const monthSales = sales.filter(s => s.date.startsWith(selectedMonth));
  const monthExpenses = expenses.filter(e => e.date.startsWith(selectedMonth));

  const monthSalesCount = monthSales.length;
  const monthTotalSalesValue = monthSales.reduce((acc, s) => acc + s.totalAmount, 0);
  const monthGrossProfit = monthSales.reduce((acc, s) => acc + s.profit, 0);
  const monthTotalExpenses = monthExpenses.reduce((acc, e) => acc + e.amount, 0);
  const monthNetProfit = monthGrossProfit - monthTotalExpenses;

  // Monthly category-wise breakups
  const monthCategoryExpenses: Record<string, number> = {};
  monthExpenses.forEach(e => {
    monthCategoryExpenses[e.category] = (monthCategoryExpenses[e.category] || 0) + e.amount;
  });

  // Unique list of YYYY-MM months available in system for users to select
  const availableMonthsSet = new Set<string>();
  // Seed with current month always
  availableMonthsSet.add(new Date().toISOString().slice(0, 7));
  sales.forEach(s => {
    if (s.date && s.date.length >= 7) {
      availableMonthsSet.add(s.date.slice(0, 7));
    }
  });
  expenses.forEach(e => {
    if (e.date && e.date.length >= 7) {
      availableMonthsSet.add(e.date.slice(0, 7));
    }
  });
  const availableMonthsList = Array.from(availableMonthsSet).sort((a, b) => b.localeCompare(a));

  const generateMonthlyReportPDF = () => {
    const doc = new jsPDF({
      orientation: 'portrait',
      unit: 'mm',
      format: 'a4'
    });

    const primaryColor = [30, 41, 59]; // slate-800
    const accentColor = [37, 99, 235]; // blue-600
    const textColor = [51, 65, 85]; // slate-700
    const borderGrey = [226, 232, 240];

    // Header Panel
    doc.setFillColor(primaryColor[0], primaryColor[1], primaryColor[2]);
    doc.rect(0, 0, 210, 40, 'F');

    doc.setTextColor(255, 255, 255);
    doc.setFont('Helvetica', 'bold');
    doc.setFontSize(22);
    doc.text('SIANA ERP & LOGISTICS', 15, 18);

    doc.setFont('Helvetica', 'normal');
    doc.setFontSize(10);
    doc.setTextColor(191, 219, 254);
    doc.text('Premium Business Management & Khata Suite', 15, 25);
    doc.text(`MONTHLY BUSINESS PERFORMANCE STATEMENT - ${selectedMonth}`, 15, 30);

    // Block Date Badge
    doc.setFillColor(accentColor[0], accentColor[1], accentColor[2]);
    doc.rect(142, 10, 53, 12, 'F');
    doc.setTextColor(255, 255, 255);
    doc.setFont('Helvetica', 'bold');
    doc.setFontSize(9.5);
    doc.text(`REPORT: ${selectedMonth}`, 147, 18);

    // Business Summary Title
    doc.setTextColor(30, 41, 59);
    doc.setFont('Helvetica', 'bold');
    doc.setFontSize(11);
    doc.text('KEY PERFORMANCE SUMMARY', 15, 52);
    doc.setLineWidth(0.4);
    doc.setDrawColor(borderGrey[0], borderGrey[1], borderGrey[2]);
    doc.line(15, 55, 195, 55);

    // Grid details
    doc.setFont('Helvetica', 'normal');
    doc.setFontSize(10);
    doc.setTextColor(textColor[0], textColor[1], textColor[2]);

    doc.text('Selected Statement Month:', 15, 63);
    doc.setFont('Helvetica', 'bold');
    doc.text(`${selectedMonth}`, 65, 63);

    doc.setFont('Helvetica', 'normal');
    doc.text('Total Invoice Count:', 15, 70);
    doc.setFont('Helvetica', 'bold');
    doc.text(`${monthSalesCount} Transactions`, 65, 70);

    doc.setFont('Helvetica', 'normal');
    doc.text('Total Sales Turnover:', 15, 77);
    doc.setFont('Helvetica', 'bold');
    doc.text(`Rs. ${monthTotalSalesValue.toLocaleString()}`, 65, 77);

    doc.setFont('Helvetica', 'normal');
    doc.text('Gross Profit (Bachaat):', 15, 84);
    doc.setFont('Helvetica', 'bold');
    doc.text(`Rs. ${monthGrossProfit.toLocaleString()}`, 65, 84);

    doc.setFont('Helvetica', 'normal');
    doc.text('Total Logged Expenses:', 15, 91);
    doc.setFont('Helvetica', 'bold');
    doc.text(`Rs. ${monthTotalExpenses.toLocaleString()}`, 65, 91);

    doc.setDrawColor(borderGrey[0], borderGrey[1], borderGrey[2]);
    doc.line(15, 96, 195, 96);

    // Net Margin Highlight Block
    doc.setFillColor(248, 250, 252);
    doc.rect(15, 101, 180, 16, 'F');
    doc.setFont('Helvetica', 'bold');
    doc.setFontSize(11);
    doc.setTextColor(primaryColor[0], primaryColor[1], primaryColor[2]);
    doc.text('NET OPERATING MARGINS:', 20, 111);

    if (monthNetProfit >= 0) {
      doc.setTextColor(16, 185, 129); // emerald-600
    } else {
      doc.setTextColor(220, 38, 38); // red-600
    }
    doc.text(`Rs. ${monthNetProfit.toLocaleString()}/-`, 100, 111);

    // Expense Categories Breakdown
    doc.setTextColor(primaryColor[0], primaryColor[1], primaryColor[2]);
    doc.setFont('Helvetica', 'bold');
    doc.setFontSize(11);
    doc.text('EXPENSE CATEGORIES BREAKDOWN', 15, 132);
    doc.line(15, 135, 195, 135);

    doc.setFont('Helvetica', 'bold');
    doc.setFontSize(9);
    doc.setTextColor(71, 85, 105);
    doc.text('LOGGED CATEGORY', 25, 143);
    doc.text('TOTAL AMOUNT SPENT', 185, 143, { align: 'right' });

    let currentY = 150;
    const categoriesList = Object.keys(monthCategoryExpenses);
    if (categoriesList.length === 0) {
      doc.setFont('Helvetica', 'italic');
      doc.setFontSize(9.5);
      doc.setTextColor(148, 163, 184);
      doc.text('No expenses logged for this month.', 25, currentY);
      currentY += 8;
    } else {
      categoriesList.forEach((cat) => {
        doc.setFont('Helvetica', 'bold');
        doc.setFontSize(9.5);
        doc.setTextColor(30, 41, 59);
        doc.text(cat, 25, currentY);

        doc.setFont('Helvetica', 'normal');
        doc.text(`Rs. ${monthCategoryExpenses[cat].toLocaleString()}/-`, 185, currentY, { align: 'right' });

        doc.setLineWidth(0.15);
        doc.setDrawColor(borderGrey[0], borderGrey[1], borderGrey[2]);
        doc.line(15, currentY + 3.5, 195, currentY + 3.5);

        currentY += 9;
      });
    }

    // Footnotes branding
    doc.setFont('Helvetica', 'oblique');
    doc.setFontSize(9);
    doc.setTextColor(148, 163, 184);
    doc.text('Shukriya! Siana ERP Business Analytics Center.', 105, 273, { align: 'center' });

    doc.setFont('Helvetica', 'normal');
    doc.setFontSize(8);
    doc.text('This is an official computer-formatted ledger report generated securely on Siana ERP.', 105, 278, { align: 'center' });

    doc.save(`Monthly_Report_${selectedMonth}.pdf`);
  };

  const handleDownloadBackup = () => {
    const backupData: Record<string, string> = {};
    for (let i = 0; i < localStorage.length; i++) {
      const key = localStorage.key(i);
      if (key) {
        backupData[key] = localStorage.getItem(key) || '';
      }
    }

    const dataStr = JSON.stringify(backupData, null, 2);
    const blob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    
    const link = document.createElement('a');
    link.href = url;
    const dateStr = new Date().toISOString().split('T')[0];
    link.download = `Siana_ERP_Database_Backup_${dateStr}.json`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || amount <= 0) return;

    const newExpense: Expense = {
      id: 'EXP-' + Date.now().toString().slice(-5),
      title: title.trim(),
      amount: Number(amount),
      category: category,
      date: new Date().toISOString().split('T')[0]
    };

    onAddExpense(newExpense);
    
    // reset form
    setTitle('');
    setCategory('General');
    setAmount(0);
  };

  // Icon mapping for categories
  const getCategoryIcon = (cat: string) => {
    switch (cat) {
      case 'Chai':
        return <Coffee className="w-4 h-4 text-amber-600" />;
      case 'Rent':
        return <Receipt className="w-4 h-4 text-violet-600" />;
      case 'Salary':
        return <Award className="w-4 h-4 text-emerald-600" />;
      case 'Bill':
        return <Wallet className="w-4 h-4 text-blue-600" />;
      default:
        return <Tag className="w-4 h-4 text-slate-500" />;
    }
  };

  return (
    <div className="space-y-6" id="accountant-tab">
      
      {/* 1. Profit & Loss Status Card Bar */}
      <div className={`p-5 rounded-2xl border flex flex-col md:flex-row justify-between items-center gap-4 ${
        netProfit >= 0 
          ? 'bg-emerald-50/50 border-emerald-100 text-emerald-900' 
          : 'bg-rose-50 border-rose-100 text-rose-900'
      }`}>
        <div className="flex items-center gap-3">
          <span className={`p-3 rounded-xl ${netProfit >= 0 ? 'bg-emerald-100 text-emerald-700' : 'bg-rose-100 text-rose-700'}`}>
            <CircleDollarSign className="w-6 h-6" />
          </span>
          <div>
            <h4 className="font-extrabold text-base">{netProfit >= 0 ? t.profitSuccess : t.profitLoss}</h4>
            <p className="text-xs text-slate-500 mt-0.5">Automated accounting ledger health auditing</p>
          </div>
        </div>
        
        <div className="flex gap-4 items-center">
          <button
            onClick={() => setShowReportModal(true)}
            className="flex items-center gap-2 px-4 py-2.5 bg-white text-slate-800 border border-slate-200/80 hover:border-blue-500 hover:text-blue-600 rounded-xl text-xs font-bold transition-all duration-150 shadow-sm hover:shadow active:scale-95 cursor-pointer"
          >
            <BarChart2 className="w-4 h-4 text-blue-500" />
            <span>{t.generateMonthlyReport}</span>
          </button>

          <div className="text-right border-l border-slate-200 pl-4">
            <span className="text-[10px] uppercase font-bold text-slate-400 block tracking-wider">{t.netProfit}</span>
            <span className={`text-2xl font-black font-mono block ${netProfit >= 0 ? 'text-emerald-700' : 'text-rose-700'}`}>
              Rs. {netProfit.toLocaleString()}/-
            </span>
          </div>
        </div>
      </div>

      {/* 2. Bento Panel Rows */}
      <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
        
        {/* Log expense Form (2/5 width) */}
        <div id="add-expense-form" className="lg:col-span-2 bg-white rounded-2xl p-6 border border-slate-100 shadow-sm space-y-4">
          <div>
            <h3 className="font-semibold text-slate-800 text-base">{t.addExpense}</h3>
            <p className="text-xs text-slate-400">Record payments to keep profit calculated accurately</p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4 text-xs font-semibold">
            
            {/* Title */}
            <div>
              <label className="text-[10px] uppercase font-bold text-slate-400 block mb-1.5">{t.expenseTitle}</label>
              <input 
                type="text"
                required
                placeholder="e.g. Mulazim ki tankhwah / Chai Ka Bill"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                className="w-full p-2.5 bg-slate-50 border border-slate-200 outline-none focus:border-blue-500 rounded-lg font-semibold"
              />
            </div>

            {/* Category selection */}
            <div>
              <div className="flex justify-between items-center mb-1.5">
                <label className="text-[10px] uppercase font-bold text-slate-400">Category</label>
                <button
                  type="button"
                  onClick={() => setShowCategoryManager(!showCategoryManager)}
                  className="text-[10px] text-blue-600 hover:text-blue-700 font-bold flex items-center gap-1 cursor-pointer transition"
                >
                  <Settings className="w-3 h-3" />
                  <span>{t.manageCategories.split(' ')[0]}</span>
                </button>
              </div>
              <select 
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                className="w-full p-2.5 bg-slate-50 border border-slate-200 outline-none focus:border-blue-500 rounded-lg font-bold"
              >
                {expenseCategories.map(cat => (
                  <option key={cat} value={cat}>
                    {cat === 'General' ? t.categoryGeneral || 'General' : 
                     cat === 'Rent' ? t.categoryRent || 'Rent' : 
                     cat === 'Salary' ? t.categorySalary || 'Salary' : 
                     cat === 'Bill' ? t.categoryBill || 'Bill' : 
                     cat === 'Chai' ? t.categoryChai || 'Chai' : cat}
                  </option>
                ))}
              </select>
            </div>

            {/* Inline Dynamic Category Management Panel */}
            {showCategoryManager && (
              <div className="p-3 bg-slate-50 border border-slate-200/60 rounded-xl space-y-3 animate-in fade-in duration-150">
                <div className="flex justify-between items-center text-[10px] text-slate-400 font-bold uppercase tracking-wider">
                  <span>{t.manageCategories}</span>
                </div>
                
                {/* Visual pill badges with delete buttons */}
                <div className="flex flex-wrap gap-1.5 max-h-[120px] overflow-y-auto pr-1">
                  {expenseCategories.map(cat => (
                    <div 
                      key={cat} 
                      className="flex items-center gap-1 pl-2.5 pr-1 py-1 bg-white border border-slate-200/60 rounded-lg text-[11px] font-bold text-slate-700 select-none"
                    >
                      <span>
                        {cat === 'General' ? t.categoryGeneral || 'General' : 
                         cat === 'Rent' ? t.categoryRent || 'Rent' : 
                         cat === 'Salary' ? t.categorySalary || 'Salary' : 
                         cat === 'Bill' ? t.categoryBill || 'Bill' : 
                         cat === 'Chai' ? t.categoryChai || 'Chai' : cat}
                      </span>
                      {cat !== 'General' && (
                        <button
                          type="button"
                          onClick={() => handleDeleteCategory(cat)}
                          className="p-0.5 text-slate-300 hover:text-rose-600 hover:bg-rose-50 rounded transition cursor-pointer"
                        >
                          <Trash2 className="w-3 h-3" />
                        </button>
                      )}
                    </div>
                  ))}
                </div>

                {/* Direct category creator controls */}
                <div className="flex gap-2">
                  <input
                    type="text"
                    placeholder={t.categoryPlaceholder}
                    value={newCategoryInput}
                    onChange={(e) => setNewCategoryInput(e.target.value)}
                    className="flex-1 p-2 bg-white border border-slate-200 outline-none focus:border-blue-500 rounded-lg text-[11px] font-bold"
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        e.preventDefault();
                        handleCreateCategory();
                      }
                    }}
                  />
                  <button
                    type="button"
                    onClick={handleCreateCategory}
                    className="px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-[10px] font-bold active:scale-95 transition cursor-pointer shrink-0"
                  >
                    {t.addCategoryBtn}
                  </button>
                </div>
              </div>
            )}

            {/* Amount */}
            <div>
              <label className="text-[10px] uppercase font-bold text-slate-400 block mb-1.5">{t.amountLabel}</label>
              <input 
                type="number"
                required
                min="1"
                value={amount}
                onChange={(e) => setAmount(Number(e.target.value))}
                className="w-full p-3 bg-slate-50 border border-slate-200 outline-none focus:border-blue-500 rounded-xl font-bold font-mono text-base"
                placeholder="Rs. Cash Outflow Amount"
              />
            </div>

            <button 
              type="submit"
              className="w-full py-3 bg-slate-900 hover:bg-slate-800 text-white font-bold rounded-xl transition duration-300 shadow-md shadow-slate-100 flex items-center justify-center gap-1.5"
            >
              <Plus className="w-4 h-4 text-emerald-400" />
              <span>Record Shop Expense</span>
            </button>

          </form>
        </div>

        {/* Ledger logs columns & calculations details (3/5 width) */}
        <div id="expense-history" className="lg:col-span-3 bg-white rounded-2xl p-6 border border-slate-100 shadow-sm flex flex-col justify-between">
          <div>
            <div className="flex justify-between items-center mb-4">
              <div>
                <h3 className="font-semibold text-slate-800 text-base">{t.tableTitle}</h3>
                <p className="text-xs text-slate-400">Total expense registries: Rs. {totalExpenses.toLocaleString()}</p>
              </div>
            </div>

            {expenses.length === 0 ? (
              <div className="text-center py-20 bg-slate-50 border border-dashed border-slate-200 rounded-xl p-4 font-medium text-xs text-slate-400">
                {t.noExpenses}
              </div>
            ) : (
              <div className="overflow-y-auto max-h-[340px] border border-slate-100 rounded-xl text-xs">
                <table className="w-full text-left whitespace-nowrap">
                  <thead>
                    <tr className="bg-slate-50 border-b border-slate-100 text-slate-400 font-bold uppercase text-[9px]">
                      <th className="py-2.5 px-4">Title / Category</th>
                      <th className="py-2.5 px-4 text-center">Date</th>
                      <th className="py-2.5 px-4 text-right">Amount Out (Rs)</th>
                      <th className="py-2.5 px-4 text-center">Action</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {expenses.map(exp => (
                      <tr key={exp.id} className="hover:bg-slate-50 transition-colors font-medium text-slate-700">
                        
                        <td className="py-3 px-4 flex items-center gap-2.5">
                          <span className="p-1.5 bg-slate-100 rounded-lg">{getCategoryIcon(exp.category)}</span>
                          <div>
                            <span className="font-bold text-slate-900 block">{exp.title}</span>
                            <span className="text-[10px] text-slate-400 font-medium">{exp.category}</span>
                          </div>
                        </td>

                        <td className="py-3 px-4 text-center font-mono text-slate-400 font-semibold">{exp.date}</td>

                        <td className="py-3 px-4 text-right font-sans font-bold text-slate-900">
                          -Rs. {exp.amount.toLocaleString()}
                        </td>

                        <td className="py-3 px-4 text-center">
                          <button 
                            onClick={() => onDeleteExpense(exp.id)}
                            className="p-1 text-slate-450 hover:text-rose-600 rounded"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </td>

                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>

          <div className="mt-6 p-4 rounded-xl border border-slate-100 bg-slate-50/50 flex justify-between text-xs font-semibold text-slate-600 items-center">
            <span className="inline-flex items-center gap-1"><CheckCircle className="w-4 h-4 text-emerald-500" /> Accounts Audited</span>
            <span className="font-mono text-[10px] text-slate-400">Total balance: Rs. {grossProfit.toLocaleString()} (In) - Rs. {totalExpenses.toLocaleString()} (Out)</span>
          </div>

        </div>

      </div>

      {/* 3. System Data Preservations Settings & Backup Center */}
      <div id="settings-backup-system" className="bg-white rounded-2xl p-6 border border-slate-100 shadow-sm">
        <div className="flex flex-col xl:flex-row items-start xl:items-center justify-between gap-5">
          <div className="flex items-start gap-3.5">
            <span className="p-3 bg-blue-50 text-blue-600 rounded-xl mt-0.5">
              <Settings className="w-5.5 h-5.5" />
            </span>
            <div className="space-y-1">
              <h3 className="font-bold text-slate-800 text-sm md:text-base flex items-center gap-2">
                {t.settingsTitle}
              </h3>
              <p className="text-xs text-slate-400 leading-relaxed font-semibold">
                {t.settingsDesc}
              </p>
            </div>
          </div>
          
          <div className="flex flex-col sm:flex-row gap-3 w-full xl:w-auto">
            <button 
              onClick={handleDownloadBackup}
              className="flex items-center justify-center gap-2 px-5 py-3.5 bg-blue-600 hover:bg-blue-700 text-white text-xs font-black rounded-xl shadow-md shadow-blue-600/15 duration-200 active:scale-95 transition-all w-full sm:w-auto text-center cursor-pointer"
            >
              <HardDriveDownload className="w-4 h-4 text-blue-100" />
              <span>{t.backupBtn}</span>
            </button>

            {onResetAllData && (
              <button 
                onClick={onResetAllData}
                className="flex items-center justify-center gap-2 px-5 py-3.5 bg-rose-600 hover:bg-rose-700 text-white text-xs font-black rounded-xl shadow-md shadow-rose-600/15 duration-200 active:scale-95 transition-all w-full sm:w-auto text-center cursor-pointer"
              >
                <Trash2 className="w-4 h-4 text-rose-100" />
                <span>{language === 'english' ? 'Clear All Data' : language === 'urdu' ? 'تمام ڈیٹا صاف کریں' : 'Sara Data Saaf Karein'}</span>
              </button>
            )}
          </div>
        </div>
      </div>

      {/* 4. Interactive Analytical Monthly Performance Statement Modal */}
      {showReportModal && (
        <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-sm z-50 flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white rounded-3xl w-full max-w-2xl border border-slate-100 shadow-2xl overflow-hidden max-h-[92vh] flex flex-col animate-in fade-in zoom-in duration-200">
            
            {/* Modal Header */}
            <div className="bg-slate-900 p-6 text-white relative">
              <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                <div className="space-y-1">
                  <span className="text-[10px] uppercase font-bold tracking-widest text-blue-400 block">Siana ERP Financial Center</span>
                  <h3 className="text-lg md:text-xl font-black flex items-center gap-2">
                    <BarChart2 className="w-5 h-5 text-blue-500" />
                    <span>{t.monthlyReportTitle} ({selectedMonth})</span>
                  </h3>
                  <p className="text-xs text-slate-400 font-medium">
                    {t.monthlyReportDesc}
                  </p>
                </div>

                {/* Dropdown calendar month switcher */}
                <div className="bg-slate-850 p-2 rounded-xl border border-slate-800 flex items-center gap-2.5 text-xs font-bold w-full md:w-auto">
                  <Calendar className="w-4 h-4 text-blue-500 shrink-0" />
                  <span className="text-[10px] text-slate-400 block uppercase font-extrabold">{t.chooseMonth}</span>
                  <select
                    value={selectedMonth}
                    onChange={(e) => setSelectedMonth(e.target.value)}
                    className="bg-transparent text-white outline-none font-bold font-mono pl-1 cursor-pointer"
                  >
                    {availableMonthsList.map(m => (
                      <option key={m} value={m} className="bg-slate-900 text-white font-mono">{m}</option>
                    ))}
                  </select>
                </div>
              </div>
            </div>

            {/* Modal Body ScrollArea */}
            <div className="p-6 overflow-y-auto space-y-6 flex-1">
              
              {/* Performance Key metrics Grid */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                
                {/* Sale count */}
                <div className="p-4 bg-slate-50 border border-slate-100 rounded-2xl flex flex-col justify-between">
                  <div>
                    <span className="text-[9px] uppercase font-bold text-slate-400 tracking-wider block">{t.numSales}</span>
                    <span className="text-lg font-black font-mono text-slate-800 block mt-1">{monthSalesCount}</span>
                  </div>
                  <span className="text-[10px] text-slate-400 font-semibold block mt-1">Invoices Issued</span>
                </div>

                {/* Turnover */}
                <div className="p-4 bg-slate-50 border border-slate-100 rounded-2xl flex flex-col justify-between">
                  <div>
                    <span className="text-[9px] uppercase font-bold text-slate-400 tracking-wider block">{t.grossSalesVal}</span>
                    <span className="text-sm md:text-base font-black font-sans text-slate-800 truncate block mt-1">
                      Rs. {monthTotalSalesValue.toLocaleString()}
                    </span>
                  </div>
                  <span className="text-[10px] text-slate-400 font-semibold block mt-1">Sales turnover</span>
                </div>

                {/* Gross Profit */}
                <div className="p-4 bg-slate-50 border border-slate-100 rounded-2xl flex flex-col justify-between">
                  <div>
                    <span className="text-[9px] uppercase font-bold text-slate-400 tracking-wider block">{t.totalProfitVal}</span>
                    <span className="text-sm md:text-base font-black text-emerald-600 block mt-1">
                      Rs. {monthGrossProfit.toLocaleString()}
                    </span>
                  </div>
                  <span className="text-[10px] text-emerald-500/80 font-bold block mt-1">Gross Margin</span>
                </div>

                {/* Spend */}
                <div className="p-4 bg-slate-50 border border-slate-100 rounded-2xl flex flex-col justify-between">
                  <div>
                    <span className="text-[9px] uppercase font-bold text-slate-400 tracking-wider block">{t.totalExpensesVal}</span>
                    <span className="text-sm md:text-base font-black text-rose-500 block mt-1">
                      -Rs. {monthTotalExpenses.toLocaleString()}
                    </span>
                  </div>
                  <span className="text-[10px] text-rose-400 font-bold block mt-1">Total spendout</span>
                </div>

              </div>

              {/* Net PNL Banner */}
              <div className={`p-4 rounded-2xl border flex items-center justify-between ${
                monthNetProfit >= 0 ? 'bg-emerald-50/50 border-emerald-100/60 text-emerald-950' : 'bg-rose-50 border-rose-100 text-rose-950'
              }`}>
                <div className="flex items-center gap-2.5">
                  <span className={`p-2 rounded-lg ${monthNetProfit >= 0 ? 'bg-emerald-100 text-emerald-700' : 'bg-rose-100 text-rose-700'}`}>
                    <CircleDollarSign className="w-5 h-5" />
                  </span>
                  <div>
                    <span className="text-[9px] uppercase font-black text-slate-400 block tracking-wider">{t.netProfitVal}</span>
                    <span className="text-xs font-bold block">
                      {monthNetProfit >= 0 ? "Masha'Allah profit status registered" : "Loss registered during this tracking period"}
                    </span>
                  </div>
                </div>
                <div className="text-right">
                  <span className={`text-xl font-bold font-mono tracking-tight block ${monthNetProfit >= 0 ? 'text-emerald-700' : 'text-rose-700'}`}>
                    Rs. {monthNetProfit.toLocaleString()}/-
                  </span>
                </div>
              </div>

              {/* Expense Categories breakdown details */}
              <div className="space-y-3.5">
                <div className="flex items-center justify-between border-b border-slate-100 pb-2">
                  <h4 className="font-extrabold text-slate-800 text-xs uppercase tracking-wider flex items-center gap-1.5">
                    <FileText className="w-4 h-4 text-slate-400" />
                    <span>Dukan Outflow Categories Breakdown</span>
                  </h4>
                  <span className="text-[10px] text-slate-400 font-bold">Category total relative shares</span>
                </div>

                {Object.keys(monthCategoryExpenses).length === 0 ? (
                  <div className="text-center py-6 bg-slate-50/50 border border-dashed border-slate-100 rounded-xl text-xs font-semibold text-slate-400">
                    Is mahinay me abhi dukan ka koi kharcha record nahi kiya gaya.
                  </div>
                ) : (
                  <div className="space-y-4">
                    {Object.keys(monthCategoryExpenses).map(cat => {
                      const amountSpent = monthCategoryExpenses[cat];
                      const pctShare = monthTotalExpenses > 0 ? Math.round((amountSpent / monthTotalExpenses) * 100) : 0;
                      return (
                        <div key={cat} className="space-y-2">
                          <div className="flex justify-between items-center text-xs font-bold text-slate-700">
                            <span className="flex items-center gap-2 text-slate-800">
                              <span className="p-1 bg-slate-50 border border-slate-100 rounded-lg">{getCategoryIcon(cat)}</span>
                              <span>{cat === 'General' ? t.categoryGeneral : cat === 'Rent' ? t.categoryRent : cat === 'Salary' ? t.categorySalary : cat === 'Bill' ? t.categoryBill : t.categoryChai}</span>
                            </span>
                            <span className="font-mono text-slate-900">
                              Rs. {amountSpent.toLocaleString()}/- <span className="text-slate-400 font-sans font-bold ml-1">({pctShare}%)</span>
                            </span>
                          </div>
                          
                          {/* Visual progress bar bar indicator */}
                          <div className="w-full bg-slate-150 rounded-full h-2">
                            <div 
                              className={`h-2 rounded-full duration-500 transition-all ${
                                cat === 'Rent' ? 'bg-violet-500' :
                                cat === 'Salary' ? 'bg-emerald-500' :
                                cat === 'Bill' ? 'bg-blue-500' :
                                cat === 'Chai' ? 'bg-amber-500' : 'bg-slate-400'
                              }`}
                              style={{ width: `${pctShare}%` }}
                            ></div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>

            </div>

            {/* Modal Actions Footer */}
            <div className="bg-slate-50 p-4 border-t border-slate-100 flex flex-col sm:flex-row gap-3">
              <button
                onClick={generateMonthlyReportPDF}
                className="flex items-center justify-center gap-2 px-5 py-3.5 bg-blue-600 hover:bg-blue-700 text-white font-black text-xs rounded-xl shadow-lg shadow-blue-600/10 cursor-pointer active:scale-95 transition flex-1"
              >
                <FileDown className="w-4 h-4 text-blue-100" />
                <span>{t.downloadReportPdf}</span>
              </button>
              
              <button
                onClick={() => setShowReportModal(false)}
                className="flex items-center justify-center py-3.5 border border-slate-200 hover:bg-slate-100 text-slate-700 font-extrabold text-xs rounded-xl duration-150 active:scale-95 transition sm:px-8 cursor-pointer"
              >
                <span>{t.closeReport}</span>
              </button>
            </div>

          </div>
        </div>
      )}

    </div>
  );
}
