/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { 
  Sparkles, 
  Send, 
  Bot, 
  HelpCircle, 
  Loader2, 
  MessageSquare, 
  Compass, 
  RefreshCw, 
  ShieldCheck,
  TrendingUp,
  AlertTriangle,
  Coins,
  Globe
} from 'lucide-react';
import { Product, Client, Sale, Expense } from '../types';

interface AiAdvisorProps {
  products: Product[];
  clients: Client[];
  sales: Sale[];
  expenses: Expense[];
  language: 'roman_urdu' | 'urdu' | 'english';
}

export default function AiAdvisor({ 
  products, 
  clients, 
  sales, 
  expenses,
  language 
}: AiAdvisorProps) {

  // Current selected visual tab language context for AI
  const [aiLanguage, setAiLanguage] = useState<'roman_urdu' | 'urdu' | 'english'>(language);

  // Chat message thread
  const [chatLog, setChatLog] = useState<{ role: 'user' | 'assistant'; text: string }[]>([]);
  const [isThinking, setIsThinking] = useState(false);
  const [customPrompt, setCustomPrompt] = useState('');

  // Siana Munim initial welcome prompt greeting on load!
  useEffect(() => {
    // Determine language specific greeting
    const welcome = {
      roman_urdu: "Assalam-o-Alaikum bhai jaan! Main hoon aap ka 'Bhai AI Accountant Munim'. Main ne aap ki dukan ka khata aur stocks ka gehra jaiza le liya hai. Neeche diye gae fast buttons dabayein ya koi bhi sawal poochein, main foran apnay business stats ka mukamil audit kar k behtareen mashwara dunga!",
      urdu: "السلام علیکم بھائی جان! میں ہوں آپ کا ذہین محاسب (AI Munim)۔ میں نے آپ کی دکان کے اسٹاک اور کھاتوں کا جائزہ لے لیا ہے۔ کسی بھی سوال کا جواب جاننے کے لئے نیچے دیئے گئے بٹن دبائیں یا اپنا سوال ٹائپ کریں۔",
      english: "Welcome brother! I am your AI Accountant and Shop Growth Advisor. I have synchronized with your product registers, client debts, and general ledger. Ask me any question or choose standard audit presets to grow your retail profits today!"
    }[aiLanguage];

    setChatLog([{ role: 'assistant', text: welcome }]);
  }, [aiLanguage]);

  // Quick Questions Presets
  const getPresets = () => {
    switch (aiLanguage) {
      case 'urdu':
        return [
          { label: "دکان کا خلاصہ اور مالیاتی رپورٹ بتائیں", prompt: "Mujhay dukan ki overall financial report and health check bataen urdu me." },
          { label: "کم اسٹاک اور ختم ہونے والی مصنوعات بتائیں", prompt: "Kaun sa maal dukan me khatam horha ha or kisay order karna ha list den." },
          { label: "وہ کسٹمرز بتائیں جن کا ادھار سب سے زیادہ ہے", prompt: "Kaun say khatadar grakak sab se udhar dba kr bthe hain or kis se paise lene hain?" },
          { label: "دکان کے منافع کو دگنا کرنے کا مخلصانہ مشورہ دیں", prompt: "Mera munafa grow krnay or kharchay kam krnay k liye koi ahm mashwara den." }
        ];
      case 'english':
        return [
          { label: "Generate Complete Financial Audit Summary", prompt: "Give me an overview of gross revenue, profits, net margins, and ledger balance." },
          { label: "Identify Critical Stock Shortages", prompt: "What items should i order next from manufacturers to prevent out-of-stock?" },
          { label: "Inspect Client Outstandings", prompt: "Who are my top debtor clients and what is their total outstanding khata balance?" },
          { label: "Action Plan to Maximize Retail Profits", prompt: "Analyze my expense lists and suggest cost cutting actions to double net gain." }
        ];
      default: // roman urdu placeholder
        return [
          { label: "Mera dukan ka audit and profit report den", prompt: "Mujhay dukan ka overall financial audit report and profit margins bataen." },
          { label: "Kaun sa maal khatam horha hai or order krna ha?", prompt: "Kaun sa maal dukan me khatam horha ha or kisay order karna ha list den." },
          { label: "Kaun se grahak sab se zayda udhar dba kr bethe hain?", prompt: "Kaun say khatadar grakak sab se zayda udhar dba kr bthe hain or paise recover krnay hain?" },
          { label: "Dukan ka munafa barhane aur kharche kam krne k mashware", prompt: "Mera munafa barhanay or kharchay kam krnay k tarikey btaen." }
        ];
    }
  };

  const handleQuerySubmit = async (promptText: string) => {
    if (!promptText.trim() || isThinking) return;

    // Append user query to thread
    const updatedThread = [...chatLog, { role: 'user' as const, text: promptText }];
    setChatLog(updatedThread);
    setIsThinking(true);
    setCustomPrompt('');

    try {
      const response = await fetch('/api/ai/advise', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          products,
          clients,
          sales,
          expenses,
          currentLanguage: aiLanguage
        })
      });

      const data = await response.json();
      if (data.advice) {
        setChatLog([...updatedThread, { role: 'assistant', text: data.advice }]);
      } else {
        setChatLog([...updatedThread, { role: 'assistant', text: "Bhai jaan, AI Advisor se koi response nahi mil saka. Ek baar dobara koshish karein." }]);
      }
    } catch (err: any) {
      console.error(err);
      setChatLog([...updatedThread, { role: 'assistant', text: "Maaf kijiyega bhai, API keys check karein ya internet connections. AI systems me thora masla aya hai." }]);
    } finally {
      setIsThinking(false);
    }
  };

  // Helper to format response rendering nicely (handles linebreaks, bold tokens, list highlights)
  const formatTextResponse = (raw: string) => {
    const lines = raw.split('\n');
    return lines.map((line, idx) => {
      // Check if bullet point
      const isBullet = line.trim().startsWith('*') || line.trim().startsWith('-');
      let cleaned = line.replace(/^\s*[\*\-]\s*/, '').trim();

      // Bold highlight converter
      const regex = /\*\*(.*?)\*\*/g;
      const parts = [];
      let lastIndex = 0;
      let match;

      while ((match = regex.exec(cleaned)) !== null) {
        if (match.index > lastIndex) {
          parts.push(cleaned.substring(lastIndex, match.index));
        }
        parts.push(<strong key={match.index} className="text-slate-900 font-extrabold bg-amber-50 px-1 rounded">{match[1]}</strong>);
        lastIndex = regex.lastIndex;
      }
      if (lastIndex < cleaned.length) {
        parts.push(cleaned.substring(lastIndex));
      }

      const finalContent = parts.length > 0 ? parts : cleaned;

      if (isBullet) {
        return (
          <li key={idx} className="ml-4 list-disc pl-1 py-1 text-slate-700 leading-relaxed font-medium">
            {finalContent}
          </li>
        );
      }

      if (line.trim().startsWith('###')) {
        return (
          <h4 key={idx} className="font-extrabold text-[#3b82f6] text-xs uppercase tracking-wider mb-2 mt-4">
            {cleaned.replace(/^###\s*/, '')}
          </h4>
        );
      }

      if (line.trim() === '') {
        return <div key={idx} className="h-2" />;
      }

      return (
        <p key={idx} className="leading-relaxed py-0.5 text-slate-650 font-medium">
          {finalContent}
        </p>
      );
    });
  };

  return (
    <div className="space-y-6" id="ai-advisor-tab">
      
      {/* 1. Header Alert Panel */}
      <div className="bg-gradient-to-r from-blue-600 via-indigo-600 to-violet-700 rounded-3xl p-6 text-white shadow-xl relative overflow-hidden flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_bottom_right,rgba(255,255,255,0.12),transparent_60%)]"></div>
        <div className="flex items-center gap-4 relative z-10">
          <span className="p-3.5 bg-white/10 text-white rounded-2xl backdrop-blur">
            <Bot className="w-8 h-8 animate-bounce" />
          </span>
          <div>
            <h2 className="text-xl font-black flex items-center gap-2">
              <span>Bhai AI Siana Munim</span>
              <Sparkles className="w-4 h-4 text-amber-300 animate-spin" />
            </h2>
            <p className="text-xs text-blue-100 mt-1 max-w-md">Urdu/Roman Urdu Shop Accounts Advisor analyzing products margins and khatadar deficit reports instantly.</p>
          </div>
        </div>

        {/* Advisor Language Switcher */}
        <div className="flex items-center gap-2 relative z-10 bg-white/15 p-1 rounded-xl self-end md:self-auto border border-white/10 text-xs">
          <button 
            onClick={() => setAiLanguage('roman_urdu')} 
            className={`px-3 py-1.5 rounded-lg font-bold transition flex items-center gap-1 ${
              aiLanguage === 'roman_urdu' ? 'bg-white text-blue-900 shadow-sm' : 'hover:bg-white/10 text-white'
            }`}
          >
            <Globe className="w-3.5 h-3.5" /> Roman Urdu
          </button>
          <button 
            onClick={() => setAiLanguage('urdu')} 
            className={`px-3 py-1.5 rounded-lg font-bold transition flex items-center gap-1 ${
              aiLanguage === 'urdu' ? 'bg-white text-blue-900 shadow-sm' : 'hover:bg-white/10 text-white'
            }`}
          >
            <Globe className="w-3.5 h-3.5" /> Urdu Script
          </button>
          <button 
            onClick={() => setAiLanguage('english')} 
            className={`px-3 py-1.5 rounded-lg font-bold transition flex items-center gap-1 ${
              aiLanguage === 'english' ? 'bg-white text-blue-900 shadow-sm' : 'hover:bg-white/10 text-white'
            }`}
          >
            <Globe className="w-3.5 h-3.5" /> English
          </button>
        </div>
      </div>

      {/* 2. Main Chat log Canvas with presets */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">

        {/* Conversations Area (2/3 width) */}
        <div className="lg:col-span-2 bg-white rounded-2xl border border-slate-100 shadow-sm flex flex-col h-[520px] justify-between overflow-hidden">
          
          {/* Header indicator */}
          <div className="bg-slate-50 border-b border-slate-100 px-5 py-3.5 flex justify-between items-center text-xs text-slate-500 font-bold">
            <span className="flex items-center gap-1.5"><MessageSquare className="w-4 h-4 text-blue-600" /> Conversational Thread</span>
            <span className="flex items-center gap-1 text-[10px] text-emerald-600 bg-emerald-50 border border-emerald-100 px-2 py-0.5 rounded-full uppercase">
              <ShieldCheck className="w-3 h-3" /> Secure AI Proxy Active
            </span>
          </div>

          {/* Chat scrolling block */}
          <div className="flex-1 p-5 overflow-y-auto space-y-4">
            {chatLog.map((chat, idx) => {
              const isAssistant = chat.role === 'assistant';
              return (
                <div key={idx} className={`flex gap-3 items-start ${isAssistant ? '' : 'justify-end'}`}>
                  
                  {isAssistant && (
                    <span className="p-2 bg-blue-50 text-blue-600 rounded-xl flex-shrink-0 border border-blue-100 mt-1">
                      <Bot className="w-4.5 h-4.5" />
                    </span>
                  )}

                  <div className={`p-4 rounded-2xl text-xs max-w-[85%] border shadow-sm ${
                    isAssistant 
                      ? 'bg-slate-50/50 border-slate-100 text-slate-700' 
                      : 'bg-blue-600 border-blue-500 text-white font-semibold'
                  }`}>
                    {isAssistant ? (
                      <div className="space-y-1.5">
                        {formatTextResponse(chat.text)}
                      </div>
                    ) : (
                      <p className="leading-relaxed">{chat.text}</p>
                    )}
                  </div>

                </div>
              );
            })}

            {/* Thinking status */}
            {isThinking && (
              <div className="flex gap-3 items-start">
                <span className="p-2 bg-indigo-50 text-indigo-600 rounded-xl flex-shrink-0 animate-spin">
                  <RefreshCw className="w-4.5 h-4.5" />
                </span>
                <div className="p-4 rounded-2xl bg-slate-50 border border-slate-150 inline-flex items-center gap-2 text-xs font-semibold text-slate-500">
                  <Loader2 className="w-4 h-4 animate-spin text-blue-600" />
                  <span>AI Siana Munim dukan ka khata check kar raha hai. Thora sabar karein bhai...</span>
                </div>
              </div>
            )}
          </div>

          {/* Prompt custom input sender */}
          <form 
            onSubmit={(e) => {
              e.preventDefault();
              handleQuerySubmit(customPrompt);
            }}
            className="border-t border-slate-100 p-4 bg-slate-50 flex gap-2 items-center"
          >
            <input 
              type="text" 
              value={customPrompt}
              disabled={isThinking}
              onChange={(e) => setCustomPrompt(e.target.value)}
              placeholder="Siana AI Munim se koi bhi sawal poochein (e.g. 'Mera profit grow krnay ka bataen')..."
              className="flex-1 p-3 bg-white border border-slate-200 outline-none focus:border-blue-500 text-xs font-semibold rounded-xl transition"
            />
            <button 
              type="submit"
              disabled={!customPrompt.trim() || isThinking}
              className="p-3 bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white rounded-xl shadow-md shadow-blue-100 transition active:scale-95 flex-shrink-0"
            >
              <Send className="w-4.5 h-4.5" />
            </button>
          </form>

        </div>

        {/* Quick Audit Actions / Presets Sidebar (1/3 width) */}
        <div id="ai-quick-presets" className="bg-white rounded-2xl p-6 border border-slate-100 shadow-sm space-y-6">
          <div>
            <h3 className="font-semibold text-slate-800 text-base mb-1 inline-flex items-center gap-1">
              <Compass className="w-4.5 h-4.5 text-slate-400" />
              Quick Financial Audit Presets
            </h3>
            <p className="text-xs text-slate-400">Select any pre-configured question checklist to trigger real-time AI ledger checks</p>
          </div>

          <div className="space-y-2.5">
            {getPresets().map((preset, idx) => (
              <button
                key={idx}
                onClick={() => handleQuerySubmit(preset.prompt)}
                disabled={isThinking}
                className="w-full text-left p-3.5 bg-slate-50 hover:bg-slate-100/80 hover:border-slate-300 border border-slate-100/60 rounded-xl transition font-semibold text-xs text-slate-700 flex gap-2.5 items-start active:scale-98 disabled:opacity-50"
              >
                <HelpCircle className="w-4 h-4 text-blue-500 flex-shrink-0 mt-0.5" />
                <span>{preset.label}</span>
              </button>
            ))}
          </div>

          {/* Visual card guide of AI analytical coverage */}
          <div className="border border-slate-100 rounded-xl p-4 bg-indigo-50/20 space-y-3">
            <h4 className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">AI Audit Coverage Scope</h4>
            
            <div className="space-y-1.5 text-[11px] text-slate-650 font-semibold">
              <div className="flex items-center gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-blue-500"></span>
                <span>Active Gross Profit Ratios & Net Valuation</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-rose-500"></span>
                <span>Low stock alerts list automatically queried</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-amber-500"></span>
                <span>Receivables outstanding debtor collection plans</span>
              </div>
            </div>
          </div>
        </div>

      </div>

    </div>
  );
}
