/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  Truck, 
  Users, 
  DollarSign, 
  Plus, 
  Search, 
  ArrowUpRight, 
  ArrowDownLeft, 
  FileText, 
  UserPlus, 
  Calendar, 
  CheckCircle, 
  XCircle,
  Clock,
  Briefcase,
  Smartphone,
  MapPin,
  Clipboard,
  ShieldCheck,
  PackagePlus,
  ArrowRight
} from 'lucide-react';
import { Supplier, Product, Staff, SupplierBill } from '../types';

interface SuppliersProps {
  suppliers: Supplier[];
  supplierBills: SupplierBill[];
  staff: Staff[];
  products: Product[];
  onAddSupplier: (supplier: Supplier) => void;
  onUpdateSupplier: (supplier: Supplier) => void;
  onDeleteSupplier: (id: string) => void;
  onRecordSupplierPayment: (supplierId: string, amount: number) => void;
  onRecordStockPurchase: (bill: SupplierBill) => void;
  onAddStaff: (staff: Staff) => void;
  onUpdateStaff: (staff: Staff) => void;
  onDeleteStaff: (id: string) => void;
  onRecordStaffSalaryOrLoan: (staffId: string, type: 'salary' | 'advance', amount: number) => void;
  onUpdateStaffAttendance: (staffId: string, status: 'Present' | 'Absent' | 'Half-day' | 'Leave') => void;
  language: 'roman_urdu' | 'urdu' | 'english';
}

export default function Suppliers({ 
  suppliers, 
  supplierBills, 
  staff, 
  products,
  onAddSupplier,
  onUpdateSupplier,
  onRecordSupplierPayment,
  onRecordStockPurchase,
  onAddStaff,
  onUpdateStaff,
  onDeleteStaff,
  onRecordStaffSalaryOrLoan,
  onUpdateStaffAttendance,
  language 
}: SuppliersProps) {
  
  // Outer tabs: 'suppliers' | 'staff'
  const [activeTab, setActiveTab] = useState<'suppliers' | 'staff'>('suppliers');
  
  // Search state
  const [searchQuery, setSearchQuery] = useState('');

  // Modals / forms state
  const [isSupplierModalOpen, setIsSupplierModalOpen] = useState(false);
  const [isPurchaseModalOpen, setIsPurchaseModalOpen] = useState(false);
  const [isPaymentModalOpen, setIsPaymentModalOpen] = useState(false);
  const [isStaffModalOpen, setIsStaffModalOpen] = useState(false);
  const [isSalaryModalOpen, setIsSalaryModalOpen] = useState(false);

  // Supplier Form State
  const [supName, setSupName] = useState('');
  const [supPhone, setSupPhone] = useState('');
  const [supCompany, setSupCompany] = useState('');
  const [supAddress, setSupAddress] = useState('');
  const [supBalance, setSupBalance] = useState(0);

  // Purchase Form State
  const [purSupplierId, setPurSupplierId] = useState('');
  const [purProductId, setPurProductId] = useState('');
  const [purQty, setPurQty] = useState(1);
  const [purCostPrice, setPurCostPrice] = useState(0);
  const [purAmountPaid, setPurAmountPaid] = useState(0);

  // Payment Form State
  const [paySupplierId, setPaySupplierId] = useState('');
  const [payAmount, setPayAmount] = useState(0);

  // Staff Form State
  const [stfName, setStfName] = useState('');
  const [stfRole, setStfRole] = useState('');
  const [stfPhone, setStfPhone] = useState('');
  const [stfSalary, setStfSalary] = useState(20000);

  // Salary/Advance Form State
  const [salStaffId, setSalStaffId] = useState('');
  const [salType, setSalType] = useState<'salary' | 'advance'>('salary');
  const [salAmount, setSalAmount] = useState(0);

  const t = {
    roman_urdu: {
      suppliersTitle: "Dealers Ledger (Wholesale Suppliers)",
      suppliersSub: "Wholesalers ka maal purchase, ledger credits aur payments control book",
      staffTitle: "Mulazim Register (Staff attendance & Advance wages)",
      staffSub: "Dukan k dosto aur workers ka daily haazri card aur peshgi book",
      tabSuppliers: "Dealer Book (Suppliers)",
      tabStaff: "Mulazim Register (Staff)",
      btnNewSupplier: "Naya Dealer Add Karen 🚚",
      btnNewPurchase: "Naya Maal Purchase Karen 📦",
      btnPaySupplier: "Dealer ko Payment Ada Karen 💰",
      btnNewStaff: "Naya Mulazim Add Karen 👤",
      btnPayStaff: "Salary / Advance Ada Karen 💵",
      lblSearch: "Dukan data search karen...",
      lblTotalWeOwe: "Humein Ada Karna Hai (We Owe Debt)",
      lblTotalEmployees: "Kul Mulazimeen (Staff Employees)",
      colName: "Dealers Details",
      colCompany: "Company / Thook Markaz",
      colPhone: "Contact Number",
      colBalanceOwed: "Outstanding Liability Balance",
      colAction: "Kharwai (Actions)",
      noSuppliers: "Bhai, abhi tak koi suppliers add nahi kiye gaye.",
      noStaff: "Abhi koi staff employee dukan register me nahi ha.",
      modalAddSupplier: "Naya Supplier Dealer Register Karen",
      modalRecordPurchase: "Wholesale Maal Stock Inward (Nayi Purchase Bill)",
      modalRecordPayment: "Supplier Dealer ko Outstanding Cash Transfer Ledger",
      modalAddStaff: "Naya Mulazim Add Karen (Staff Register)",
      modalRecordSalary: "Wages & Advance Peshgi Form",
      lblSupplierName: "Dealer Name (Incharge / Malik)",
      lblCompanyName: "Wholesale Company Name",
      lblPhoneNum: "Mobile/WhatsApp Num",
      lblAddress: "Market Address / Shop location",
      lblStartingBalance: "Purana Balance Jo Hume Ada Karna Hai (Rs.)",
      lblSelectSupplier: "Supplier Select Karen",
      lblSelectProduct: "Dukan ka Maal (Select Product to Stock up)",
      lblQtyToPurchase: "Total Quantity (Daba / Maal unit count)",
      lblCostPriceUnit: "Single Cost Price Unit (Rs.)",
      lblTotalBillAmount: "Sub-total Net Purchase Bill Amount",
      lblPaidAmount: "Paid Amount Right Now (Rs.)",
      lblUnpaidRemaining: "Baqi Dealer Balance (Owed liability to Supplier)",
      lblStaffName: "Mulazim Name",
      lblStaffRole: "Work Role (Helper, Guard, Rider)",
      lblStaffMonthly: "Basic Salary Per Month (Rs.)",
      placeholderSearch: "Dealers ya staff search karain...",
      addSuccess: "Mubarak! Data updated securely.",
      saveBtn: "Mahfooz Karein (Save)",
      colRole: "Karobar Role",
      colSalary: "Month's Salary",
      colAdvance: "Total Advance / Peshgi",
      colAttendance: "Daily Haazri (Attendance Today)",
      lblAttendanceBadge: "Haazri",
      attendanceP: "P - Hazir",
      attendanceA: "A - Ghair Hazir",
      attendanceH: "H - Half-day",
      attendanceL: "L - Chutti",
      auditTrailTitle: "Haaliya Procurement Inventory Purchase Bills",
      colInvoiceNum: "Bill Num",
      colDate: "Tareekh",
      colProduct: "Mal-e-Ghanimat",
      colQty: "Tadad",
      colPaid: "Paid"
    },
    urdu: {
      suppliersTitle: "تھوک ڈیلرز بائینگ بک",
      suppliersSub: "ڈیلرز سے مال کی خریداری، ادھار لیجر اور نقد ادائیگی کا نظام",
      staffTitle: "ملازمین کا حاضری اور ایڈوانس رجسٹر",
      staffSub: "دکان کے کاریگروں کی روزانہ حاضری اور معاوضہ بک",
      tabSuppliers: "ڈیلر اکاؤنٹ (سپلیئرز)",
      tabStaff: "ملازم شیٹ (اسٹاف)",
      btnNewSupplier: "نیا ڈیلر شامل کریں 🚚",
      btnNewPurchase: "نیا اسٹاک خریدیں 📦",
      btnPaySupplier: "ڈیلر کو ادائیگی کریں 💰",
      btnNewStaff: "نیا ملازم درج کریں 👤",
      btnPayStaff: "تنخواہ یا ایڈوانس معاوضہ 💵",
      lblSearch: "تلاش کریں...",
      lblTotalWeOwe: "کل واجب الادا رقم (ڈیلر قرضہ)",
      lblTotalEmployees: "کل ملازمین",
      colName: "ڈیلر کی تفصیلات",
      colCompany: "کمپنی / ہول سیلر",
      colPhone: "فون نمبر",
      colBalanceOwed: "واجب الادا بقایا رقم",
      colAction: "ایکشن",
      noSuppliers: "کوئی معلومات درج نہیں ہیں۔",
      noStaff: "ابھی تک کوئی ملازم رجسٹرڈ نہیں ہے۔",
      modalAddSupplier: "نیا ہول سیل سپلائر رجسٹر کریں",
      modalRecordPurchase: "ہول سیل خرید انوائس (نئی پروکیورمنٹ)",
      modalRecordPayment: "سپلائر ڈیلر کو نقد ادائیگی رجسٹر کریں",
      modalAddStaff: "نیا کاریگر / ملازم شامل کریں",
      modalRecordSalary: "تنخواہ اور پیشگی ریکارڈ",
      lblSupplierName: "ڈیلر کا نام",
      lblCompanyName: "مارکیٹ کمپنی کا نام",
      lblPhoneNum: "واٹس ایپ یا فون موبائل نمبر",
      lblAddress: "مارکیٹ دکان کا پتہ",
      lblStartingBalance: "سابقہ رقم جو دکان نے ادا کرنی ہے (روپے)",
      lblSelectSupplier: "سپلائر کا انتخاب کریں",
      lblSelectProduct: "پروڈکٹ کا انتخاب کریں",
      lblQtyToPurchase: "کل تعداد",
      lblCostPriceUnit: "فی یونٹ خرید قیمت خرید (روپے)",
      lblTotalBillAmount: "کل بل کی رقم",
      lblPaidAmount: "ادا کردہ جزوی رقم",
      lblUnpaidRemaining: "باقی واجب الادا قرضہ",
      lblStaffName: "ملازم کا نام",
      lblStaffRole: "کام کی ذمہ داری (کاریگر، ہیلپر)",
      lblStaffMonthly: "ماہانہ تنخواہ (روپے)",
      placeholderSearch: "ڈیلر یا کاریگر تلاش کریں...",
      addSuccess: "معلومات محفوظ کر لی گئی ہیں۔",
      saveBtn: "محفوظ کریں",
      colRole: "دکان کا رول",
      colSalary: "ماہانہ تنخواہ",
      colAdvance: "مجموعی پیشگی قرض",
      colAttendance: "روزانہ حاضری شیٹ",
      lblAttendanceBadge: "حاضری",
      attendanceP: "حاضر",
      attendanceA: "غیر حاضر",
      attendanceH: "ہاف ڈے",
      attendanceL: "رخصت",
      auditTrailTitle: "حالیہ ہول سیل خریداری بل انوائسز",
      colInvoiceNum: "بل نمبر",
      colDate: "تاریخ",
      colProduct: "پروڈکٹ",
      colQty: "تعداد",
      colPaid: "ادا شدہ رقم"
    },
    english: {
      suppliersTitle: "Dealer Khata Book & Purchase Ledger",
      suppliersSub: "Manage wholesale distributors, procurement bills, track cash liabilities & payables",
      staffTitle: "Staff Employee Register & Wage Registry",
      staffSub: "Track employees, record daily attendance cards, advance payments & salary payouts",
      tabSuppliers: "Wholesale Suppliers",
      tabStaff: "Staff Employee Ledger",
      btnNewSupplier: "Add Supplier 🚚",
      btnNewPurchase: "Record Stock Inward 📦",
      btnPaySupplier: "Record Supplier Payment 💰",
      btnNewStaff: "Register Employee 👤",
      btnPayStaff: "Disburse Wage / Advance 💵",
      lblSearch: "Search database...",
      lblTotalWeOwe: "Total Account Payable (We Owe)",
      lblTotalEmployees: "Total Hired Staff",
      colName: "Supplier Ledger",
      colCompany: "Trading Firm / Company",
      colPhone: "Phone Details",
      colBalanceOwed: "Outstanding Payable Balance",
      colAction: "Manage Action",
      noSuppliers: "No registered suppliers found in your storage ledger.",
      noStaff: "No staff employees listed under your payroll registry.",
      modalAddSupplier: "Register New Wholesale Supplier Dealer",
      modalRecordPurchase: "Record Supplier Stock Purchase Bill (Stock Inward)",
      modalRecordPayment: "Settle Supplier Invoice Payment (Cash Outward)",
      modalAddStaff: "Register New Staff Member",
      modalRecordSalary: "Pay Employee Wages or Advance Peshgi",
      lblSupplierName: "Supplier Contact Name",
      lblCompanyName: "Wholesale Company / Mill Name",
      lblPhoneNum: "Mobile / WhatsApp Number",
      lblAddress: "Warehouse / Market Physical Address",
      lblStartingBalance: "Outstanding Balance Owed by Shop (Rs.)",
      lblSelectSupplier: "Select Wholesale Supplier",
      lblSelectProduct: "Select Warehouse Item to Replenish",
      lblQtyToPurchase: "Buying Quantity (Units)",
      lblCostPriceUnit: "Wholesale Buying Unit Cost (Rs.)",
      lblTotalBillAmount: "Total Wholesale Purchase Invoice",
      lblPaidAmount: "Immediate Cash Paid Amount (Rs.)",
      lblUnpaidRemaining: "Remining Balance Owed to Supplier Liability",
      lblStaffName: "Employee Legal Name",
      lblStaffRole: "Role Description (Helper, Guard, Dispatcher)",
      lblStaffMonthly: "Fixed Base Monthly Salary (Rs.)",
      placeholderSearch: "Query supplier, roles or names...",
      addSuccess: "Master ERP entry saved successfully.",
      saveBtn: "Save Profile Ledger",
      colRole: "Work Domain Role",
      colSalary: "Monthly Salary Scale",
      colAdvance: "Total Advances Paid",
      colAttendance: "Daily Digital Attendance Stamp",
      lblAttendanceBadge: "Attendance Status",
      attendanceP: "P - Present",
      attendanceA: "A - Absent",
      attendanceH: "H - Half-day",
      attendanceL: "L - Leave Approved",
      auditTrailTitle: "Recent Inward Inventory Purchase Log",
      colInvoiceNum: "Inv No.",
      colDate: "Purchase Date",
      colProduct: "Acquired Items",
      colQty: "Count",
      colPaid: "Paid Paid Amount"
    }
  }[language];

  // Calculations
  const totalOwedAmount = suppliers.reduce((sum, s) => sum + s.balance, 0);
  const totalEmployeesCount = staff.length;

  // Filter lists
  const filteredSuppliers = suppliers.filter(s => 
    s.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    s.companyName.toLowerCase().includes(searchQuery.toLowerCase()) ||
    s.phone.includes(searchQuery)
  );

  const filteredStaff = staff.filter(st => 
    st.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    st.role.toLowerCase().includes(searchQuery.toLowerCase()) ||
    st.phone.includes(searchQuery)
  );

  // Set unit price helper when changing product in purchase dropdown
  const handleProductChangeForPurchase = (prodId: string) => {
    setPurProductId(prodId);
    const selectedProd = products.find(p => p.id === prodId);
    if (selectedProd) {
      setPurCostPrice(selectedProd.costPrice);
    }
  };

  const handleCreateSupplierSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!supName || !supCompany) return;

    const newSup: Supplier = {
      id: 'SUP-' + Math.floor(1000 + Math.random() * 9000).toString(),
      name: supName,
      phone: supPhone || 'N/A',
      companyName: supCompany,
      address: supAddress || 'General Market',
      balance: Number(supBalance) || 0
    };

    onAddSupplier(newSup);
    setIsSupplierModalOpen(false);
    setSupName('');
    setSupPhone('');
    setSupCompany('');
    setSupAddress('');
    setSupBalance(0);
  };

  const handlePurchaseSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!purSupplierId || !purProductId || purQty <= 0) return;

    const selectedSup = suppliers.find(s => s.id === purSupplierId);
    const selectedProd = products.find(p => p.id === purProductId);
    if (!selectedSup || !selectedProd) return;

    const netCost = purQty * purCostPrice;
    
    const bill: SupplierBill = {
      id: 'BILL-' + Math.floor(10000 + Math.random() * 90000).toString(),
      billNumber: 'PO-' + Math.floor(1000 + Math.random() * 9000).toString(),
      date: new Date().toISOString().split('T')[0],
      supplierId: purSupplierId,
      supplierName: selectedSup.name,
      productId: purProductId,
      productName: selectedProd.name,
      qty: Number(purQty),
      costPrice: Number(purCostPrice),
      totalAmount: netCost,
      paidAmount: Number(purAmountPaid)
    };

    onRecordStockPurchase(bill);
    setIsPurchaseModalOpen(false);
    setPurSupplierId('');
    setPurProductId('');
    setPurQty(1);
    setPurCostPrice(0);
    setPurAmountPaid(0);
  };

  const handleSupplierPaymentSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!paySupplierId || payAmount <= 0) return;

    onRecordSupplierPayment(paySupplierId, Number(payAmount));
    setIsPaymentModalOpen(false);
    setPaySupplierId('');
    setPayAmount(0);
  };

  const handleCreateStaffSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!stfName || !stfRole) return;

    const newStf: Staff = {
      id: 'STF-' + Math.floor(100 + Math.random() * 900).toString(),
      name: stfName,
      role: stfRole,
      phone: stfPhone || 'N/A',
      monthlySalary: Number(stfSalary) || 15000,
      advanceTaken: 0,
      attendanceToday: 'Present'
    };

    onAddStaff(newStf);
    setIsStaffModalOpen(false);
    setStfName('');
    setStfRole('');
    setStfPhone('');
    setStfSalary(20000);
  };

  const handleStaffWageSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!salStaffId || salAmount <= 0) return;

    onRecordStaffSalaryOrLoan(salStaffId, salType, Number(salAmount));
    setIsSalaryModalOpen(false);
    setSalStaffId('');
    setSalAmount(0);
  };

  return (
    <div className="space-y-6" id="dealers-and-staff-hub">
      
      {/* 1. TOP HEADER BRANDED RAIL SUMMARY */}
      <div className="bg-white rounded-3xl p-6 border border-slate-100 shadow-sm flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div className="flex items-center gap-3">
          <span className="p-3 bg-gradient-to-br from-indigo-500 to-purple-600 text-white rounded-2xl shadow-lg">
            <Truck className="w-6 h-6 animate-pulse" />
          </span>
          <div>
            <h2 className="text-base font-extrabold text-slate-900">
              {activeTab === 'suppliers' ? t.suppliersTitle : t.staffTitle}
            </h2>
            <p className="text-xs text-slate-400 mt-1">
              {activeTab === 'suppliers' ? t.suppliersSub : t.staffSub}
            </p>
          </div>
        </div>

        {/* Dynamic Nav Switches */}
        <div className="flex bg-slate-100 p-1 rounded-xl text-xs font-bold shrink-0">
          <button 
            type="button"
            onClick={() => { setActiveTab('suppliers'); setSearchQuery(''); }}
            className={`px-4 py-2 rounded-lg transition-all duration-200 flex items-center gap-1.5 ${activeTab === 'suppliers' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-500 hover:text-slate-900'}`}
          >
            <Truck className="w-3.5 h-3.5" />
            <span>{t.tabSuppliers}</span>
          </button>
          <button 
            type="button"
            onClick={() => { setActiveTab('staff'); setSearchQuery(''); }}
            className={`px-4 py-2 rounded-lg transition-all duration-200 flex items-center gap-1.5 ${activeTab === 'staff' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-500 hover:text-slate-900'}`}
          >
            <Users className="w-3.5 h-3.5" />
            <span>{t.tabStaff}</span>
          </button>
        </div>
      </div>

      {/* 2. SUMMARY METRIC CARDS */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        
        {/* Metric Card 1 */}
        <div className="bg-gradient-to-br from-rose-50 to-pink-50 rounded-2xl p-5 border border-rose-100 flex items-center justify-between">
          <div>
            <span className="text-[10px] font-bold text-rose-500 uppercase tracking-widest">{t.lblTotalWeOwe}</span>
            <h3 className="text-xl font-extrabold text-slate-900 mt-1">Rs. {totalOwedAmount.toLocaleString()}/-</h3>
            <p className="text-[9px] text-slate-400 mt-1">All wholesale account payables</p>
          </div>
          <span className="p-3 bg-white text-rose-500 rounded-xl shadow-sm border border-rose-100">
            <ArrowUpRight className="w-5 h-5 font-bold" />
          </span>
        </div>

        {/* Metric Card 2 */}
        <div className="bg-gradient-to-br from-blue-50 to-indigo-50 rounded-2xl p-5 border border-blue-100 flex items-center justify-between">
          <div>
            <span className="text-[10px] font-bold text-blue-500 uppercase tracking-widest">{t.lblTotalEmployees}</span>
            <h3 className="text-xl font-extrabold text-slate-900 mt-1">{totalEmployeesCount} Workers</h3>
            <p className="text-[9px] text-slate-400 mt-1">Hired personnel working at shop</p>
          </div>
          <span className="p-3 bg-white text-blue-500 rounded-xl shadow-sm border border-blue-100">
            <Users className="w-5 h-5" />
          </span>
        </div>

        {/* Action Button Rails based on Active Tab */}
        <div className="bg-white rounded-2xl p-4 border border-slate-100 flex flex-col justify-center gap-2">
          {activeTab === 'suppliers' ? (
            <>
              <div className="grid grid-cols-2 gap-2">
                <button
                  onClick={() => setIsSupplierModalOpen(true)}
                  className="w-full bg-blue-600 hover:bg-blue-700 text-white font-heavy text-[11px] font-bold py-2 rounded-xl transition flex items-center justify-center gap-1 shadow-sm active:scale-95 cursor-pointer"
                >
                  <UserPlus className="w-3.5 h-3.5" />
                  <span>Dealer Profile</span>
                </button>
                <button
                  onClick={() => setIsPurchaseModalOpen(true)}
                  className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-heavy text-[11px] font-bold py-2 rounded-xl transition flex items-center justify-center gap-1 shadow-sm active:scale-95 cursor-pointer"
                >
                  <PackagePlus className="w-3.5 h-3.5" />
                  <span>Maal Purchase</span>
                </button>
              </div>
              <button
                onClick={() => setIsPaymentModalOpen(true)}
                className="w-full bg-slate-800 hover:bg-slate-900 text-white font-heavy text-[11px] font-bold py-2 rounded-xl transition flex items-center justify-center gap-1 border shadow-sm active:scale-95 cursor-pointer"
              >
                <DollarSign className="w-3.5 h-3.5" />
                <span>{t.btnPaySupplier}</span>
              </button>
            </>
          ) : (
            <>
              <button
                onClick={() => setIsStaffModalOpen(true)}
                className="w-full bg-blue-600 hover:bg-blue-700 text-white font-heavy text-[11px] font-bold py-2.5 rounded-xl transition flex items-center justify-center gap-1 shadow-sm active:scale-95 cursor-pointer"
              >
                <UserPlus className="w-3.5 h-3.5" />
                <span>{t.btnNewStaff}</span>
              </button>
              <button
                onClick={() => setIsSalaryModalOpen(true)}
                className="w-full bg-indigo-650 hover:bg-indigo-700 text-white font-heavy text-[11px] font-bold py-2.5 rounded-xl transition flex items-center justify-center gap-1 shadow-sm active:scale-95 cursor-pointer"
              >
                <DollarSign className="w-3.5 h-3.5" />
                <span>{t.btnPayStaff}</span>
              </button>
            </>
          )}
        </div>

      </div>

      {/* 3. INPUT FILTER & QUICK SEARCH BAR */}
      <div className="bg-white rounded-2xl p-4 border border-slate-100 flex items-center gap-3 shadow-xs">
        <Search className="w-4 h-4 text-slate-400 ml-1.5 shrink-0" />
        <input 
          type="text"
          placeholder={t.placeholderSearch}
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="bg-transparent border-none outline-none font-bold text-xs text-slate-700 w-full placeholder-slate-400"
        />
      </div>

      {/* 4. CONTENT GRID DISPLAY / RENDER */}
      {activeTab === 'suppliers' ? (
        <div className="space-y-6">
          
          {/* Suppliers Table Panel Card */}
          <div className="bg-white rounded-3xl border border-slate-100 shadow-xs overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="bg-slate-50 border-b border-slate-100 text-[10px] font-black uppercase text-slate-405 tracking-wider font-semibold">
                    <th className="py-4 px-6">{t.colName}</th>
                    <th className="py-4 px-6">{t.colCompany}</th>
                    <th className="py-4 px-6">{t.colPhone}</th>
                    <th className="py-4 px-6 text-right">{t.colBalanceOwed}</th>
                    <th className="py-4 px-6 text-center">{t.colAction}</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-50 font-medium">
                  {filteredSuppliers.length === 0 ? (
                    <tr>
                      <td colSpan={5} className="py-12 text-center text-slate-400 font-bold bg-slate-50/50">
                        {t.noSuppliers}
                      </td>
                    </tr>
                  ) : (
                    filteredSuppliers.map((sup) => (
                      <tr key={sup.id} className="hover:bg-slate-50/70 transition">
                        <td className="py-4.5 px-6">
                          <span className="font-extrabold text-slate-900 block leading-tight">{sup.name}</span>
                          <span className="text-[10px] text-slate-400 font-mono mt-0.5 block">{sup.id} | {sup.address}</span>
                        </td>
                        <td className="py-4.5 px-6 font-bold text-slate-700">
                          {sup.companyName}
                        </td>
                        <td className="py-4.5 px-6 font-mono font-bold text-slate-600">
                          {sup.phone}
                        </td>
                        <td className="py-4.5 px-6 text-right">
                          <span className={`font-mono text-xs font-black ${sup.balance > 0 ? 'text-rose-600 bg-rose-50 px-2 py-1 rounded-lg' : 'text-slate-400'}`}>
                            Rs. {sup.balance.toLocaleString()}/-
                          </span>
                        </td>
                        <td className="py-4.5 px-6 text-center">
                          <div className="flex justify-center gap-1.5">
                            <button
                              type="button"
                              onClick={() => {
                                setPaySupplierId(sup.id);
                                setIsPaymentModalOpen(true);
                              }}
                              className="px-2 py-1 text-[10px] uppercase font-black bg-blue-50 text-blue-700 hover:bg-blue-100 font-bold border rounded-lg transition"
                            >
                              Pay Debt
                            </button>
                            <button
                              type="button"
                              onClick={() => {
                                setPurSupplierId(sup.id);
                                setIsPurchaseModalOpen(true);
                              }}
                              className="px-2 py-1 text-[10px] uppercase font-black bg-emerald-50 text-emerald-700 hover:bg-emerald-100 font-bold border rounded-lg transition"
                            >
                              Buy Stock
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>

          {/* Audit Trail Inward Stock Purchase Ledger */}
          <div className="bg-white rounded-3xl border border-slate-100 shadow-sm p-6 space-y-4">
            <h3 className="text-xs font-black uppercase text-slate-400 tracking-wider flex items-center gap-2 border-none">
              <FileText className="w-4 h-4 text-emerald-500" />
              {t.auditTrailTitle}
            </h3>

            <div className="overflow-x-auto rounded-2xl border border-slate-100">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="bg-slate-50 border-b border-slate-100 text-[10px] font-black uppercase text-slate-400">
                    <th className="py-3 px-4">{t.colInvoiceNum}</th>
                    <th className="py-3 px-4">{t.colDate}</th>
                    <th className="py-3 px-4">Dealer Name</th>
                    <th className="py-3 px-4">{t.colProduct}</th>
                    <th className="py-3 px-4 text-center">{t.colQty}</th>
                    <th className="py-3 px-4 text-right">Total Net Cost</th>
                    <th className="py-3 px-4 text-right">{t.colPaid}</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-50 font-mono text-[11px] font-semibold text-slate-705">
                  {supplierBills.length === 0 ? (
                    <tr>
                      <td colSpan={7} className="py-8 text-center text-slate-400 font-bold">
                        Dukan par abhi koi wholesale purchase logs maujood nahi hain.
                      </td>
                    </tr>
                  ) : (
                    supplierBills.map((bill) => (
                      <tr key={bill.id} className="hover:bg-slate-50/50 transition">
                        <td className="py-3 px-4 font-bold text-slate-900">{bill.billNumber}</td>
                        <td className="py-3 px-4 text-slate-400">{bill.date}</td>
                        <td className="py-3 px-4 font-medium text-slate-750 font-sans">{bill.supplierName}</td>
                        <td className="py-3 px-4 font-medium text-slate-800 font-sans">{bill.productName}</td>
                        <td className="py-3 px-4 text-center text-slate-900 font-bold">{bill.qty} units</td>
                        <td className="py-3 px-4 text-right font-heavy text-slate-800">Rs. {bill.totalAmount.toLocaleString()}</td>
                        <td className="py-3 px-4 text-right">
                          <span className={`px-1.5 py-0.5 rounded font-heavy ${bill.paidAmount >= bill.totalAmount ? 'text-emerald-600 bg-emerald-50' : 'text-amber-600 bg-amber-50'}`}>
                            Rs. {bill.paidAmount.toLocaleString()}
                          </span>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>

        </div>
      ) : (
        /* Render Staff Employees Registry */
        <div className="bg-white rounded-3xl border border-slate-100 shadow-xs overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-100 text-[10px] font-black uppercase text-slate-400 tracking-wider font-semibold">
                  <th className="py-4 px-6">{t.lblStaffName}</th>
                  <th className="py-4 px-6">{t.colRole}</th>
                  <th className="py-4 px-6">{t.colPhone}</th>
                  <th className="py-4 px-6 text-right">{t.colSalary}</th>
                  <th className="py-4 px-6 text-right">{t.colAdvance}</th>
                  <th className="py-4 px-6 text-center">{t.colAttendance}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-50 font-medium">
                {filteredStaff.length === 0 ? (
                  <tr>
                    <td colSpan={6} className="py-12 text-center text-slate-400 font-bold bg-slate-50/50">
                      {t.noStaff}
                    </td>
                  </tr>
                ) : (
                  filteredStaff.map((emp) => (
                    <tr key={emp.id} className="hover:bg-slate-50/70 transition">
                      <td className="py-4.5 px-6">
                        <span className="font-extrabold text-slate-900 block leading-tight">{emp.name}</span>
                        <span className="text-[10px] text-slate-400 font-mono mt-0.5 block">{emp.id}</span>
                      </td>
                      <td className="py-4.5 px-6 text-slate-700 font-bold flex items-center gap-1.5 mt-2.5">
                        <Briefcase className="w-3.5 h-3.5 text-slate-400" />
                        <span>{emp.role}</span>
                      </td>
                      <td className="py-4.5 px-6 font-mono text-slate-600 font-bold">
                        {emp.phone}
                      </td>
                      <td className="py-4.5 px-6 text-right font-mono font-bold text-slate-800">
                        Rs. {emp.monthlySalary.toLocaleString()}/-
                      </td>
                      <td className="py-4.5 px-6 text-right">
                        <span className={`font-mono font-bold text-xs ${emp.advanceTaken > 0 ? 'text-amber-600 bg-amber-50 px-2 py-0.5 rounded' : 'text-slate-400'}`}>
                          Rs. {emp.advanceTaken.toLocaleString()}/-
                        </span>
                      </td>
                      <td className="py-4.5 px-6 text-center">
                        <div className="flex justify-center gap-1">
                          {(['Present', 'Absent', 'Half-day', 'Leave'] as const).map((status) => {
                            const active = emp.attendanceToday === status;
                            let btnStyle = 'bg-slate-50 text-slate-400 hover:text-slate-700';
                            if (active) {
                              if (status === 'Present') btnStyle = 'bg-emerald-600 text-white shadow-xs';
                              if (status === 'Absent') btnStyle = 'bg-rose-500 text-white shadow-xs';
                              if (status === 'Half-day') btnStyle = 'bg-amber-500 text-white shadow-xs';
                              if (status === 'Leave') btnStyle = 'bg-blue-500 text-white shadow-xs';
                            }
                            
                            return (
                              <button
                                key={status}
                                type="button"
                                onClick={() => onUpdateStaffAttendance(emp.id, status)}
                                className={`text-[10px] font-black px-1.5 py-1 rounded transition ${btnStyle}`}
                                title={status}
                              >
                                {status === 'Present' && 'P'}
                                {status === 'Absent' && 'A'}
                                {status === 'Half-day' && 'H'}
                                {status === 'Leave' && 'L'}
                              </button>
                            );
                          })}
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* 5. MODALS PANELS CONTAINER SECTION */}
      
      {/* MODAL 1: ADD SUPPLIER DEALER */}
      {isSupplierModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-xs">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 space-y-4 shadow-2xl border border-slate-100">
            <div className="flex justify-between items-center border-b pb-3.5">
              <h3 className="font-black text-slate-800 text-sm flex items-center gap-1.5 border-none">
                <Truck className="w-5 h-5 text-blue-600" />
                {t.modalAddSupplier}
              </h3>
              <button 
                onClick={() => setIsSupplierModalOpen(false)}
                className="text-slate-400 hover:text-slate-600 font-bold"
              >
                ×
              </button>
            </div>

            <form onSubmit={handleCreateSupplierSubmit} className="space-y-4 text-xs font-semibold">
              <div>
                <label className="text-[10px] uppercase font-bold text-slate-400 block mb-1">{t.lblSupplierName} *</label>
                <input 
                  type="text"
                  required
                  placeholder="e.g. Mian Jahangir Sahib"
                  value={supName}
                  onChange={(e) => setSupName(e.target.value)}
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 outline-none focus:border-blue-500 focus:bg-white rounded-lg font-bold"
                />
              </div>

              <div>
                <label className="text-[10px] uppercase font-bold text-slate-400 block mb-1">{t.lblCompanyName} *</label>
                <input 
                  type="text"
                  required
                  placeholder="e.g. Bilal & Co Silk Wholesalers"
                  value={supCompany}
                  onChange={(e) => setSupCompany(e.target.value)}
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 outline-none focus:border-blue-500 focus:bg-white rounded-lg font-bold"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-[10px] uppercase font-bold text-slate-400 block mb-1">{t.lblPhoneNum}</label>
                  <input 
                    type="text"
                    placeholder="e.g. 03001234567"
                    value={supPhone}
                    onChange={(e) => setSupPhone(e.target.value)}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 outline-none focus:border-blue-500 focus:bg-white rounded-lg font-mono font-bold"
                  />
                </div>
                <div>
                  <label className="text-[10px] uppercase font-bold text-slate-400 block mb-1">{t.lblStartingBalance}</label>
                  <input 
                    type="number"
                    min="0"
                    placeholder="0"
                    value={supBalance || ''}
                    onChange={(e) => setSupBalance(Number(e.target.value))}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 outline-none focus:border-blue-500 focus:bg-white rounded-lg font-mono font-bold"
                  />
                </div>
              </div>

              <div>
                <label className="text-[10px] uppercase font-bold text-slate-400 block mb-1">{t.lblAddress}</label>
                <input 
                  type="text"
                  placeholder="e.g. Azam Cloth Market Shop A/4, Lahore"
                  value={supAddress}
                  onChange={(e) => setSupAddress(e.target.value)}
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 outline-none focus:border-blue-500 focus:bg-white rounded-lg font-semibold"
                />
              </div>

              <div className="flex gap-2 pt-2 border-t text-xs">
                <button
                  type="button"
                  onClick={() => setIsSupplierModalOpen(false)}
                  className="w-full py-2.5 bg-slate-100 hover:bg-slate-200 rounded-lg text-slate-600 font-bold transition"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="w-full py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-black transition shadow-md"
                >
                  {t.saveBtn}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL 2: PURCHASE BILL STOCK INWARD FORM */}
      {isPurchaseModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-xs">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 space-y-4 shadow-2xl border border-slate-100">
            <div className="flex justify-between items-center border-b pb-3.5">
              <h3 className="font-black text-slate-800 text-sm flex items-center gap-1.5 border-none">
                <PackagePlus className="w-5 h-5 text-emerald-600" />
                {t.modalRecordPurchase}
              </h3>
              <button 
                onClick={() => setIsPurchaseModalOpen(false)}
                className="text-slate-400 hover:text-slate-600 font-bold"
              >
                ×
              </button>
            </div>

            <form onSubmit={handlePurchaseSubmit} className="space-y-4 text-xs font-semibold">
              
              {/* Select Supplier Dealer */}
              <div>
                <label className="text-[10px] uppercase font-bold text-slate-400 block mb-1">{t.lblSelectSupplier} *</label>
                <select
                  required
                  value={purSupplierId}
                  onChange={(e) => setPurSupplierId(e.target.value)}
                  className="w-full p-2.5 bg-slate-50 hover:bg-slate-100 border border-slate-200 outline-none focus:border-blue-500 rounded-lg font-bold"
                >
                  <option value="">-- Wholesaler Dealer Chunein --</option>
                  {suppliers.map(sup => (
                    <option key={sup.id} value={sup.id}>
                      {sup.companyName} ({sup.name})
                    </option>
                  ))}
                </select>
              </div>

              {/* Select Target Product stock item */}
              <div>
                <label className="text-[10px] uppercase font-bold text-slate-400 block mb-1">{t.lblSelectProduct} *</label>
                <select
                  required
                  value={purProductId}
                  onChange={(e) => handleProductChangeForPurchase(e.target.value)}
                  className="w-full p-2.5 bg-slate-50 hover:bg-slate-100 border border-slate-200 outline-none focus:border-blue-500 rounded-lg font-bold"
                >
                  <option value="">-- Replenish Dukan Stock Item --</option>
                  {products.map(prod => (
                    <option key={prod.id} value={prod.id}>
                      {prod.name} (Current Stock: {prod.stock} units)
                    </option>
                  ))}
                </select>
              </div>

              {/* Counts & Single cost pricing config */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-[10px] uppercase font-bold text-slate-400 block mb-1">{t.lblQtyToPurchase} *</label>
                  <input 
                    type="number"
                    min="1"
                    required
                    value={purQty}
                    onChange={(e) => setPurQty(Math.max(1, Number(e.target.value)))}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 outline-none focus:border-blue-500 text-xs font-mono font-bold rounded-lg"
                  />
                </div>
                <div>
                  <label className="text-[10px] uppercase font-bold text-slate-400 block mb-1">{t.lblCostPriceUnit} (Rs.) *</label>
                  <input 
                    type="number"
                    min="1"
                    required
                    value={purCostPrice || ''}
                    onChange={(e) => setPurCostPrice(Number(e.target.value))}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 outline-none focus:border-blue-500 text-xs font-mono font-bold rounded-lg"
                  />
                </div>
              </div>

              {/* Double verification math report */}
              <div className="bg-slate-50 p-3 rounded-xl border space-y-2">
                <div className="flex justify-between font-extrabold text-slate-800 text-[11px]">
                  <span>{t.lblTotalBillAmount}:</span>
                  <span className="font-mono">Rs. {(purQty * purCostPrice).toLocaleString()}/-</span>
                </div>

                <div className="pt-2 border-t">
                  <label className="text-[10px] uppercase font-bold text-slate-500 block mb-1">{t.lblPaidAmount} (Rs.)</label>
                  <input 
                    type="number"
                    min="0"
                    max={purQty * purCostPrice}
                    placeholder="How much cash paid now?"
                    value={purAmountPaid || ''}
                    onChange={(e) => setPurAmountPaid(Number(e.target.value))}
                    className="w-full p-2 bg-white border border-slate-250 outline-none focus:border-emerald-500 text-xs font-mono font-bold rounded-md"
                  />
                </div>

                <div className="flex justify-between text-[10px] text-slate-500 pt-1 font-bold">
                  <span>{t.lblUnpaidRemaining}:</span>
                  <span className="text-rose-600 font-mono">Rs. {Math.max(0, (purQty * purCostPrice) - purAmountPaid).toLocaleString()}/-</span>
                </div>
              </div>

              <div className="flex gap-2 pt-2 border-t text-xs">
                <button
                  type="button"
                  onClick={() => setIsPurchaseModalOpen(false)}
                  className="w-full py-2.5 bg-slate-100 hover:bg-slate-200 rounded-lg text-slate-600 font-bold transition"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="w-full py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg font-black transition shadow-md"
                >
                  Record & Stock Inward 📦
                </button>
              </div>

            </form>
          </div>
        </div>
      )}

      {/* MODAL 3: SUPPLIER PAYMENT FORM */}
      {isPaymentModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-xs">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 space-y-4 shadow-2xl border border-slate-100">
            <div className="flex justify-between items-center border-b pb-3.5">
              <h3 className="font-black text-slate-800 text-sm flex items-center gap-1.5 border-none">
                <DollarSign className="w-5 h-5 text-indigo-600" />
                {t.modalRecordPayment}
              </h3>
              <button 
                onClick={() => setIsPaymentModalOpen(false)}
                className="text-slate-400 hover:text-slate-600 font-bold"
              >
                ×
              </button>
            </div>

            <form onSubmit={handleSupplierPaymentSubmit} className="space-y-4 text-xs font-semibold">
              
              <div>
                <label className="text-[10px] uppercase font-bold text-slate-400 block mb-1">{t.lblSelectSupplier} *</label>
                <select
                  required
                  value={paySupplierId}
                  onChange={(e) => setPaySupplierId(e.target.value)}
                  className="w-full p-2.5 bg-slate-50 hover:bg-slate-100 border border-slate-200 outline-none focus:border-blue-500 rounded-lg font-bold"
                >
                  <option value="">-- Wholesaler Dealer Chunein --</option>
                  {suppliers.map(sup => (
                    <option key={sup.id} value={sup.id}>
                      {sup.companyName} (Malik: {sup.name} | Owed Debit: Rs. {sup.balance})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="text-[10px] uppercase font-bold text-slate-400 block mb-1">CASH PAYMENT AMOUNT (Rs.) *</label>
                <input 
                  type="number"
                  min="1"
                  required
                  placeholder="Enter cash amount paid to supplier"
                  value={payAmount || ''}
                  onChange={(e) => setPayAmount(Number(e.target.value))}
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 outline-none focus:border-blue-500 text-xs font-mono font-bold rounded-lg"
                />
              </div>

              <div className="flex gap-2 pt-2 border-t text-xs">
                <button
                  type="button"
                  onClick={() => setIsPaymentModalOpen(false)}
                  className="w-full py-2.5 bg-slate-100 hover:bg-slate-200 rounded-lg text-slate-600 font-bold transition"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="w-full py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-black transition shadow-md"
                >
                  Record Cash Paid Outward 💸
                </button>
              </div>

            </form>
          </div>
        </div>
      )}

      {/* MODAL 4: CREATED STAFF REGISTER DETAILS */}
      {isStaffModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-xs">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 space-y-4 shadow-2xl border border-slate-100">
            <div className="flex justify-between items-center border-b pb-3.5">
              <h3 className="font-black text-slate-800 text-sm flex items-center gap-1.5 border-none">
                <Users className="w-5 h-5 text-blue-650" />
                {t.modalAddStaff}
              </h3>
              <button 
                onClick={() => setIsStaffModalOpen(false)}
                className="text-slate-400 hover:text-slate-600 font-bold"
              >
                ×
              </button>
            </div>

            <form onSubmit={handleCreateStaffSubmit} className="space-y-4 text-xs font-semibold">
              
              <div>
                <label className="text-[10px] uppercase font-bold text-slate-400 block mb-1">{t.lblStaffName} *</label>
                <input 
                  type="text"
                  required
                  placeholder="e.g. Zahid Iqbal"
                  value={stfName}
                  onChange={(e) => setStfName(e.target.value)}
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 outline-none focus:border-blue-500 focus:bg-white rounded-lg font-bold"
                />
              </div>

              <div>
                <label className="text-[10px] uppercase font-bold text-slate-400 block mb-1">{t.lblStaffRole} *</label>
                <input 
                  type="text"
                  required
                  placeholder="e.g. Sales Assistant, Security Guard, Rider"
                  value={stfRole}
                  onChange={(e) => setStfRole(e.target.value)}
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 outline-none focus:border-blue-500 focus:bg-white rounded-lg font-bold"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-[10px] uppercase font-bold text-slate-400 block mb-1">{t.lblPhoneNum}</label>
                  <input 
                    type="text"
                    placeholder="03123456789"
                    value={stfPhone}
                    onChange={(e) => setStfPhone(e.target.value)}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 outline-none focus:border-blue-500 font-mono font-bold rounded-lg"
                  />
                </div>
                <div>
                  <label className="text-[10px] uppercase font-bold text-slate-400 block mb-1">{t.lblStaffMonthly} *</label>
                  <input 
                    type="number"
                    min="1"
                    required
                    value={stfSalary}
                    onChange={(e) => setStfSalary(Number(e.target.value))}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 outline-none focus:border-blue-500 font-mono font-bold rounded-lg"
                  />
                </div>
              </div>

              <div className="flex gap-2 pt-2 border-t text-xs">
                <button
                  type="button"
                  onClick={() => setIsStaffModalOpen(false)}
                  className="w-full py-2.5 bg-slate-100 hover:bg-slate-200 rounded-lg text-slate-600 font-bold transition"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="w-full py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-black transition shadow-md"
                >
                  Add Mulazim Profile 👤
                </button>
              </div>

            </form>
          </div>
        </div>
      )}

      {/* MODAL 5: STAFF SALARIES AND ADVANCES */}
      {isSalaryModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-xs">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 space-y-4 shadow-2xl border border-slate-100">
            <div className="flex justify-between items-center border-b pb-3.5">
              <h3 className="font-black text-slate-800 text-sm flex items-center gap-1.5 border-none">
                <DollarSign className="w-5 h-5 text-indigo-600" />
                {t.modalRecordSalary}
              </h3>
              <button 
                onClick={() => setIsSalaryModalOpen(false)}
                className="text-slate-400 hover:text-slate-600 font-bold"
              >
                ×
              </button>
            </div>

            <form onSubmit={handleStaffWageSubmit} className="space-y-4 text-xs font-semibold">
              
              {/* Select Employee */}
              <div>
                <label className="text-[10px] uppercase font-bold text-slate-400 block mb-1">Select Employee *</label>
                <select
                  required
                  value={salStaffId}
                  onChange={(e) => setSalStaffId(e.target.value)}
                  className="w-full p-2.5 bg-slate-50 hover:bg-slate-100 border border-slate-200 outline-none focus:border-blue-500 rounded-lg font-bold"
                >
                  <option value="">-- Employee Chunein --</option>
                  {staff.map(emp => (
                    <option key={emp.id} value={emp.id}>
                      {emp.name} (Salary: Rs. {emp.monthlySalary} | Advance Debt: Rs. {emp.advanceTaken})
                    </option>
                  ))}
                </select>
              </div>

              {/* Salary payout or loan advance type */}
              <div>
                <label className="text-[10px] uppercase font-bold text-slate-400 block mb-1">Transaction Category / Type *</label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setSalType('salary')}
                    className={`py-2 px-3 border rounded-xl text-center font-bold transition duration-200 ${
                      salType === 'salary' ? 'bg-emerald-50 border-emerald-400 text-emerald-700' : 'bg-white border-slate-200 text-slate-600'
                    }`}
                  >
                    Monthly Wages / Salary
                  </button>
                  <button
                    type="button"
                    onClick={() => setSalType('advance')}
                    className={`py-2 px-3 border rounded-xl text-center font-bold transition duration-200 ${
                      salType === 'advance' ? 'bg-amber-50 border-amber-400 text-amber-900' : 'bg-white border-slate-200 text-slate-600'
                    }`}
                  >
                    Peshgi Loan / Advance
                  </button>
                </div>
              </div>

              {/* Amount Cash paid */}
              <div>
                <label className="text-[10px] uppercase font-bold text-slate-400 block mb-1">Payment Amount (Rs.) *</label>
                <input 
                  type="number"
                  min="1"
                  required
                  placeholder="Enter wages payout amount"
                  value={salAmount || ''}
                  onChange={(e) => setSalAmount(Number(e.target.value))}
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 outline-none focus:border-blue-500 text-xs font-mono font-bold rounded-lg"
                />
              </div>

              <div className="flex gap-2 pt-2 border-t text-xs">
                <button
                  type="button"
                  onClick={() => setIsSalaryModalOpen(false)}
                  className="w-full py-2.5 bg-slate-100 hover:bg-slate-200 rounded-lg text-slate-600 font-bold transition"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="w-full py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-black transition shadow-md"
                >
                  Disburse Cash Wages 💸
                </button>
              </div>

            </form>
          </div>
        </div>
      )}

    </div>
  );
}
