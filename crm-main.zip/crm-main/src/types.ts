/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface Product {
  id: string;
  name: string;
  category: string;
  costPrice: number;    // Purchase price
  sellingPrice: number; // Sale price
  stock: number;        // Current stock
  minStockAlert: number;// Minimum alert level
  image?: string;       // Base64 or URL
}

export interface Client {
  id: string;
  name: string;
  phone: string;
  address: string;
  balance: number;      // Cash client owes (Outstanding Loan / Khata)
  lastTransactionDate?: string;
}

export interface SaleItem {
  productId: string;
  productName: string;
  qty: number;
  costPrice: number;    // Buying cost at the time of sale
  sellingPrice: number; // Selling cost at the time of sale
}

export interface Sale {
  id: string;
  invoiceNumber: string;
  date: string;         // YYYY-MM-DD
  clientId: string;     // "walk-in" or individual client ID
  clientName: string;   // For convenience
  items: SaleItem[];
  totalAmount: number;
  discount: number;
  paidAmount: number;
  paymentStatus: 'Paid' | 'Unpaid' | 'Partially Paid';
  profit: number;       // Auto computed on server/client: (sellingPrice - costPrice) * qty
}

export interface Expense {
  id: string;
  title: string;
  amount: number;
  category: string;     // Rent, Salary, Bill, General, Chai, etc.
  date: string;         // YYYY-MM-DD
}

export interface Supplier {
  id: string;
  name: string;
  phone: string;
  companyName: string;
  address: string;
  balance: number;      // Amount WE owe the supplier (Payable debt)
}

export interface SupplierBill {
  id: string;
  billNumber: string;
  date: string;         // YYYY-MM-DD
  supplierId: string;
  supplierName: string;
  productId: string;
  productName: string;
  qty: number;
  costPrice: number;
  totalAmount: number;
  paidAmount: number;
}

export interface Staff {
  id: string;
  name: string;
  role: string;         // e.g. Helper, Delivery, Accountant
  phone: string;
  monthlySalary: number;
  advanceTaken: number;  // Amount taken in advance/loans
  attendanceToday?: 'Present' | 'Absent' | 'Half-day' | 'Leave';
}

export interface DashboardReport {
  dailySales: number;
  dailyProfit: number;
  monthlySales: number;
  monthlyProfit: number;
}
